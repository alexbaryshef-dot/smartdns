#include "smartdns/hosts_source.h"
#include "address.h"
#include "ptr.h"
#include "smartdns/tlog.h"
#include "smartdns/util.h"

#include <limits.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#define HOSTS_TIMEOUT_MS 1000
#define HOSTS_REPLY_MAX (512 * 1024)
#define HOSTS_LINE_MAX 1024

static char hosts_path[sizeof(((struct sockaddr_un *)0)->sun_path)];
static char **hosts_records;
static int hosts_records_num;
static char hosts_result[PATH_MAX + 128];
static tlog_level hosts_result_level;

int hosts_conf_socket(void *data, int argc, char *argv[])
{
	if (argc < 2 || strlen(argv[1]) >= sizeof(hosts_path)) {
		tlog(TLOG_ERROR, "invalid hosts-socket.");
		return -1;
	}

	safe_strncpy(hosts_path, argv[1], sizeof(hosts_path));
	return 0;
}

int hosts_conf_record(void *data, int argc, char *argv[])
{
	if (argc < 2 || strlen(argv[1]) >= HOSTS_LINE_MAX) {
		tlog(TLOG_ERROR, "invalid hosts-record.");
		return -1;
	}

	char **records = realloc(hosts_records, (hosts_records_num + 1) * sizeof(*records));
	if (records == NULL) {
		return -1;
	}
	hosts_records = records;

	hosts_records[hosts_records_num] = strdup(argv[1]);
	if (hosts_records[hosts_records_num] == NULL) {
		return -1;
	}
	hosts_records_num++;
	return 0;
}

static int _hosts_reply_done(const char *buf, size_t len)
{
	return (len == 2 && memcmp(buf, ".\n", 2) == 0) || (len > 2 && memcmp(buf + len - 3, "\n.\n", 3) == 0);
}

static char *_hosts_fetch(const char **reason)
{
	struct sockaddr_un addr = {.sun_family = AF_UNIX};
	safe_strncpy(addr.sun_path, hosts_path, sizeof(addr.sun_path));

	int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
	if (fd < 0) {
		*reason = "socket failed";
		return NULL;
	}

	char *buf = NULL;
	size_t len = 0;
	size_t cap = 0;
	unsigned long deadline = get_tick_count() + HOSTS_TIMEOUT_MS;

	if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
		*reason = "no answer from socket";
		goto errout;
	}

	if (send(fd, "HOSTS\n", 6, MSG_NOSIGNAL) != 6) {
		*reason = "send failed";
		goto errout;
	}

	while (!_hosts_reply_done(buf, len)) {
		long left = (long)(deadline - get_tick_count());
		struct pollfd pfd = {.fd = fd, .events = POLLIN};
		if (left <= 0 || poll(&pfd, 1, left) <= 0) {
			*reason = "timeout";
			goto errout;
		}

		if (cap - len < 4096) {
			cap = cap == 0 ? 8192 : cap * 2;
			char *grown = cap <= HOSTS_REPLY_MAX ? realloc(buf, cap + 1) : NULL;
			if (grown == NULL) {
				*reason = "reply too large";
				goto errout;
			}
			buf = grown;
		}

		ssize_t n = recv(fd, buf + len, cap - len, 0);
		if (n <= 0) {
			*reason = "connection closed";
			goto errout;
		}
		len += n;
		buf[len] = '\0';

		if (strncmp(buf, "ERR", 3) == 0) {
			*reason = "hrweb could not read records";
			goto errout;
		}
	}

	close(fd);
	buf[len - 2] = '\0';
	return buf;

errout:
	close(fd);
	free(buf);
	return NULL;
}

static void _hosts_add_ptr(const char *line, const char *slash)
{
	char host[DNS_MAX_CNAME_LEN];
	char addrs[HOSTS_LINE_MAX];
	char *save = NULL;

	if (line[0] == '*') {
		return;
	}
	if (strncmp(line, "-.", 2) == 0) {
		line += 2;
	}

	size_t host_len = slash - line;
	if (host_len == 0 || host_len >= sizeof(host)) {
		return;
	}
	memcpy(host, line, host_len);
	host[host_len] = '\0';
	safe_strncpy(addrs, slash + 1, sizeof(addrs));

	for (char *ip = strtok_r(addrs, ",", &save); ip != NULL; ip = strtok_r(NULL, ",", &save)) {
		if (ip[0] != '#' && strcmp(ip, "0.0.0.0") != 0) {
			_conf_ptr_add(host, ip, 0);
		}
	}
}

static void _hosts_apply(const char *line)
{
	char rule[HOSTS_LINE_MAX + 1];
	const char *slash = strchr(line, '/');

	if (slash == NULL || strlen(line) >= HOSTS_LINE_MAX) {
		tlog(TLOG_WARN, "invalid hosts record: %s", line);
		return;
	}

	snprintf(rule, sizeof(rule), "/%s", line);
	char *argv[] = {"address", rule, NULL};
	_config_address(NULL, 2, argv);
	_hosts_add_ptr(line, slash);
}

static void _hosts_records_free(void)
{
	for (int i = 0; i < hosts_records_num; i++) {
		free(hosts_records[i]);
	}
	free(hosts_records);
	hosts_records = NULL;
	hosts_records_num = 0;
}

void hosts_load(void)
{
	const char *reason = NULL;
	char *reply = NULL;
	char *save = NULL;

	if (hosts_path[0] != '\0') {
		reply = _hosts_fetch(&reason);
	}

	if (reply != NULL) {
		int count = 0;
		for (char *line = strtok_r(reply, "\n", &save); line != NULL; line = strtok_r(NULL, "\n", &save)) {
			_hosts_apply(line);
			count++;
		}
		hosts_result_level = TLOG_INFO;
		snprintf(hosts_result, sizeof(hosts_result), "hosts: %d records from %s.", count, hosts_path);
		free(reply);
	} else {
		if (reason != NULL) {
			hosts_result_level = TLOG_WARN;
			snprintf(hosts_result, sizeof(hosts_result), "hosts: %s (%s), using %d records from config.", hosts_path, reason,
					 hosts_records_num);
		}
		for (int i = 0; i < hosts_records_num; i++) {
			_hosts_apply(hosts_records[i]);
		}
	}

	_hosts_records_free();
}

void hosts_log(void)
{
	if (hosts_result[0] != '\0') {
		tlog(hosts_result_level, "%s", hosts_result);
	}
}
