#define _GNU_SOURCE

#include "ui.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define JSON_MAX_DEPTH 64

static void out_of_memory(void)
{
	static const char msg[] = "hrdns-ui: out of memory\n";
	if (write(STDERR_FILENO, msg, sizeof(msg) - 1) < 0) {
		abort();
	}

	abort();
}

void *xmalloc(size_t size)
{
	void *p = malloc(size ? size : 1);
	if (p == NULL) {
		out_of_memory();
	}

	return p;
}

void *xcalloc(size_t count, size_t size)
{
	void *p = calloc(count ? count : 1, size ? size : 1);
	if (p == NULL) {
		out_of_memory();
	}

	return p;
}

void *xrealloc(void *ptr, size_t size)
{
	void *p = realloc(ptr, size ? size : 1);
	if (p == NULL) {
		out_of_memory();
	}

	return p;
}

char *xstrndup(const char *s, size_t len)
{
	char *p = xmalloc(len + 1);
	memcpy(p, s, len);
	p[len] = '\0';
	return p;
}

void buf_reserve(struct buf *b, size_t extra)
{
	size_t need = b->len + extra + 1;
	if (need <= b->cap) {
		return;
	}

	size_t cap = b->cap ? b->cap : 256;
	while (cap < need) {
		cap *= 2;
	}

	b->data = xrealloc(b->data, cap);
	b->cap = cap;
}

void buf_add(struct buf *b, const void *data, size_t len)
{
	buf_reserve(b, len);
	if (len > 0) {
		memcpy(b->data + b->len, data, len);
	}

	b->len += len;
	b->data[b->len] = '\0';
}

void buf_str(struct buf *b, const char *s)
{
	buf_add(b, s, strlen(s));
}

void buf_byte(struct buf *b, char c)
{
	buf_reserve(b, 1);
	b->data[b->len++] = c;
	b->data[b->len] = '\0';
}

void buf_fmt(struct buf *b, const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(NULL, 0, fmt, ap);
	va_end(ap);
	if (n <= 0) {
		return;
	}

	buf_reserve(b, (size_t)n);
	va_start(ap, fmt);
	vsnprintf(b->data + b->len, (size_t)n + 1, fmt, ap);
	va_end(ap);
	b->len += (size_t)n;
}

void buf_free(struct buf *b)
{
	free(b->data);
	b->data = NULL;
	b->len = 0;
	b->cap = 0;
}

static int utf8_decode(const uint8_t *s, size_t len, uint32_t *rune)
{
	uint8_t c = s[0];
	if (c < 0x80) {
		*rune = c;
		return 1;
	}

	int n = 0;
	uint32_t r = 0;
	uint32_t min = 0;
	if (c >= 0xC2 && c <= 0xDF) {
		n = 2;
		r = c & 0x1F;
		min = 0x80;
	} else if (c >= 0xE0 && c <= 0xEF) {
		n = 3;
		r = c & 0x0F;
		min = 0x800;
	} else if (c >= 0xF0 && c <= 0xF4) {
		n = 4;
		r = c & 0x07;
		min = 0x10000;
	} else {
		return 0;
	}

	if ((size_t)n > len) {
		return 0;
	}

	for (int i = 1; i < n; i++) {
		if ((s[i] & 0xC0) != 0x80) {
			return 0;
		}

		r = (r << 6) | (s[i] & 0x3F);
	}

	if (r < min || r > 0x10FFFF || (r >= 0xD800 && r <= 0xDFFF)) {
		return 0;
	}

	*rune = r;
	return n;
}

void json_str(struct buf *b, const void *data, size_t len)
{
	static const char hex[] = "0123456789abcdef";
	const uint8_t *s = data;
	size_t start = 0;
	size_t i = 0;

	buf_reserve(b, len + 2);
	buf_byte(b, '"');
	while (i < len) {
		uint8_t c = s[i];
		if (c >= 0x20 && c != '"' && c != '\\' && c != '<' && c != '>' && c != '&' && c < 0x80) {
			i++;
			continue;
		}

		if (c < 0x80) {
			buf_add(b, s + start, i - start);
			switch (c) {
			case '"':
				buf_str(b, "\\\"");
				break;
			case '\\':
				buf_str(b, "\\\\");
				break;
			case '\b':
				buf_str(b, "\\b");
				break;
			case '\f':
				buf_str(b, "\\f");
				break;
			case '\n':
				buf_str(b, "\\n");
				break;
			case '\r':
				buf_str(b, "\\r");
				break;
			case '\t':
				buf_str(b, "\\t");
				break;
			default: {
				char esc[7] = {'\\', 'u', '0', '0', hex[c >> 4], hex[c & 0xF], '\0'};
				buf_str(b, esc);
			}
			}

			i++;
			start = i;
			continue;
		}

		uint32_t rune = 0;
		int n = utf8_decode(s + i, len - i, &rune);
		if (n == 0) {
			buf_add(b, s + start, i - start);
			buf_str(b, "\\ufffd");
			i++;
			start = i;
			continue;
		}

		if (rune == 0x2028 || rune == 0x2029) {
			buf_add(b, s + start, i - start);
			buf_str(b, rune == 0x2028 ? "\\u2028" : "\\u2029");
			i += (size_t)n;
			start = i;
			continue;
		}

		i += (size_t)n;
	}

	buf_add(b, s + start, len - start);
	buf_byte(b, '"');
}

void json_cstr(struct buf *b, const char *s)
{
	json_str(b, s, strlen(s));
}

void json_key(struct buf *b, const char *key)
{
	buf_byte(b, '"');
	buf_str(b, key);
	buf_str(b, "\":");
}

void json_u64(struct buf *b, uint64_t v)
{
	buf_fmt(b, "%" PRIu64, v);
}

void json_i64(struct buf *b, int64_t v)
{
	buf_fmt(b, "%" PRId64, v);
}

void json_float(struct buf *b, double v)
{
	char tmp[400];

	if (v == 0) {
		buf_str(b, signbit(v) ? "-0" : "0");
		return;
	}

	if (fabs(v) < 1e-6 || fabs(v) >= 1e21) {
		snprintf(tmp, sizeof(tmp), "%.17g", v);
		buf_str(b, tmp);
		return;
	}

	for (int p = 0; p <= 17; p++) {
		snprintf(tmp, sizeof(tmp), "%.*f", p, v);
		if (strtod(tmp, NULL) == v) {
			break;
		}
	}

	buf_str(b, tmp);
}

void json_bool(struct buf *b, int v)
{
	buf_str(b, v ? "true" : "false");
}

struct jparser {
	const char *p;
	const char *end;
	int depth;
};

static void skip_ws(struct jparser *jp)
{
	while (jp->p < jp->end && (*jp->p == ' ' || *jp->p == '\t' || *jp->p == '\n' || *jp->p == '\r')) {
		jp->p++;
	}
}

static int hex_value(char c)
{
	if (c >= '0' && c <= '9') {
		return c - '0';
	}

	if (c >= 'a' && c <= 'f') {
		return c - 'a' + 10;
	}

	if (c >= 'A' && c <= 'F') {
		return c - 'A' + 10;
	}

	return -1;
}

static int read_hex4(const char *p, const char *end, uint32_t *out)
{
	uint32_t v = 0;
	if (end - p < 4) {
		return -1;
	}

	for (int i = 0; i < 4; i++) {
		int h = hex_value(p[i]);
		if (h < 0) {
			return -1;
		}

		v = (v << 4) | (uint32_t)h;
	}

	*out = v;
	return 0;
}

static void put_utf8(struct buf *b, uint32_t r)
{
	char tmp[4];
	if (r < 0x80) {
		buf_byte(b, (char)r);
	} else if (r < 0x800) {
		tmp[0] = (char)(0xC0 | (r >> 6));
		tmp[1] = (char)(0x80 | (r & 0x3F));
		buf_add(b, tmp, 2);
	} else if (r < 0x10000) {
		tmp[0] = (char)(0xE0 | (r >> 12));
		tmp[1] = (char)(0x80 | ((r >> 6) & 0x3F));
		tmp[2] = (char)(0x80 | (r & 0x3F));
		buf_add(b, tmp, 3);
	} else {
		tmp[0] = (char)(0xF0 | (r >> 18));
		tmp[1] = (char)(0x80 | ((r >> 12) & 0x3F));
		tmp[2] = (char)(0x80 | ((r >> 6) & 0x3F));
		tmp[3] = (char)(0x80 | (r & 0x3F));
		buf_add(b, tmp, 4);
	}
}

static int parse_string(struct jparser *jp, char **out, size_t *out_len)
{
	struct buf b = {0};

	jp->p++;
	while (jp->p < jp->end && *jp->p != '"') {
		unsigned char c = (unsigned char)*jp->p;
		if (c < 0x20) {
			buf_free(&b);
			return -1;
		}

		if (c != '\\') {
			buf_byte(&b, (char)c);
			jp->p++;
			continue;
		}

		if (jp->end - jp->p < 2) {
			buf_free(&b);
			return -1;
		}

		char e = jp->p[1];
		jp->p += 2;
		switch (e) {
		case '"':
		case '\\':
		case '/':
			buf_byte(&b, e);
			break;
		case 'b':
			buf_byte(&b, '\b');
			break;
		case 'f':
			buf_byte(&b, '\f');
			break;
		case 'n':
			buf_byte(&b, '\n');
			break;
		case 'r':
			buf_byte(&b, '\r');
			break;
		case 't':
			buf_byte(&b, '\t');
			break;
		case 'u': {
			uint32_t r = 0;
			if (read_hex4(jp->p, jp->end, &r) != 0) {
				buf_free(&b);
				return -1;
			}

			jp->p += 4;
			if (r >= 0xD800 && r < 0xDC00) {
				uint32_t lo = 0;
				if (jp->end - jp->p >= 6 && jp->p[0] == '\\' && jp->p[1] == 'u' && read_hex4(jp->p + 2, jp->end, &lo) == 0 &&
					lo >= 0xDC00 && lo < 0xE000) {
					r = 0x10000 + ((r - 0xD800) << 10) + (lo - 0xDC00);
					jp->p += 6;
				} else {
					r = 0xFFFD;
				}
			} else if (r >= 0xDC00 && r < 0xE000) {
				r = 0xFFFD;
			}

			put_utf8(&b, r);
			break;
		}
		default:
			buf_free(&b);
			return -1;
		}
	}

	if (jp->p >= jp->end) {
		buf_free(&b);
		return -1;
	}

	jp->p++;
	if (b.data == NULL) {
		buf_reserve(&b, 0);
		b.data[0] = '\0';
	}

	*out = b.data;
	*out_len = b.len;
	return 0;
}

static int parse_value(struct jparser *jp, struct jval *v);

static int parse_number(struct jparser *jp, struct jval *v)
{
	const char *s = jp->p;
	if (jp->p < jp->end && *jp->p == '-') {
		jp->p++;
	}

	if (jp->p >= jp->end || *jp->p < '0' || *jp->p > '9') {
		return -1;
	}

	if (*jp->p == '0') {
		jp->p++;
	} else {
		while (jp->p < jp->end && *jp->p >= '0' && *jp->p <= '9') {
			jp->p++;
		}
	}

	if (jp->p < jp->end && *jp->p == '.') {
		jp->p++;
		if (jp->p >= jp->end || *jp->p < '0' || *jp->p > '9') {
			return -1;
		}

		while (jp->p < jp->end && *jp->p >= '0' && *jp->p <= '9') {
			jp->p++;
		}
	}

	if (jp->p < jp->end && (*jp->p == 'e' || *jp->p == 'E')) {
		jp->p++;
		if (jp->p < jp->end && (*jp->p == '+' || *jp->p == '-')) {
			jp->p++;
		}

		if (jp->p >= jp->end || *jp->p < '0' || *jp->p > '9') {
			return -1;
		}

		while (jp->p < jp->end && *jp->p >= '0' && *jp->p <= '9') {
			jp->p++;
		}
	}

	v->type = J_NUM;
	v->len = (size_t)(jp->p - s);
	v->str = xstrndup(s, v->len);
	return 0;
}

static int parse_literal(struct jparser *jp, const char *word)
{
	size_t n = strlen(word);
	if ((size_t)(jp->end - jp->p) < n || memcmp(jp->p, word, n) != 0) {
		return -1;
	}

	jp->p += n;
	return 0;
}

static int parse_container(struct jparser *jp, struct jval *v, int object)
{
	size_t cap = 0;
	char close = object ? '}' : ']';

	v->type = object ? J_OBJ : J_ARR;
	jp->p++;
	skip_ws(jp);
	if (jp->p < jp->end && *jp->p == close) {
		jp->p++;
		return 0;
	}

	for (;;) {
		char *key = NULL;
		size_t key_len = 0;

		skip_ws(jp);
		if (object) {
			if (jp->p >= jp->end || *jp->p != '"' || parse_string(jp, &key, &key_len) != 0) {
				return -1;
			}

			skip_ws(jp);
			if (jp->p >= jp->end || *jp->p != ':') {
				free(key);
				return -1;
			}

			jp->p++;
		}

		if (v->count == cap) {
			cap = cap ? cap * 2 : 8;
			v->items = xrealloc(v->items, cap * sizeof(*v->items));
			if (object) {
				v->keys = xrealloc(v->keys, cap * sizeof(*v->keys));
			}
		}

		memset(&v->items[v->count], 0, sizeof(*v->items));
		if (object) {
			v->keys[v->count] = key;
		}

		v->count++;
		if (parse_value(jp, &v->items[v->count - 1]) != 0) {
			return -1;
		}

		skip_ws(jp);
		if (jp->p < jp->end && *jp->p == ',') {
			jp->p++;
			continue;
		}

		if (jp->p < jp->end && *jp->p == close) {
			jp->p++;
			return 0;
		}

		return -1;
	}
}

static int parse_value(struct jparser *jp, struct jval *v)
{
	int ret = -1;

	if (++jp->depth > JSON_MAX_DEPTH) {
		return -1;
	}

	skip_ws(jp);
	if (jp->p >= jp->end) {
		return -1;
	}

	v->raw = jp->p;
	switch (*jp->p) {
	case '{':
		ret = parse_container(jp, v, 1);
		break;
	case '[':
		ret = parse_container(jp, v, 0);
		break;
	case '"':
		v->type = J_STR;
		ret = parse_string(jp, &v->str, &v->len);
		break;
	case 't':
		v->type = J_BOOL;
		v->boolean = 1;
		ret = parse_literal(jp, "true");
		break;
	case 'f':
		v->type = J_BOOL;
		ret = parse_literal(jp, "false");
		break;
	case 'n':
		v->type = J_NULL;
		ret = parse_literal(jp, "null");
		break;
	default:
		ret = parse_number(jp, v);
	}

	v->raw_len = (size_t)(jp->p - v->raw);
	jp->depth--;
	return ret;
}

int json_parse(const char *text, size_t len, struct jval *out)
{
	struct jparser jp = {text, text + len, 0};

	memset(out, 0, sizeof(*out));
	if (parse_value(&jp, out) != 0) {
		json_free(out);
		return -1;
	}

	skip_ws(&jp);
	if (jp.p != jp.end) {
		json_free(out);
		return -1;
	}

	return 0;
}

void json_free(struct jval *v)
{
	for (size_t i = 0; i < v->count; i++) {
		json_free(&v->items[i]);
		if (v->keys != NULL) {
			free(v->keys[i]);
		}
	}

	free(v->items);
	free(v->keys);
	free(v->str);
	memset(v, 0, sizeof(*v));
}

const struct jval *json_get(const struct jval *obj, const char *key)
{
	const struct jval *found = NULL;
	if (obj == NULL || obj->type != J_OBJ) {
		return NULL;
	}

	for (size_t i = 0; i < obj->count; i++) {
		if (strcmp(obj->keys[i], key) == 0) {
			found = &obj->items[i];
		}
	}

	return found;
}

static int digits_only(const char *s)
{
	if (*s == '\0') {
		return 0;
	}

	for (; *s; s++) {
		if (*s < '0' || *s > '9') {
			return 0;
		}
	}

	return 1;
}

int json_as_u64(const struct jval *v, uint64_t *out)
{
	if (v == NULL || v->type == J_NULL) {
		return 0;
	}

	if (v->type != J_NUM || !digits_only(v->str)) {
		return -1;
	}

	errno = 0;
	*out = strtoull(v->str, NULL, 10);
	return errno == 0 ? 0 : -1;
}

int json_as_i64(const struct jval *v, int64_t *out)
{
	if (v == NULL || v->type == J_NULL) {
		return 0;
	}

	if (v->type != J_NUM || !digits_only(v->str[0] == '-' ? v->str + 1 : v->str)) {
		return -1;
	}

	errno = 0;
	*out = strtoll(v->str, NULL, 10);
	return errno == 0 ? 0 : -1;
}

int json_as_double(const struct jval *v, double *out)
{
	if (v == NULL || v->type == J_NULL) {
		return 0;
	}

	if (v->type != J_NUM) {
		return -1;
	}

	*out = strtod(v->str, NULL);
	return 0;
}

int64_t now_ms(void)
{
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static int64_t days_from_civil(int64_t y, unsigned m, unsigned d)
{
	y -= m <= 2;
	int64_t era = (y >= 0 ? y : y - 399) / 400;
	unsigned yoe = (unsigned)(y - era * 400);
	unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
	unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
	return era * 146097 + (int64_t)doe - 719468;
}

void day_name(int64_t day, char out[11])
{
	int64_t z = day + 719468;
	int64_t era = (z >= 0 ? z : z - 146096) / 146097;
	unsigned doe = (unsigned)(z - era * 146097);
	unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
	int64_t y = (int64_t)yoe + era * 400;
	unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
	unsigned mp = (5 * doy + 2) / 153;
	unsigned d = doy - (153 * mp + 2) / 5 + 1;
	unsigned m = mp < 10 ? mp + 3 : mp - 9;
	y += m <= 2;
	snprintf(out, 11, "%04d-%02u-%02u", (int)y, m, d);
}

int parse_day(const char *name, int64_t *day)
{
	static const unsigned mdays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	for (int i = 0; i < 10; i++) {
		if (i == 4 || i == 7) {
			if (name[i] != '-') {
				return -1;
			}
		} else if (name[i] < '0' || name[i] > '9') {
			return -1;
		}
	}

	if (name[10] != '\0') {
		return -1;
	}

	int y = (name[0] - '0') * 1000 + (name[1] - '0') * 100 + (name[2] - '0') * 10 + (name[3] - '0');
	unsigned m = (unsigned)((name[5] - '0') * 10 + (name[6] - '0'));
	unsigned d = (unsigned)((name[8] - '0') * 10 + (name[9] - '0'));
	if (m < 1 || m > 12 || d < 1) {
		return -1;
	}

	unsigned limit = mdays[m - 1];
	if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) {
		limit = 29;
	}

	if (d > limit) {
		return -1;
	}

	*day = days_from_civil(y, m, d);
	return 0;
}

void format_addr(uint8_t family, const uint8_t addr[ADDR_LEN], char out[ADDR_STR_LEN])
{
	static const uint8_t mapped[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xFF, 0xFF};
	int zero_start = 255;
	int zero_end = 255;
	size_t n = 0;

	out[0] = '\0';
	if (family == 4) {
		snprintf(out, ADDR_STR_LEN, "%u.%u.%u.%u", addr[0], addr[1], addr[2], addr[3]);
		return;
	}

	if (family != 6) {
		return;
	}

	if (memcmp(addr, mapped, sizeof(mapped)) == 0) {
		snprintf(out, ADDR_STR_LEN, "::ffff:%u.%u.%u.%u", addr[12], addr[13], addr[14], addr[15]);
		return;
	}

	for (int i = 0; i < 8; i++) {
		int j = i;
		while (j < 8 && addr[j * 2] == 0 && addr[j * 2 + 1] == 0) {
			j++;
		}

		if (j - i >= 2 && j - i > zero_end - zero_start) {
			zero_start = i;
			zero_end = j;
		}
	}

	for (int i = 0; i < 8; i++) {
		if (i == zero_start) {
			n += (size_t)snprintf(out + n, ADDR_STR_LEN - n, "::");
			i = zero_end;
			if (i >= 8) {
				break;
			}
		} else if (i > 0) {
			n += (size_t)snprintf(out + n, ADDR_STR_LEN - n, ":");
		}

		n += (size_t)snprintf(out + n, ADDR_STR_LEN - n, "%x", (unsigned)(addr[i * 2] << 8 | addr[i * 2 + 1]));
	}
}

void format_mac(const uint8_t mac[MAC_LEN], char out[MAC_STR_LEN])
{
	snprintf(out, MAC_STR_LEN, "%02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

int mac_is_zero(const uint8_t mac[MAC_LEN])
{
	for (int i = 0; i < MAC_LEN; i++) {
		if (mac[i] != 0) {
			return 0;
		}
	}

	return 1;
}

int mkdir_all(const char *path)
{
	char tmp[1024];
	struct stat st;
	size_t len = strlen(path);

	if (len == 0 || len >= sizeof(tmp)) {
		errno = ENAMETOOLONG;
		return -1;
	}

	memcpy(tmp, path, len + 1);
	for (char *p = tmp + 1; *p; p++) {
		if (*p != '/') {
			continue;
		}

		*p = '\0';
		if (mkdir(tmp, 0755) != 0 && errno != EEXIST) {
			return -1;
		}

		*p = '/';
	}

	if (mkdir(tmp, 0755) != 0) {
		if (errno != EEXIST || stat(tmp, &st) != 0 || !S_ISDIR(st.st_mode)) {
			if (errno == EEXIST) {
				errno = ENOTDIR;
			}

			return -1;
		}
	}

	return 0;
}

int remove_all(const char *path)
{
	struct stat st;
	if (lstat(path, &st) != 0) {
		return errno == ENOENT ? 0 : -1;
	}

	if (!S_ISDIR(st.st_mode)) {
		return unlink(path);
	}

	DIR *dir = opendir(path);
	if (dir == NULL) {
		return -1;
	}

	struct dirent *ent = NULL;
	char child[1024];
	int ret = 0;
	while ((ent = readdir(dir)) != NULL) {
		if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) {
			continue;
		}

		snprintf(child, sizeof(child), "%s/%s", path, ent->d_name);
		if (remove_all(child) != 0) {
			ret = -1;
		}
	}

	closedir(dir);
	if (rmdir(path) != 0) {
		ret = -1;
	}

	return ret;
}

int atomic_write(const char *path, const void *data, size_t len)
{
	char tmp[1024];
	const char *p = data;
	int fd = -1;

	snprintf(tmp, sizeof(tmp), "%s.tmp", path);
	fd = open(tmp, O_CREAT | O_WRONLY | O_TRUNC | O_CLOEXEC, 0644);
	if (fd < 0) {
		return -1;
	}

	while (len > 0) {
		ssize_t n = write(fd, p, len);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			int err = errno;
			close(fd);
			unlink(tmp);
			errno = err;
			return -1;
		}

		p += n;
		len -= (size_t)n;
	}

	if (fsync(fd) != 0) {
		int err = errno;
		close(fd);
		unlink(tmp);
		errno = err;
		return -1;
	}

	if (close(fd) != 0) {
		int err = errno;
		unlink(tmp);
		errno = err;
		return -1;
	}

	return rename(tmp, path);
}

int read_file(const char *path, struct buf *out)
{
	char chunk[65536];
	int fd = open(path, O_RDONLY | O_CLOEXEC);
	if (fd < 0) {
		return -1;
	}

	for (;;) {
		ssize_t n = read(fd, chunk, sizeof(chunk));
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n < 0) {
			int err = errno;
			close(fd);
			errno = err;
			return -1;
		}

		if (n == 0) {
			break;
		}

		buf_add(out, chunk, (size_t)n);
	}

	close(fd);
	if (out->data == NULL) {
		buf_reserve(out, 0);
		out->data[0] = '\0';
	}

	return 0;
}
