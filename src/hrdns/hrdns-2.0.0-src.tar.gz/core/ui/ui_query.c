#define _GNU_SOURCE

#include "store.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define BLOCK_RECS 4096

enum { PRED_CLI, PRED_GRP, PRED_RCODE, PRED_QTYPE, PRED_FLAGS, PRED_DOM, PRED_TIME, NUM_PREDS };

static const int pred_column[NUM_PREDS] = {COL_CLI, COL_GRP, COL_RCODE, COL_QTYPE, COL_FLAGS, COL_DOM, COL_TMS};

struct seg_filter {
	int skip;
	int preds[NUM_PREDS];
	int npreds;
	uint8_t *dom_set;
	size_t ndom_set;
	uint8_t *cli_set;
	size_t ncli_set;
	int cli_one;
	int grp;
	int qtype;
	int rcode;
	uint8_t flag_mask;
	uint8_t flag_want;
	uint32_t lo_tms;
	uint32_t hi_tms;
	int constant;
};

struct block {
	uint8_t cols[NUM_COLS][BLOCK_RECS * 4];
	int loaded[NUM_COLS];
	size_t start;
	size_t n;
	uint16_t cand[BLOCK_RECS];
	size_t ncand;
};

static struct block blk;

static int64_t mono_ms(void)
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static int expired(int64_t deadline)
{
	return deadline != 0 && mono_ms() > deadline;
}

static int filter_unconstrained(const struct filter *f)
{
	return f->domain[0] == '\0' && f->domain_mode[0] == '\0' && !f->has_qtype && f->client[0] == '\0' && !f->has_group &&
		   !f->has_rcode && f->blocked == TRI_ANY && f->cached == TRI_ANY && f->after == 0 && f->before == 0;
}

static int hex_digit(char c)
{
	if (c >= '0' && c <= '9') {
		return c - '0';
	}

	if (c >= 'a' && c <= 'f') {
		return c - 'a' + 10;
	}

	if (c >= 'A' && c <= 'F') {
		return c - 'A' + 10;
	}

	return -1;
}

static int hex_pair(const char *s, uint8_t *out)
{
	int hi = hex_digit(s[0]);
	int lo = hi < 0 ? -1 : hex_digit(s[1]);
	if (lo < 0) {
		return -1;
	}

	*out = (uint8_t)(hi << 4 | lo);
	return 0;
}

static int client_mac(const char *s, uint8_t mac[MAC_LEN])
{
	size_t len = strlen(s);

	if (len == 17 && (s[2] == ':' || s[2] == '-')) {
		for (int i = 0; i < MAC_LEN; i++) {
			if (hex_pair(s + i * 3, &mac[i]) != 0 || (i < MAC_LEN - 1 && s[i * 3 + 2] != s[2])) {
				return 0;
			}
		}
	} else if (len == 14 && s[4] == '.') {
		for (int i = 0; i < 3; i++) {
			if (hex_pair(s + i * 5, &mac[i * 2]) != 0 || hex_pair(s + i * 5 + 2, &mac[i * 2 + 1]) != 0 ||
				(i < 2 && s[i * 5 + 4] != '.')) {
				return 0;
			}
		}
	} else {
		return 0;
	}

	return !mac_is_zero(mac);
}

static uint8_t lower_byte(uint8_t c)
{
	return c >= 'A' && c <= 'Z' ? (uint8_t)(c + 32) : c;
}

static int contains_fold(const uint8_t *name, size_t len, const char *needle, size_t n)
{
	for (size_t i = 0; i + n <= len; i++) {
		size_t j = 0;
		while (j < n && lower_byte(name[i + j]) == (uint8_t)needle[j]) {
			j++;
		}

		if (j == n) {
			return 1;
		}
	}

	return 0;
}

static int cmp_int(const void *a, const void *b)
{
	return *(const int *)a - *(const int *)b;
}

static void filter_release(struct seg_filter *sf)
{
	free(sf->dom_set);
	free(sf->cli_set);
	sf->dom_set = NULL;
	sf->cli_set = NULL;
}

static void filter_compile(const struct filter *f, const struct seg_view *v, struct seg_filter *sf)
{
	int64_t day_start = v->day * DAY_MILLIS;
	int64_t lo = 0;
	int64_t hi = DAY_MILLIS - 1;
	const struct dict *d = v->dict;

	memset(sf, 0, sizeof(*sf));
	sf->grp = -1;
	sf->qtype = -1;
	sf->rcode = -1;
	sf->cli_one = -1;
	sf->hi_tms = DAY_MILLIS - 1;
	if (f->after != 0) {
		lo = f->after - day_start;
		if (lo < 0) {
			lo = 0;
		}
	}

	if (f->before != 0) {
		hi = f->before - day_start;
		if (hi > DAY_MILLIS - 1) {
			hi = DAY_MILLIS - 1;
		}
	}

	if (lo > hi) {
		sf->skip = 1;
		return;
	}

	sf->lo_tms = (uint32_t)lo;
	sf->hi_tms = (uint32_t)hi;
	if (f->has_qtype) {
		sf->qtype = f->qtype;
		sf->preds[sf->npreds++] = PRED_QTYPE;
	}

	if (f->has_rcode) {
		sf->rcode = f->rcode;
		sf->preds[sf->npreds++] = PRED_RCODE;
	}

	if (f->has_group) {
		size_t glen = strlen(f->group);
		for (size_t i = 0; i < d->ngroups; i++) {
			if (d->groups[i].len == glen && memcmp(d->groups[i].data, f->group, glen) == 0) {
				sf->grp = (int)i;
			}
		}

		if (sf->grp < 0) {
			sf->skip = 1;
			return;
		}

		sf->preds[sf->npreds++] = PRED_GRP;
	}

	if (f->blocked != TRI_ANY) {
		sf->flag_mask |= FLAG_BLOCKED;
		if (f->blocked == TRI_YES) {
			sf->flag_want |= FLAG_BLOCKED;
		}
	}

	if (f->cached != TRI_ANY) {
		sf->flag_mask |= FLAG_CACHED;
		if (f->cached == TRI_YES) {
			sf->flag_want |= FLAG_CACHED;
		}
	}

	if (sf->flag_mask != 0) {
		sf->preds[sf->npreds++] = PRED_FLAGS;
	}

	if (f->client[0] != '\0') {
		uint8_t mac[MAC_LEN];
		int by_mac = client_mac(f->client, mac);
		size_t matched = 0;

		sf->ncli_set = d->nclients;
		sf->cli_set = xcalloc(d->nclients, 1);
		for (size_t i = 0; i < d->nclients; i++) {
			const uint8_t *k = d->clients[i];
			int ok = 0;
			if (by_mac) {
				ok = memcmp(k + 1 + ADDR_LEN, mac, MAC_LEN) == 0;
			} else {
				char addr[ADDR_STR_LEN];
				format_addr(k[0], k + 1, addr);
				ok = strcmp(addr, f->client) == 0;
			}

			if (ok) {
				sf->cli_set[i] = 1;
				sf->cli_one = (int)i;
				matched++;
			}
		}

		if (matched == 0) {
			sf->skip = 1;
			return;
		}

		if (matched > 1) {
			sf->cli_one = -1;
		}

		sf->preds[sf->npreds++] = PRED_CLI;
	}

	if (f->domain[0] != '\0' || strcmp(f->domain_mode, "notempty") == 0) {
		size_t needle_len = strlen(f->domain);
		char *needle = xstrndup(f->domain, needle_len);
		size_t matched = 0;

		for (size_t i = 0; i < needle_len; i++) {
			needle[i] = (char)lower_byte((uint8_t)needle[i]);
		}

		sf->ndom_set = d->ndom;
		sf->dom_set = xcalloc(d->ndom, 1);
		for (uint32_t id = 0; id < d->ndom; id++) {
			size_t len = 0;
			const uint8_t *name = dict_domain(d, id, &len);
			int ok = 0;
			if (strcmp(f->domain_mode, "contains") == 0) {
				ok = contains_fold(name, len, needle, needle_len);
			} else if (strcmp(f->domain_mode, "notempty") == 0) {
				ok = len > 0;
			} else {
				ok = len == needle_len && memcmp(name, f->domain, len) == 0;
			}

			if (ok) {
				sf->dom_set[id] = 1;
				matched++;
			}
		}

		free(needle);
		if (matched == 0) {
			sf->skip = 1;
			return;
		}

		sf->preds[sf->npreds++] = PRED_DOM;
	}

	if (sf->lo_tms != 0 || sf->hi_tms != DAY_MILLIS - 1) {
		sf->preds[sf->npreds++] = PRED_TIME;
	}

	qsort(sf->preds, (size_t)sf->npreds, sizeof(int), cmp_int);
	sf->constant = sf->npreds == 0;
}

static int match_rec(const struct seg_filter *sf, const struct rec *r)
{
	if (sf->constant) {
		return 1;
	}

	if (r->tms < sf->lo_tms || r->tms > sf->hi_tms) {
		return 0;
	}

	if (sf->dom_set != NULL && (r->dom >= sf->ndom_set || !sf->dom_set[r->dom])) {
		return 0;
	}

	if (sf->cli_set != NULL && (r->cli >= sf->ncli_set || !sf->cli_set[r->cli])) {
		return 0;
	}

	if (sf->grp >= 0 && r->grp != sf->grp) {
		return 0;
	}

	if (sf->qtype >= 0 && r->qtype != sf->qtype) {
		return 0;
	}

	if (sf->rcode >= 0 && r->rcode != sf->rcode) {
		return 0;
	}

	return (r->flags & sf->flag_mask) == sf->flag_want;
}

static int test_at(const struct seg_filter *sf, int pred, const struct block *b, size_t i)
{
	switch (pred) {
	case PRED_CLI: {
		size_t id = get_u16(b->cols[COL_CLI], i);
		return id < sf->ncli_set && sf->cli_set[id];
	}
	case PRED_GRP:
		return b->cols[COL_GRP][i] == sf->grp;
	case PRED_RCODE:
		return b->cols[COL_RCODE][i] == sf->rcode;
	case PRED_QTYPE:
		return get_u16(b->cols[COL_QTYPE], i) == sf->qtype;
	case PRED_FLAGS:
		return (b->cols[COL_FLAGS][i] & sf->flag_mask) == sf->flag_want;
	case PRED_DOM: {
		size_t id = get_u24(b->cols[COL_DOM], i);
		return id < sf->ndom_set && sf->dom_set[id];
	}
	default: {
		uint32_t t = get_u32(b->cols[COL_TMS], i);
		return t >= sf->lo_tms && t <= sf->hi_tms;
	}
	}
}

static void scan_first(const struct seg_filter *sf, int pred, struct block *b)
{
	const uint8_t *col = b->cols[pred_column[pred]];
	size_t n = b->n;
	size_t m = 0;

	switch (pred) {
	case PRED_CLI:
		if (sf->cli_one >= 0) {
			uint8_t lo = (uint8_t)sf->cli_one;
			uint8_t hi = (uint8_t)(sf->cli_one >> 8);
			for (size_t i = 0; i < n; i++) {
				if (col[i * 2] == lo && col[i * 2 + 1] == hi) {
					b->cand[m++] = (uint16_t)i;
				}
			}
		} else {
			for (size_t i = 0; i < n; i++) {
				size_t id = get_u16(col, i);
				if (id < sf->ncli_set && sf->cli_set[id]) {
					b->cand[m++] = (uint16_t)i;
				}
			}
		}

		break;
	case PRED_GRP:
	case PRED_RCODE: {
		uint8_t want = (uint8_t)(pred == PRED_GRP ? sf->grp : sf->rcode);
		for (size_t i = 0; i < n; i++) {
			if (col[i] == want) {
				b->cand[m++] = (uint16_t)i;
			}
		}

		break;
	}
	case PRED_QTYPE: {
		uint8_t lo = (uint8_t)sf->qtype;
		uint8_t hi = (uint8_t)(sf->qtype >> 8);
		for (size_t i = 0; i < n; i++) {
			if (col[i * 2] == lo && col[i * 2 + 1] == hi) {
				b->cand[m++] = (uint16_t)i;
			}
		}

		break;
	}
	case PRED_FLAGS:
		for (size_t i = 0; i < n; i++) {
			if ((col[i] & sf->flag_mask) == sf->flag_want) {
				b->cand[m++] = (uint16_t)i;
			}
		}

		break;
	case PRED_DOM:
		for (size_t i = 0; i < n; i++) {
			size_t id = get_u24(col, i);
			if (id < sf->ndom_set && sf->dom_set[id]) {
				b->cand[m++] = (uint16_t)i;
			}
		}

		break;
	default:
		for (size_t i = 0; i < n; i++) {
			uint32_t t = get_u32(col, i);
			if (t >= sf->lo_tms && t <= sf->hi_tms) {
				b->cand[m++] = (uint16_t)i;
			}
		}
	}

	b->ncand = m;
}

static void block_reset(struct block *b, size_t start, size_t n)
{
	b->start = start;
	b->n = n;
	memset(b->loaded, 0, sizeof(b->loaded));
}

static int block_load(const struct seg_view *v, struct block *b, int col)
{
	size_t w = (size_t)col_width[col];
	size_t want = b->n * w;
	size_t got = 0;
	off_t off = (off_t)(b->start * w);

	if (b->loaded[col]) {
		return 1;
	}

	while (got < want && v->fds[col] >= 0) {
		ssize_t n = pread(v->fds[col], b->cols[col] + got, want - got, off + (off_t)got);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			break;
		}

		got += (size_t)n;
	}

	if (got < want) {
		if (!late_column(col)) {
			return 0;
		}

		memset(b->cols[col] + got, 0, want - got);
	}

	b->loaded[col] = 1;
	return 1;
}

static int block_load_all(const struct seg_view *v, struct block *b)
{
	for (int col = 0; col < NUM_COLS; col++) {
		if (!block_load(v, b, col)) {
			return 0;
		}
	}

	return 1;
}

static void decode_rec(const struct block *b, size_t i, struct rec *r)
{
	r->tms = get_u32(b->cols[COL_TMS], i);
	r->dom = get_u24(b->cols[COL_DOM], i);
	r->cli = get_u16(b->cols[COL_CLI], i);
	r->grp = b->cols[COL_GRP][i];
	r->qtype = get_u16(b->cols[COL_QTYPE], i);
	r->rcode = b->cols[COL_RCODE][i];
	r->flags = b->cols[COL_FLAGS][i];
	r->qms = get_u16(b->cols[COL_QMS], i);
	r->ping = get_u16(b->cols[COL_PING], i);
	r->blk = b->cols[COL_BLK][i];
}

static int match_block(const struct seg_view *v, const struct seg_filter *sf, struct block *b)
{
	if (sf->constant) {
		for (size_t i = 0; i < b->n; i++) {
			b->cand[i] = (uint16_t)i;
		}

		b->ncand = b->n;
		return 1;
	}

	for (int k = 0; k < sf->npreds; k++) {
		int pred = sf->preds[k];
		if (!block_load(v, b, pred_column[pred])) {
			return 0;
		}

		if (k == 0) {
			scan_first(sf, pred, b);
			continue;
		}

		size_t kept = 0;
		for (size_t j = 0; j < b->ncand; j++) {
			if (test_at(sf, pred, b, b->cand[j])) {
				b->cand[kept++] = b->cand[j];
			}
		}

		b->ncand = kept;
		if (kept == 0) {
			break;
		}
	}

	return 1;
}

typedef int (*visit_fn)(void *ctx, struct seg_view *v, size_t idx, const struct rec *r);

enum scan_result { SCAN_EXPIRED, SCAN_DONE, SCAN_STOPPED };

static enum scan_result scan_file(struct seg_view *v, const struct seg_filter *sf, int desc, size_t lo, size_t hi, int64_t deadline,
								  visit_fn fn, void *ctx)
{
	struct block *b = &blk;
	struct rec r;

	for (size_t step = 0; step < hi - lo; step += BLOCK_RECS) {
		size_t start = lo + step;
		size_t end = lo + step + BLOCK_RECS < hi ? lo + step + BLOCK_RECS : hi;
		if (desc) {
			end = hi - step;
			start = end - lo > BLOCK_RECS ? end - BLOCK_RECS : lo;
		}

		if (expired(deadline)) {
			return SCAN_EXPIRED;
		}

		block_reset(b, start, end - start);
		if (!match_block(v, sf, b)) {
			return SCAN_DONE;
		}

		if (b->ncand == 0) {
			continue;
		}

		if (!block_load_all(v, b)) {
			return SCAN_DONE;
		}

		for (size_t k = 0; k < b->ncand; k++) {
			size_t i = desc ? b->cand[b->ncand - 1 - k] : b->cand[k];
			decode_rec(b, i, &r);
			if (!fn(ctx, v, start + i, &r)) {
				return SCAN_STOPPED;
			}
		}
	}

	return SCAN_DONE;
}

static enum scan_result scan(struct seg_view *v, const struct seg_filter *sf, int desc, size_t lo, size_t hi, int64_t deadline,
							 visit_fn fn, void *ctx)
{
	size_t file_hi = hi < v->nflushed ? hi : v->nflushed;
	size_t pend_lo = lo > v->nflushed ? lo : v->nflushed;

	if (desc) {
		for (size_t i = hi; i-- > pend_lo;) {
			const struct rec *r = &v->pending[i - v->nflushed];
			if (match_rec(sf, r) && !fn(ctx, v, i, r)) {
				return SCAN_STOPPED;
			}
		}
	}

	if (lo < file_hi) {
		enum scan_result res = scan_file(v, sf, desc, lo, file_hi, deadline, fn, ctx);
		if (res != SCAN_DONE) {
			return res;
		}
	}

	if (!desc) {
		for (size_t i = pend_lo; i < hi; i++) {
			const struct rec *r = &v->pending[i - v->nflushed];
			if (match_rec(sf, r) && !fn(ctx, v, i, r)) {
				return SCAN_STOPPED;
			}
		}
	}

	return SCAN_DONE;
}

static int iterate(struct views *vs, const struct filter *f, int desc, uint64_t boundary, int has_boundary, int64_t deadline,
				   visit_fn fn, void *ctx)
{
	int64_t b_day = (int64_t)(boundary >> ID_DAY_SHIFT);
	int64_t b_idx = (int64_t)(boundary & ID_INDEX_MASK) - 1;

	for (size_t k = 0; k < vs->n; k++) {
		struct seg_view *v = &vs->v[desc ? vs->n - 1 - k : k];
		struct seg_filter sf;

		if (has_boundary && ((desc && v->day > b_day) || (!desc && v->day < b_day))) {
			continue;
		}

		seg_open(v);
		if (v->empty) {
			continue;
		}

		size_t lo = 0;
		size_t hi = v->nrec;
		if (has_boundary && v->day == b_day) {
			if (desc) {
				size_t limit = b_idx > 0 ? (size_t)b_idx : 0;
				if (limit < hi) {
					hi = limit;
				}
			} else {
				size_t next = (size_t)(b_idx + 1);
				lo = next < hi ? next : hi;
			}
		}

		filter_compile(f, v, &sf);
		if (sf.skip || lo >= hi) {
			filter_release(&sf);
			continue;
		}

		enum scan_result res = scan(v, &sf, desc, lo, hi, deadline, fn, ctx);
		filter_release(&sf);
		if (res == SCAN_EXPIRED) {
			return 0;
		}

		if (res == SCAN_STOPPED) {
			return 1;
		}
	}

	return 1;
}

static void make_record(const struct seg_view *v, size_t idx, const struct rec *r, struct record *out)
{
	const struct dict *d = v->dict;

	memset(out, 0, sizeof(*out));
	out->id = (uint64_t)v->day << ID_DAY_SHIFT | (uint64_t)(idx + 1);
	out->time_ms = v->day * DAY_MILLIS + r->tms;
	out->domain = dict_domain(d, r->dom, &out->domain_len);
	out->qtype = r->qtype;
	if (r->cli < d->nclients) {
		format_addr(d->clients[r->cli][0], d->clients[r->cli] + 1, out->client);
		memcpy(out->mac, d->clients[r->cli] + 1 + ADDR_LEN, MAC_LEN);
	}

	if (r->grp < d->ngroups) {
		out->group = d->groups[r->grp].data;
		out->group_len = d->groups[r->grp].len;
	} else {
		out->group = "";
	}

	out->rcode = r->rcode;
	out->query_ms = r->qms;
	out->ping_tenths = r->ping == PING_NONE ? -1 : r->ping;
	out->blocked = (r->flags & FLAG_BLOCKED) != 0;
	out->block_list = r->blk;
	out->cached = (r->flags & FLAG_CACHED) != 0;
}

struct list_ctx {
	struct list_result *res;
	size_t skip;
	size_t size;
	size_t cap;
};

static int list_visit(void *ctx, struct seg_view *v, size_t idx, const struct rec *r)
{
	struct list_ctx *lc = ctx;

	if (lc->skip > 0) {
		lc->skip--;
		return 1;
	}

	if (lc->res->count == lc->cap) {
		lc->cap = lc->cap ? lc->cap * 2 : 16;
		lc->res->records = xrealloc(lc->res->records, lc->cap * sizeof(*lc->res->records));
	}

	make_record(v, idx, r, &lc->res->records[lc->res->count++]);
	return lc->res->count < lc->size;
}

static uint64_t count_views(struct views *vs, const struct filter *f, int budget_ms, int *complete)
{
	uint64_t total = 0;
	int64_t deadline = budget_ms > 0 ? mono_ms() + budget_ms : 0;

	*complete = 1;
	if (filter_unconstrained(f)) {
		for (size_t i = 0; i < vs->n; i++) {
			seg_open(&vs->v[i]);
			if (!vs->v[i].empty) {
				total += vs->v[i].nrec;
			}
		}

		return total;
	}

	for (size_t k = vs->n; k-- > 0;) {
		struct seg_view *v = &vs->v[k];
		struct seg_filter sf;

		seg_open(v);
		if (v->empty) {
			continue;
		}

		filter_compile(f, v, &sf);
		if (sf.skip) {
			filter_release(&sf);
			continue;
		}

		size_t file_hi = v->nrec < v->nflushed ? v->nrec : v->nflushed;
		int failed = 0;
		for (size_t start = 0; start < file_hi && !failed; start += BLOCK_RECS) {
			if (expired(deadline)) {
				filter_release(&sf);
				*complete = 0;
				return total;
			}

			block_reset(&blk, start, (start + BLOCK_RECS < file_hi ? start + BLOCK_RECS : file_hi) - start);
			failed = !match_block(v, &sf, &blk);
			total += failed ? 0 : blk.ncand;
		}

		for (size_t i = v->nflushed; i < v->nrec && !failed; i++) {
			if (match_rec(&sf, &v->pending[i - v->nflushed])) {
				total++;
			}
		}

		filter_release(&sf);
	}

	return total;
}

void store_list(const struct filter *f, const struct page_spec *p, int budget_ms, struct list_result *out)
{
	struct list_ctx lc = {out, 0, p->size > SIZE_MAX ? SIZE_MAX : (size_t)p->size, 0};
	int desc = !p->asc;
	int complete = 1;

	memset(out, 0, sizeof(*out));
	out->views = store_views();
	out->step_by_cursor = p->has_cursor || p->total_given;
	if (p->has_cursor && p->prev) {
		desc = !desc;
	}

	if (!p->has_cursor) {
		uint64_t skip = p->num - 1;
		lc.skip = p->size != 0 && skip > SIZE_MAX / p->size ? SIZE_MAX : (size_t)(skip * p->size);
	}

	iterate(out->views, f, desc, p->cursor, p->has_cursor, 0, list_visit, &lc);
	if (p->has_cursor && p->prev) {
		for (size_t i = 0; i < out->count / 2; i++) {
			struct record tmp = out->records[i];
			out->records[i] = out->records[out->count - 1 - i];
			out->records[out->count - 1 - i] = tmp;
		}
	}

	if (p->total_given) {
		out->total = p->total;
		return;
	}

	out->total = count_views(out->views, f, budget_ms, &complete);
	out->truncated = !complete;
}

void store_list_free(struct list_result *res)
{
	free(res->records);
	views_release(res->views);
	memset(res, 0, sizeof(*res));
}

uint64_t store_count(const struct filter *f, int budget_ms, int *complete)
{
	struct views *vs = store_views();
	uint64_t total = count_views(vs, f, budget_ms, complete);
	views_release(vs);
	return total;
}

int store_get(uint64_t id, struct record *out, struct views **views)
{
	int64_t day = (int64_t)(id >> ID_DAY_SHIFT);
	int64_t idx = (int64_t)(id & ID_INDEX_MASK) - 1;
	struct views *vs = store_views();
	struct rec r;

	*views = vs;
	for (size_t i = 0; i < vs->n; i++) {
		struct seg_view *v = &vs->v[i];
		if (v->day != day) {
			continue;
		}

		seg_open(v);
		if (v->empty || idx < 0 || (size_t)idx >= v->nrec) {
			return 0;
		}

		if ((size_t)idx >= v->nflushed) {
			make_record(v, (size_t)idx, &v->pending[(size_t)idx - v->nflushed], out);
			return 1;
		}

		block_reset(&blk, (size_t)idx, 1);
		if (!block_load_all(v, &blk)) {
			return 0;
		}

		decode_rec(&blk, 0, &r);
		make_record(v, (size_t)idx, &r, out);
		return 1;
	}

	return 0;
}
