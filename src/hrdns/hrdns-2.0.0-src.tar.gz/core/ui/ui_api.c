#define _GNU_SOURCE

#include "ui.h"

#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/statvfs.h>
#include <unistd.h>

#define RESOLVER_TIMEOUT_MS 5000
#define COUNT_BUDGET_MS 3000
#define STATS_MAX_AGE_MS 1000
#define CONTROL_TYPE 1
#define CONTROL_PAUSE 1
#define CONTROL_RESUME 2
#define CONTROL_LEVEL 3
#define MAX_TOP 1000

static const char *const log_levels[] = {"debug", "info", "notice", "warn", "error", "fatal", "off"};
static const char *const security_names[] = {"Unknown", "Not Applicable", "Verify Failed", "Insecure", "Secure"};

static struct api_options opts;

static struct {
	int64_t at;
	int valid;
	double cache_hit_rate;
	double avg_time;
	int64_t cache_number;
	int64_t cache_memsize;
	uint64_t lost;
} stats_cache;

struct api_error {
	int status;
	struct buf msg;
};

void api_init(const struct api_options *o)
{
	opts = *o;
}

static void headers_json(struct http_response *resp)
{
	resp_header(resp, "Content-Type", "application/json");
	resp_header(resp, "Cache-Control", "no-cache");
}

static void write_json(struct http_response *resp, int status, struct buf *body)
{
	resp->status = status;
	headers_json(resp);
	buf_add(&resp->body, body->data, body->len);
	buf_free(body);
}

static void write_error(struct http_response *resp, int status, const char *msg)
{
	struct buf b = {0};
	buf_str(&b, "{\"error\":");
	json_cstr(&b, msg);
	buf_byte(&b, '}');
	write_json(resp, status, &b);
}

static void write_no_content(struct http_response *resp)
{
	resp->status = 204;
	headers_json(resp);
}

static void bad_param(struct http_response *resp)
{
	write_error(resp, 400, "Invalid parameter.");
}

static int call(const char *command, struct buf *data, struct http_response *resp)
{
	struct buf err = {0};
	int ret = link_call(command, RESOLVER_TIMEOUT_MS, data, &err);
	if (ret != 0 && resp != NULL) {
		write_error(resp, 500, err.data);
	}

	buf_free(&err);
	return ret;
}

static int parse_uint(const char *s, uint64_t max, uint64_t *out)
{
	uint64_t v = 0;

	if (*s == '\0') {
		return -1;
	}

	for (; *s; s++) {
		if (*s < '0' || *s > '9') {
			return -1;
		}

		unsigned d = (unsigned)(*s - '0');
		if (v > (max - d) / 10) {
			return -1;
		}

		v = v * 10 + d;
	}

	*out = v;
	return 0;
}

static int p_u64(const struct http_request *r, const char *key, uint64_t *v, int *has)
{
	struct buf raw = {0};
	int ret = 0;

	*has = http_query(r, key, &raw);
	if (*has && parse_uint(raw.data, UINT64_MAX, v) != 0) {
		ret = -1;
	}

	buf_free(&raw);
	return ret;
}

static int p_u64_default(const struct http_request *r, const char *key, uint64_t def, uint64_t *v)
{
	int has = 0;
	if (p_u64(r, key, v, &has) != 0) {
		return -1;
	}

	if (!has) {
		*v = def;
	}

	return 0;
}

static int p_tri(const struct http_request *r, const char *key, enum tri *out)
{
	struct buf raw = {0};
	int ret = 0;

	*out = TRI_ANY;
	if (http_query(r, key, &raw)) {
		if (strcmp(raw.data, "true") == 0) {
			*out = TRI_YES;
		} else if (strcmp(raw.data, "false") == 0) {
			*out = TRI_NO;
		} else {
			ret = -1;
		}
	}

	buf_free(&raw);
	return ret;
}

static int level_index(const char *name, size_t len)
{
	char lower[16];

	if (len >= sizeof(lower)) {
		return -1;
	}

	for (size_t i = 0; i < len; i++) {
		lower[i] = (char)tolower((unsigned char)name[i]);
	}

	lower[len] = '\0';
	for (size_t i = 0; i < sizeof(log_levels) / sizeof(log_levels[0]); i++) {
		if (strcmp(log_levels[i], lower) == 0) {
			return (int)i;
		}
	}

	return -1;
}

static void resolver_stats(void)
{
	struct buf data = {0};
	struct jval v;
	int64_t now = now_ms();

	if (stats_cache.valid && now - stats_cache.at < STATS_MAX_AGE_MS) {
		return;
	}

	memset(&stats_cache, 0, sizeof(stats_cache));
	if (call("stats", &data, NULL) == 0 && json_parse(data.data, data.len, &v) == 0) {
		json_as_double(json_get(&v, "cache_hit_rate"), &stats_cache.cache_hit_rate);
		json_as_double(json_get(&v, "avg_time"), &stats_cache.avg_time);
		json_as_i64(json_get(&v, "cache_number"), &stats_cache.cache_number);
		json_as_i64(json_get(&v, "cache_memsize"), &stats_cache.cache_memsize);
		json_as_u64(json_get(&v, "lost"), &stats_cache.lost);
		json_free(&v);
	}

	buf_free(&data);
	stats_cache.valid = 1;
	stats_cache.at = now;
}

static uint64_t resident_bytes(pid_t pid)
{
	char path[64];
	struct buf data = {0};
	unsigned long long size = 0;
	unsigned long long resident = 0;

	snprintf(path, sizeof(path), "/proc/%d/statm", (int)pid);
	if (read_file(path, &data) != 0 || sscanf(data.data, "%llu %llu", &size, &resident) != 2) {
		buf_free(&data);
		return 0;
	}

	buf_free(&data);
	return (uint64_t)resident * (uint64_t)sysconf(_SC_PAGESIZE);
}

void api_metrics_json(struct buf *b)
{
	uint64_t total = 0;
	uint64_t blocked = 0;
	uint64_t failed = 0;

	store_totals(&total, &blocked, &failed);
	resolver_stats();
	buf_str(b, "{\"avg_query_time\":");
	json_float(b, stats_cache.avg_time);
	buf_str(b, ",\"block_query_count\":");
	json_u64(b, blocked);
	buf_str(b, ",\"cache_hit_rate\":");
	json_float(b, stats_cache.cache_hit_rate);
	buf_str(b, ",\"cache_memory_size\":");
	json_i64(b, stats_cache.cache_memsize);
	buf_str(b, ",\"cache_number\":");
	json_i64(b, stats_cache.cache_number);
	buf_str(b, ",\"fail_query_count\":");
	json_u64(b, failed);
	buf_str(b, ",\"is_metrics_suspended\":false,\"memory_usage\":");
	json_u64(b, resident_bytes(opts.resolver_pid));
	buf_str(b, ",\"qps\":");
	json_u64(b, store_rate());
	buf_str(b, ",\"request_drop_count\":");
	json_u64(b, stats_cache.lost);
	buf_str(b, ",\"total_query_count\":");
	json_u64(b, total);
	buf_byte(b, '}');
}

static void h_version(struct http_response *resp)
{
	struct buf b = {0};
	buf_str(&b, "{\"smartdns\":");
	json_cstr(&b, link_hello()->build);
	buf_str(&b, ",\"smartdns_ui\":");
	json_cstr(&b, SMARTDNS_VERION);
	buf_byte(&b, '}');
	write_json(resp, 200, &b);
}

static void h_overview(struct http_response *resp)
{
	struct statvfs sv;
	struct buf b = {0};
	uint64_t free_bytes = 0;

	if (statvfs(opts.data_dir, &sv) == 0) {
		free_bytes = (uint64_t)sv.f_bavail * (uint64_t)sv.f_bsize;
	}

	buf_str(&b, "{\"database_size\":");
	json_i64(&b, store_log_bytes());
	buf_str(&b, ",\"free_disk_space\":");
	json_u64(&b, free_bytes);
	buf_str(&b, ",\"is_process_suspended\":false,\"server_name\":");
	json_cstr(&b, link_hello()->server_name);
	buf_str(&b, ",\"startup_timestamp\":");
	json_i64(&b, link_hello()->started_ms);
	buf_byte(&b, '}');
	write_json(resp, 200, &b);
}

static void h_metrics(struct http_conn *c, const struct http_request *r, struct http_response *resp)
{
	struct buf b = {0};

	if (ws_is_upgrade(r)) {
		if (ws_accept(c, r, WS_METRICS) != 0) {
			write_error(resp, 400, "Need websocket upgrade.");
			return;
		}

		resp->upgraded = 1;
		return;
	}

	api_metrics_json(&b);
	write_json(resp, 200, &b);
}

static void h_stream(struct http_conn *c, const struct http_request *r, struct http_response *resp, enum ws_kind kind)
{
	if (ws_accept(c, r, kind) != 0) {
		write_error(resp, 400, "Need websocket upgrade.");
		return;
	}

	resp->upgraded = 1;
}

static void h_refresh(struct http_response *resp)
{
	store_refresh_tops();
	write_no_content(resp);
}

static void write_buckets(struct http_response *resp, const char *list_key, const char *label_key, int daily, struct bucket *list, size_t n,
						  int64_t now)
{
	struct buf b = {0};
	char label[96];

	buf_fmt(&b, "{\"%s\":[", list_key);
	for (size_t i = 0; i < n; i++) {
		bucket_label(list[i].key, daily, label);
		buf_fmt(&b, "%s{\"%s\":", i ? "," : "", label_key);
		json_cstr(&b, label);
		buf_str(&b, ",\"query_count\":");
		json_u64(&b, list[i].count);
		buf_byte(&b, '}');
	}

	buf_str(&b, "],\"query_timestamp\":");
	json_i64(&b, now);
	buf_byte(&b, '}');
	write_json(resp, 200, &b);
}

static void h_hourly(const struct http_request *r, struct http_response *resp)
{
	uint64_t hours = 0;
	struct bucket *list = NULL;

	if (p_u64_default(r, "past_hours", 24, &hours) != 0 || hours == 0 || hours > 24 * 400) {
		bad_param(resp);
		return;
	}

	int64_t now = now_ms();
	size_t n = store_hourly((int)hours, now, &list);
	write_buckets(resp, "hourly_query_count", "hour", 0, list, n, now);
	free(list);
}

static void h_daily(const struct http_request *r, struct http_response *resp)
{
	uint64_t days = 0;
	struct bucket *list = NULL;

	if (p_u64_default(r, "past_days", 30, &days) != 0 || days == 0 || days > 400) {
		bad_param(resp);
		return;
	}

	int64_t now = now_ms();
	size_t n = store_daily((int)days, now, &list);
	write_buckets(resp, "daily_query_count", "day", 1, list, n, now);
	free(list);
}

static void h_top_client(const struct http_request *r, struct http_response *resp)
{
	uint64_t count = 0;
	struct top_client *list = NULL;
	int64_t start = 0;
	int64_t end = 0;
	struct buf b = {0};

	if (p_u64_default(r, "count", 10, &count) != 0) {
		bad_param(resp);
		return;
	}

	size_t n = store_top_clients(count < MAX_TOP ? (size_t)count : MAX_TOP, &list, &start, &end);
	buf_str(&b, "{\"client_top_list\":[");
	for (size_t i = 0; i < n; i++) {
		char addr[ADDR_STR_LEN];
		char mac[MAC_STR_LEN];
		const uint8_t *k = list[i].key;
		format_addr(k[0], k + 1, addr);
		buf_str(&b, i ? ",{\"client_ip\":" : "{\"client_ip\":");
		json_cstr(&b, addr);
		if (!mac_is_zero(k + 1 + ADDR_LEN)) {
			format_mac(k + 1 + ADDR_LEN, mac);
			buf_str(&b, ",\"client_mac\":");
			json_cstr(&b, mac);
		}

		buf_str(&b, ",\"query_count\":");
		json_u64(&b, list[i].count);
		buf_str(&b, ",\"blocked_count\":");
		json_u64(&b, list[i].blocked);
		buf_str(&b, ",\"failed_count\":");
		json_u64(&b, list[i].failed);
		buf_str(&b, ",\"last_timestamp\":");
		json_i64(&b, list[i].last);
		buf_str(&b, ",\"timestamp_end\":");
		json_i64(&b, end);
		buf_str(&b, ",\"timestamp_start\":");
		json_i64(&b, start);
		buf_byte(&b, '}');
	}

	store_tops_release();
	buf_str(&b, "]}");
	write_json(resp, 200, &b);
}

static void h_top_domain(const struct http_request *r, struct http_response *resp)
{
	uint64_t count = 0;
	struct top_name *list = NULL;
	struct buf blocked = {0};
	int64_t start = 0;
	int64_t end = 0;
	struct buf b = {0};

	if (p_u64_default(r, "count", 10, &count) != 0) {
		bad_param(resp);
		return;
	}

	int is_blocked = http_query(r, "is_blocked", &blocked) && strcmp(blocked.data, "true") == 0;
	buf_free(&blocked);
	size_t n = store_top_domains(count < MAX_TOP ? (size_t)count : MAX_TOP, is_blocked, &list, &start, &end);
	buf_str(&b, "{\"domain_top_list\":[");
	for (size_t i = 0; i < n; i++) {
		buf_str(&b, i ? ",{\"domain\":" : "{\"domain\":");
		json_str(&b, list[i].name, list[i].len);
		buf_str(&b, ",\"query_count\":");
		json_u64(&b, list[i].count);
		buf_str(&b, ",\"timestamp_end\":");
		json_i64(&b, end);
		buf_str(&b, ",\"timestamp_start\":");
		json_i64(&b, start);
		buf_byte(&b, '}');
	}

	store_tops_release();
	buf_str(&b, "]}");
	write_json(resp, 200, &b);
}

static void record_json(struct buf *b, const struct record *rec)
{
	char mac[MAC_STR_LEN];

	buf_str(b, "{\"client\":");
	json_cstr(b, rec->client);
	if (!mac_is_zero(rec->mac)) {
		format_mac(rec->mac, mac);
		buf_str(b, ",\"client_mac\":");
		json_cstr(b, mac);
	}

	buf_str(b, ",\"domain\":");
	json_str(b, rec->domain, rec->domain_len);
	buf_str(b, ",\"domain_group\":");
	json_str(b, rec->group, rec->group_len);
	buf_str(b, ",\"domain_type\":");
	json_u64(b, rec->qtype);
	buf_str(b, ",\"id\":");
	json_u64(b, rec->id);
	buf_str(b, ",\"is_blocked\":");
	json_bool(b, rec->blocked);
	if (rec->block_list != 0) {
		buf_str(b, ",\"block_list\":");
		json_u64(b, rec->block_list);
	}

	buf_str(b, ",\"is_cached\":");
	json_bool(b, rec->cached);
	buf_str(b, ",\"ping_time\":");
	json_float(b, (double)rec->ping_tenths / 10);
	buf_str(b, ",\"query_time\":");
	json_u64(b, rec->query_ms);
	buf_str(b, ",\"reply_code\":");
	json_u64(b, rec->rcode);
	buf_str(b, ",\"timestamp\":");
	json_i64(b, rec->time_ms);
	buf_byte(b, '}');
}

static uint64_t total_pages(uint64_t total, uint64_t size)
{
	return total / size + (total % size != 0);
}

struct filter_strings {
	struct buf domain;
	struct buf mode;
	struct buf client;
	struct buf group;
};

static void filter_strings_free(struct filter_strings *fs)
{
	buf_free(&fs->domain);
	buf_free(&fs->mode);
	buf_free(&fs->client);
	buf_free(&fs->group);
}

static const char *or_empty(const struct buf *b)
{
	return b->data != NULL ? b->data : "";
}

static int parse_page(const struct http_request *r, struct page_spec *spec, uint64_t *id, int *has_id, struct http_response *resp)
{
	struct buf raw = {0};
	int has = 0;
	uint64_t total = 0;

	memset(spec, 0, sizeof(*spec));
	if (p_u64_default(r, "page_num", 1, &spec->num) != 0 || p_u64_default(r, "page_size", 10, &spec->size) != 0) {
		bad_param(resp);
		return -1;
	}

	if (spec->num == 0 || spec->size == 0) {
		write_error(resp, 400, "Invalid parameter: page_num or page_size");
		return -1;
	}

	if (http_query(r, "order", &raw)) {
		if (strcmp(raw.data, "asc") == 0 || strcmp(raw.data, "ASC") == 0) {
			spec->asc = 1;
		} else if (strcmp(raw.data, "desc") != 0 && strcmp(raw.data, "DESC") != 0) {
			buf_free(&raw);
			write_error(resp, 400, "order param error");
			return -1;
		}
	}

	if (p_u64(r, "id", id, has_id) != 0 || p_u64(r, "cursor", &spec->cursor, &spec->has_cursor) != 0) {
		buf_free(&raw);
		bad_param(resp);
		return -1;
	}

	if (http_query(r, "cursor_direction", &raw)) {
		if (strcmp(raw.data, "prev") == 0) {
			spec->prev = 1;
		} else if (raw.data[0] != '\0' && strcmp(raw.data, "next") != 0) {
			buf_free(&raw);
			write_error(resp, 400, "cursor direction param error");
			return -1;
		}
	}

	buf_free(&raw);
	if (p_u64(r, "total_count", &total, &has) != 0) {
		bad_param(resp);
		return -1;
	}

	spec->total = total;
	spec->total_given = has || spec->has_cursor;
	return 0;
}

static int parse_filter(const struct http_request *r, struct filter *f, struct filter_strings *fs, struct http_response *resp)
{
	struct buf raw = {0};
	uint64_t v = 0;
	int has = 0;

	memset(f, 0, sizeof(*f));
	http_query(r, "domain", &fs->domain);
	http_query(r, "domain_filter_mode", &fs->mode);
	f->domain = or_empty(&fs->domain);
	f->domain_mode = or_empty(&fs->mode);
	if (strcmp(f->domain_mode, "equals") == 0) {
		f->domain_mode = "";
	} else if (f->domain_mode[0] != '\0' && strcmp(f->domain_mode, "contains") != 0 && strcmp(f->domain_mode, "notempty") != 0) {
		write_error(resp, 400, "domain_filter_mode param error");
		return -1;
	}

	if (http_query(r, "domain_type", &raw)) {
		if (parse_uint(raw.data, 0xFFFF, &v) != 0) {
			buf_free(&raw);
			bad_param(resp);
			return -1;
		}

		f->qtype = (int)v;
		f->has_qtype = 1;
	}

	http_query(r, "client", &fs->client);
	f->client = or_empty(&fs->client);
	f->has_group = http_query(r, "domain_group", &fs->group);
	f->group = or_empty(&fs->group);
	if (http_query(r, "reply_code", &raw)) {
		if (parse_uint(raw.data, 0xFF, &v) != 0) {
			buf_free(&raw);
			bad_param(resp);
			return -1;
		}

		f->rcode = (int)v;
		f->has_rcode = 1;
	}

	buf_free(&raw);
	if (p_tri(r, "is_blocked", &f->blocked) != 0 || p_tri(r, "is_cached", &f->cached) != 0 ||
		p_u64(r, "timestamp_after", &v, &has) != 0) {
		bad_param(resp);
		return -1;
	}

	f->after = has ? (int64_t)v : 0;
	if (p_u64(r, "timestamp_before", &v, &has) != 0) {
		bad_param(resp);
		return -1;
	}

	f->before = has ? (int64_t)v : 0;
	return 0;
}

static void write_page(struct http_response *resp, struct buf *list, size_t count, int step, uint64_t total, uint64_t size)
{
	struct buf b = {0};
	buf_str(&b, "{\"domain_list\":[");
	buf_add(&b, list->data, list->len);
	buf_free(list);
	buf_str(&b, "],\"list_count\":");
	json_u64(&b, count);
	buf_str(&b, ",\"step_by_cursor\":");
	json_bool(&b, step);
	buf_str(&b, ",\"total_count\":");
	json_u64(&b, total);
	buf_str(&b, ",\"total_page\":");
	json_u64(&b, total_pages(total, size));
	buf_byte(&b, '}');
	write_json(resp, 200, &b);
}

static void h_domain_list(const struct http_request *r, struct http_response *resp)
{
	struct page_spec spec;
	struct filter f;
	struct filter_strings fs = {0};
	struct buf list = {0};
	uint64_t id = 0;
	int has_id = 0;

	if (parse_page(r, &spec, &id, &has_id, resp) != 0) {
		return;
	}

	if (parse_filter(r, &f, &fs, resp) != 0) {
		filter_strings_free(&fs);
		return;
	}

	if (has_id) {
		struct record rec;
		struct views *vs = NULL;
		int found = store_get(id, &rec, &vs);
		if (found) {
			record_json(&list, &rec);
		}

		views_release(vs);
		write_page(resp, &list, (size_t)found, 0, (uint64_t)found, spec.size);
		filter_strings_free(&fs);
		return;
	}

	struct list_result res;
	store_list(&f, &spec, COUNT_BUDGET_MS, &res);
	for (size_t i = 0; i < res.count; i++) {
		if (i > 0) {
			buf_byte(&list, ',');
		}

		record_json(&list, &res.records[i]);
	}

	write_page(resp, &list, res.count, res.step_by_cursor, res.total, spec.size);
	store_list_free(&res);
	filter_strings_free(&fs);
}

static void count_json(struct http_response *resp, uint64_t n)
{
	struct buf b = {0};
	buf_str(&b, "{\"count\":");
	json_u64(&b, n);
	buf_byte(&b, '}');
	write_json(resp, 200, &b);
}

static void empty_filter(struct filter *f)
{
	memset(f, 0, sizeof(*f));
	f->domain = "";
	f->domain_mode = "";
	f->client = "";
	f->group = "";
}

static void h_domain_count(struct http_response *resp)
{
	struct filter f;
	int complete = 0;

	empty_filter(&f);
	count_json(resp, store_count(&f, 0, &complete));
}

static void h_domain_get(const char *raw, struct http_response *resp)
{
	uint64_t id = 0;
	struct record rec;
	struct views *vs = NULL;
	struct buf b = {0};

	if (parse_uint(raw, UINT64_MAX, &id) != 0) {
		bad_param(resp);
		return;
	}

	if (!store_get(id, &rec, &vs)) {
		views_release(vs);
		write_error(resp, 404, "Not found");
		return;
	}

	record_json(&b, &rec);
	views_release(vs);
	write_json(resp, 200, &b);
}

static void h_domain_clear(const struct http_request *r, struct http_response *resp)
{
	struct filter f;
	struct page_spec spec = {.num = 1, .size = 1};
	struct list_result res;
	uint64_t before = 0;
	int has = 0;
	int complete = 0;
	char err[512];

	if (p_u64(r, "timestamp_before", &before, &has) != 0 || !has) {
		bad_param(resp);
		return;
	}

	empty_filter(&f);
	uint64_t n = store_count(&f, 0, &complete);
	if (n == 0) {
		write_error(resp, 404, "Not found");
		return;
	}

	store_list(&f, &spec, 0, &res);
	int partial = res.count == 1 && (int64_t)before < res.records[0].time_ms;
	store_list_free(&res);
	if (partial) {
		write_error(resp, 400, "Only a full clear is supported.");
		return;
	}

	if (store_clear(err, sizeof(err)) != 0) {
		write_error(resp, 500, err);
		return;
	}

	count_json(resp, n);
}

static void h_raw(const char *command, struct http_response *resp)
{
	struct buf data = {0};

	if (call(command, &data, resp) != 0) {
		return;
	}

	resp->status = 200;
	headers_json(resp);
	buf_add(&resp->body, data.data, data.len);
	buf_free(&data);
}

static int field_i64(const struct jval *obj, const char *key, int64_t *out)
{
	*out = 0;
	return json_as_i64(json_get(obj, key), out);
}

static int field_u64(const struct jval *obj, const char *key, uint64_t *out)
{
	*out = 0;
	return json_as_u64(json_get(obj, key), out);
}

static int field_str(const struct jval *obj, const char *key, const char **s, size_t *len)
{
	const struct jval *v = json_get(obj, key);
	*s = "";
	*len = 0;
	if (v == NULL || v->type == J_NULL) {
		return 0;
	}

	if (v->type != J_STR) {
		return -1;
	}

	*s = v->str;
	*len = v->len;
	return 0;
}

static int field_bool(const struct jval *obj, const char *key, int *out)
{
	const struct jval *v = json_get(obj, key);
	*out = 0;
	if (v == NULL || v->type == J_NULL) {
		return 0;
	}

	if (v->type != J_BOOL) {
		return -1;
	}

	*out = v->boolean;
	return 0;
}

static int field_double(const struct jval *obj, const char *key, double *out)
{
	*out = 0;
	return json_as_double(json_get(obj, key), out);
}

static void h_cache_domains(struct http_response *resp)
{
	struct buf data = {0};
	struct jval v;
	struct buf b = {0};

	if (call("cache.list", &data, resp) != 0) {
		return;
	}

	if (json_parse(data.data, data.len, &v) != 0 || (v.type != J_ARR && v.type != J_NULL)) {
		buf_free(&data);
		write_error(resp, 500, "json: cannot unmarshal cache list");
		return;
	}

	buf_str(&b, "{\"domains\":[");
	for (size_t i = 0; i < v.count; i++) {
		const struct jval *e = &v.items[i];
		const char *domain = NULL;
		size_t dlen = 0;
		int64_t qtype = 0;
		int64_t ttl = 0;
		int64_t t = 0;
		if (field_str(e, "domain", &domain, &dlen) != 0 || field_i64(e, "qtype", &qtype) != 0 || field_i64(e, "ttl", &ttl) != 0 ||
			field_i64(e, "time", &t) != 0) {
			json_free(&v);
			buf_free(&data);
			buf_free(&b);
			write_error(resp, 500, "json: cannot unmarshal cache list");
			return;
		}

		buf_str(&b, i ? ",{\"cached_time\":" : "{\"cached_time\":");
		json_i64(&b, t);
		buf_str(&b, ",\"domain\":");
		json_str(&b, domain, dlen);
		buf_str(&b, ",\"id\":");
		json_u64(&b, i + 1);
		buf_str(&b, ",\"qtype\":");
		json_i64(&b, qtype);
		buf_str(&b, ",\"ttl_remaining\":");
		json_i64(&b, ttl);
		buf_byte(&b, '}');
	}

	buf_str(&b, "]}");
	json_free(&v);
	buf_free(&data);
	write_json(resp, 200, &b);
}

static double round1(double v)
{
	return round(v * 10) / 10;
}

static void h_upstream(struct http_response *resp)
{
	struct buf data = {0};
	struct jval v;
	struct buf b = {0};

	if (call("servers", &data, resp) != 0) {
		return;
	}

	if (json_parse(data.data, data.len, &v) != 0 || (v.type != J_ARR && v.type != J_NULL)) {
		buf_free(&data);
		write_error(resp, 500, "json: cannot unmarshal server list");
		return;
	}

	buf_str(&b, "{\"upstream_server_list\":[");
	for (size_t i = 0; i < v.count; i++) {
		const struct jval *e = &v.items[i];
		const char *host = NULL;
		const char *ip = NULL;
		const char *type = NULL;
		const char *iface = NULL;
		size_t host_len = 0;
		size_t ip_len = 0;
		size_t type_len = 0;
		size_t iface_len = 0;
		int64_t port = 0;
		int64_t security = 0;
		int fallback = 0;
		int exclude = 0;
		int alive = 0;
		uint64_t total = 0;
		uint64_t success = 0;
		uint64_t recv = 0;
		double avg = 0;

		if (field_str(e, "host", &host, &host_len) != 0 || field_str(e, "ip", &ip, &ip_len) != 0 || field_i64(e, "port", &port) != 0 ||
			field_str(e, "type", &type, &type_len) != 0 || field_str(e, "iface", &iface, &iface_len) != 0 ||
			field_bool(e, "fallback", &fallback) != 0 || field_bool(e, "exclude_default", &exclude) != 0 ||
			field_bool(e, "alive", &alive) != 0 || field_i64(e, "security", &security) != 0 || field_u64(e, "total", &total) != 0 ||
			field_u64(e, "success", &success) != 0 || field_u64(e, "recv", &recv) != 0 || field_double(e, "avg_time", &avg) != 0) {
			json_free(&v);
			buf_free(&data);
			buf_free(&b);
			write_error(resp, 500, "json: cannot unmarshal server list");
			return;
		}

		const char *status = total == 0 ? "Unknown" : alive ? "Normal" : "Abnormal";
		double rate = total > 0 ? round1((double)success / (double)total * 100) : 0;
		const char *sec = security >= 0 && security < 5 ? security_names[security] : security_names[0];

		buf_str(&b, i ? ",{\"avg_time\":" : "{\"avg_time\":");
		json_float(&b, round1(avg));
		buf_str(&b, ",\"exclude_default\":");
		json_bool(&b, exclude);
		buf_str(&b, ",\"fallback\":");
		json_bool(&b, fallback);
		buf_str(&b, ",\"host\":");
		json_str(&b, host, host_len);
		buf_str(&b, ",\"iface\":");
		json_str(&b, iface, iface_len);
		buf_str(&b, ",\"ip\":");
		json_str(&b, ip, ip_len);
		buf_str(&b, ",\"port\":");
		json_i64(&b, port);
		buf_str(&b, ",\"query_success_rate\":");
		json_float(&b, rate);
		buf_str(&b, ",\"security\":");
		json_cstr(&b, sec);
		buf_str(&b, ",\"server_type\":");
		json_str(&b, type, type_len);
		buf_str(&b, ",\"status\":");
		json_cstr(&b, status);
		buf_str(&b, ",\"total_query_count\":");
		json_u64(&b, total);
		buf_str(&b, ",\"total_query_recv_count\":");
		json_u64(&b, recv);
		buf_str(&b, ",\"total_query_success\":");
		json_u64(&b, success);
		buf_byte(&b, '}');
	}

	buf_str(&b, "]}");
	json_free(&v);
	buf_free(&data);
	write_json(resp, 200, &b);
}

static int current_level(void)
{
	struct buf data = {0};
	struct jval v;
	int64_t level = -1;

	if (call("log.get", &data, NULL) != 0 || json_parse(data.data, data.len, &v) != 0) {
		buf_free(&data);
		return -1;
	}

	if (json_as_i64(json_get(&v, "log_level"), &level) != 0) {
		level = -1;
	}

	json_free(&v);
	buf_free(&data);
	return (int)level;
}

static void h_log_level_get(struct http_response *resp)
{
	struct buf data = {0};
	struct jval v;
	int64_t level = 0;
	struct buf b = {0};

	if (call("log.get", &data, resp) != 0) {
		return;
	}

	int ok = json_parse(data.data, data.len, &v) == 0 && (v.type == J_OBJ || v.type == J_NULL) &&
			 json_as_i64(json_get(&v, "log_level"), &level) == 0 && level >= 0 &&
			 level < (int64_t)(sizeof(log_levels) / sizeof(log_levels[0]));
	json_free(&v);

	buf_free(&data);
	if (!ok) {
		write_error(resp, 500, "resolver returned an unknown log level");
		return;
	}

	buf_str(&b, "{\"log_level\":");
	json_cstr(&b, log_levels[level]);
	buf_byte(&b, '}');
	write_json(resp, 200, &b);
}

static int set_level(int level, struct http_response *resp)
{
	char command[32];
	struct buf data = {0};

	snprintf(command, sizeof(command), "log.set %d", level);
	int ret = call(command, &data, resp);
	buf_free(&data);
	return ret;
}

static void h_log_level_put(const struct http_request *r, struct http_response *resp)
{
	struct jval v;
	const char *name = NULL;
	size_t len = 0;
	int level = -1;

	if (r->body_len <= 1024 && json_parse(r->body, r->body_len, &v) == 0) {
		if ((v.type == J_OBJ || v.type == J_NULL) && field_str(&v, "log_level", &name, &len) == 0) {
			level = level_index(name, len);
		}

		json_free(&v);
	}

	if (level < 0) {
		write_error(resp, 400, "log level is invalid");
		return;
	}

	if (set_level(level, resp) != 0) {
		return;
	}

	write_no_content(resp);
}

static void h_command(const char *command, struct http_response *resp)
{
	struct buf data = {0};
	if (call(command, &data, resp) == 0) {
		write_no_content(resp);
	}

	buf_free(&data);
}

static int is_get(const char *method)
{
	return strcmp(method, "GET") == 0 || strcmp(method, "HEAD") == 0;
}

void api_handle(struct http_conn *c, const struct http_request *r, struct http_response *resp)
{
	const char *p = r->path;
	const char *m = r->method;

	if (is_get(m) && strcmp(p, "/api/server/version") == 0) {
		h_version(resp);
	} else if (is_get(m) && strcmp(p, "/api/stats/overview") == 0) {
		h_overview(resp);
	} else if (is_get(m) && strcmp(p, "/api/stats/metrics") == 0) {
		h_metrics(c, r, resp);
	} else if (is_get(m) && strcmp(p, "/api/log/stream") == 0) {
		h_stream(c, r, resp, WS_LOG);
	} else if (is_get(m) && strcmp(p, "/api/log/audit/stream") == 0) {
		h_stream(c, r, resp, WS_AUDIT);
	} else if (strcmp(m, "PUT") == 0 && strcmp(p, "/api/stats/refresh") == 0) {
		h_refresh(resp);
	} else if (is_get(m) && strcmp(p, "/api/stats/hourly-query-count") == 0) {
		h_hourly(r, resp);
	} else if (is_get(m) && strcmp(p, "/api/stats/daily-query-count") == 0) {
		h_daily(r, resp);
	} else if (is_get(m) && strcmp(p, "/api/stats/top/client") == 0) {
		h_top_client(r, resp);
	} else if (is_get(m) && strcmp(p, "/api/stats/top/domain") == 0) {
		h_top_domain(r, resp);
	} else if (is_get(m) && strcmp(p, "/api/domain") == 0) {
		h_domain_list(r, resp);
	} else if (is_get(m) && strcmp(p, "/api/domain/count") == 0) {
		h_domain_count(resp);
	} else if (is_get(m) && strncmp(p, "/api/domain/", 12) == 0 && p[12] != '\0' && strchr(p + 12, '/') == NULL) {
		h_domain_get(p + 12, resp);
	} else if (strcmp(m, "DELETE") == 0 && strcmp(p, "/api/domain") == 0) {
		h_domain_clear(r, resp);
	} else if (is_get(m) && strcmp(p, "/api/cache/count") == 0) {
		h_raw("cache.count", resp);
	} else if (is_get(m) && strcmp(p, "/api/cache/domains") == 0) {
		h_cache_domains(resp);
	} else if (strcmp(m, "PUT") == 0 && strcmp(p, "/api/cache/flush") == 0) {
		h_raw("cache.flush", resp);
	} else if (is_get(m) && strcmp(p, "/api/upstream-server") == 0) {
		h_upstream(resp);
	} else if (is_get(m) && strcmp(p, "/api/log/level") == 0) {
		h_log_level_get(resp);
	} else if (strcmp(m, "PUT") == 0 && strcmp(p, "/api/log/level") == 0) {
		h_log_level_put(r, resp);
	} else if (strcmp(m, "PUT") == 0 && strcmp(p, "/api/service/restart") == 0) {
		h_command("restart", resp);
	} else {
		write_error(resp, 404, "API not found.");
	}
}

void api_ws_opened(struct http_conn *c)
{
	struct buf b = {0};

	switch (c->ws_kind) {
	case WS_METRICS:
		api_metrics_json(&b);
		ws_send(c, WS_TEXT, b.data, b.len);
		buf_free(&b);
		c->next_metrics = now_ms() + 1000;
		break;
	case WS_LOG:
		link_acquire(1, 0);
		c->prev_level = current_level();
		c->hub_seq = hub_subscribe(HUB_LOG);
		break;
	case WS_AUDIT:
		link_acquire(0, 1);
		c->hub_seq = hub_subscribe(HUB_AUDIT);
		break;
	}
}

void api_ws_message(struct http_conn *c, const uint8_t *data, size_t len)
{
	if (c->ws_kind == WS_METRICS || len < 2 || data[0] != CONTROL_TYPE) {
		return;
	}

	switch (data[1]) {
	case CONTROL_PAUSE:
		c->paused = 1;
		break;
	case CONTROL_RESUME:
		c->paused = 0;
		break;
	default:
		if (c->ws_kind == WS_LOG && len >= 3 && data[1] == CONTROL_LEVEL) {
			int level = level_index((const char *)data + 2, len - 2);
			if (level >= 0) {
				set_level(level, NULL);
			}
		}
	}
}

void api_ws_closed(struct http_conn *c)
{
	switch (c->ws_kind) {
	case WS_METRICS:
		break;
	case WS_LOG:
		hub_unsubscribe(HUB_LOG);
		if (c->prev_level >= 0) {
			set_level(c->prev_level, NULL);
		}

		link_release(1, 0);
		break;
	case WS_AUDIT:
		hub_unsubscribe(HUB_AUDIT);
		link_release(0, 1);
		break;
	}
}
