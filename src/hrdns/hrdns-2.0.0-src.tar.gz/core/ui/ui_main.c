#define _GNU_SOURCE

#include "ui.h"

#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/eventfd.h>
#include <sys/prctl.h>
#include <sys/signalfd.h>
#include <time.h>
#include <unistd.h>

#define BRIDGE_FD 3
#define ZONE_FILE "/var/TZ"
#define DEFAULT_LISTEN "unix:/var/run/hrdns-ui.sock"
#define DEFAULT_DATA "/opt/etc/HydraRoute/dns"

struct flags {
	const char *listen;
	const char *data;
	long days;
	long max_mb;
	long flush;
	int version;
};

static int parse_long(const char *name, const char *value, long *out)
{
	char *end = NULL;

	errno = 0;
	*out = strtol(value, &end, 0);
	if (errno != 0 || *value == '\0' || *end != '\0') {
		fprintf(stderr, "invalid value \"%s\" for flag -%s: parse error\n", value, name);
		return -1;
	}

	return 0;
}

static int parse_flags(int argc, char *argv[], struct flags *f)
{
	for (int i = 1; i < argc; i++) {
		const char *arg = argv[i];
		const char *value = NULL;
		char name[32];

		if (arg[0] != '-' || arg[1] == '\0') {
			break;
		}

		arg += arg[1] == '-' ? 2 : 1;
		const char *eq = strchr(arg, '=');
		size_t len = eq ? (size_t)(eq - arg) : strlen(arg);
		if (len == 0 || len >= sizeof(name)) {
			fprintf(stderr, "bad flag syntax: %s\n", argv[i]);
			return -1;
		}

		memcpy(name, arg, len);
		name[len] = '\0';
		if (strcmp(name, "version") == 0) {
			f->version = 1;
			continue;
		}

		if (eq != NULL) {
			value = eq + 1;
		} else if (i + 1 < argc) {
			value = argv[++i];
		} else {
			fprintf(stderr, "flag needs an argument: -%s\n", name);
			return -1;
		}

		if (strcmp(name, "listen") == 0) {
			f->listen = value;
		} else if (strcmp(name, "data") == 0) {
			f->data = value;
		} else if (strcmp(name, "days") == 0) {
			if (parse_long(name, value, &f->days) != 0) {
				return -1;
			}
		} else if (strcmp(name, "max-mb") == 0) {
			if (parse_long(name, value, &f->max_mb) != 0) {
				return -1;
			}
		} else if (strcmp(name, "flush") == 0) {
			if (parse_long(name, value, &f->flush) != 0) {
				return -1;
			}
		} else {
			fprintf(stderr, "flag provided but not defined: -%s\n", name);
			return -1;
		}
	}

	return 0;
}

static void load_zone(void)
{
	struct buf data = {0};

	if (read_file(ZONE_FILE, &data) == 0) {
		char *s = data.data;
		while (*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') {
			s++;
		}

		size_t len = strlen(s);
		while (len > 0 && (s[len - 1] == ' ' || s[len - 1] == '\t' || s[len - 1] == '\n' || s[len - 1] == '\r')) {
			s[--len] = '\0';
		}

		if (len > 0) {
			setenv("TZ", s, 1);
		}
	}

	buf_free(&data);
	tzset();
}

int hrdns_ui_main(int argc, char *argv[])
{
	struct flags f = {DEFAULT_LISTEN, DEFAULT_DATA, 7, 256, 300, 0};
	struct store_config cfg;
	struct api_options api;
	sigset_t mask;

	prctl(PR_SET_NAME, "hrdns-ui", 0, 0, 0);
	if (parse_flags(argc, argv, &f) != 0) {
		return 2;
	}

	if (f.version) {
		printf("%s\n", SMARTDNS_VERION);
		return 0;
	}

	signal(SIGPIPE, SIG_IGN);
	if (link_open(BRIDGE_FD) != 0) {
		fprintf(stderr, "bridge: cannot read hello on fd %d\n", BRIDGE_FD);
		return 1;
	}

	load_zone();
	if (strlen(f.data) >= sizeof(cfg.dir) || mkdir_all(f.data) != 0) {
		link_log(UI_LOG_WARN, "mkdir %s: %s", f.data, strerror(errno));
		return 1;
	}

	memset(&cfg, 0, sizeof(cfg));
	snprintf(cfg.dir, sizeof(cfg.dir), "%s", f.data);
	cfg.days = (int)f.days;
	cfg.max_bytes = (int64_t)f.max_mb << 20;
	cfg.flush_seconds = (int)f.flush;
	if (store_open(&cfg) != 0) {
		link_log(UI_LOG_WARN, "open journal %s: %s", f.data, strerror(errno));
		return 1;
	}

	sigemptyset(&mask);
	sigaddset(&mask, SIGTERM);
	sigaddset(&mask, SIGINT);
	pthread_sigmask(SIG_BLOCK, &mask, NULL);
	int sigfd = signalfd(-1, &mask, SFD_CLOEXEC);
	int wake = eventfd(0, EFD_CLOEXEC | EFD_NONBLOCK);
	if (sigfd < 0 || wake < 0 || link_start(wake) != 0) {
		link_log(UI_LOG_WARN, "start: %s", strerror(errno));
		store_close();
		return 1;
	}

	if (link_subscribe() != 0) {
		link_stop();
		store_close();
		link_log(UI_LOG_WARN, "resolver connection lost: subscribe failed");
		return 1;
	}

	memset(&api, 0, sizeof(api));
	snprintf(api.data_dir, sizeof(api.data_dir), "%s", f.data);
	api.resolver_pid = getppid();
	api_init(&api);
	int ret = http_serve(f.listen, f.data, wake, sigfd);
	link_stop();
	store_close();
	return ret == 0 ? 0 : 1;
}
