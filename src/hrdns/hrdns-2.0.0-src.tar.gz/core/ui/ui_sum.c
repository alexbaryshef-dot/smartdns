#define _GNU_SOURCE

#include "store.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SUM_MAGIC "SUM1"
#define DAY_TOP_LIMIT 200
#define MERGED_TOP 1000
#define TOP_WINDOW 7

struct sum_entry {
	int64_t day;
	struct day_sum *sum;
};

static pthread_mutex_t sums_mu = PTHREAD_MUTEX_INITIALIZER;
static struct sum_entry *sums;
static size_t nsums;

static pthread_mutex_t tops_mu = PTHREAD_MUTEX_INITIALIZER;
static struct {
	struct top_client *clients;
	size_t nclients;
	struct top_name *domains;
	size_t ndomains;
	struct top_name *blocked;
	size_t nblocked;
	int64_t start;
	int64_t end;
} tops;

static void free_names(struct top_name *list, size_t n)
{
	for (size_t i = 0; i < n; i++) {
		free(list[i].name);
	}

	free(list);
}

void sum_free(struct day_sum *s)
{
	if (s == NULL) {
		return;
	}

	free_names(s->domains, s->ndomains);
	free_names(s->blocked, s->nblocked);
	free(s->clients);
	free(s);
}

struct cursor {
	const uint8_t *data;
	size_t len;
	size_t off;
};

static int read_count(struct cursor *c, size_t *n)
{
	if (c->off + 2 > c->len) {
		return -1;
	}

	*n = (size_t)(c->data[c->off] | c->data[c->off + 1] << 8);
	c->off += 2;
	return 0;
}

static int read_names(struct cursor *c, struct top_name **out, size_t *count)
{
	size_t n = 0;
	if (read_count(c, &n) != 0) {
		return -1;
	}

	*out = xcalloc(n, sizeof(**out));
	*count = 0;
	for (size_t i = 0; i < n; i++) {
		if (c->off + 6 > c->len) {
			return -1;
		}

		uint64_t hits = get_u32(c->data + c->off, 0);
		size_t l = (size_t)(c->data[c->off + 4] | c->data[c->off + 5] << 8);
		c->off += 6;
		if (c->off + l > c->len) {
			return -1;
		}

		(*out)[i].name = xstrndup((const char *)c->data + c->off, l);
		(*out)[i].len = l;
		(*out)[i].count = hits;
		*count = i + 1;
		c->off += l;
	}

	return 0;
}

static int read_client_details(struct cursor *c, int64_t day, struct day_sum *s)
{
	size_t n = 0;
	if (read_count(c, &n) != 0 || n != s->nclients || c->off + n * 12 > c->len) {
		return -1;
	}

	for (size_t i = 0; i < n; i++) {
		const uint8_t *p = c->data + c->off + i * 12;
		s->clients[i].blocked = get_u32(p, 0);
		s->clients[i].failed = get_u32(p, 1);
		s->clients[i].last = day * DAY_MILLIS + get_u32(p, 2);
	}

	c->off += n * 12;
	return 0;
}

static struct day_sum *parse_sum(int64_t day, const uint8_t *data, size_t len)
{
	struct cursor c = {data, len, 4};
	size_t n = 0;

	if (len < 4 + SLOTS_PER_DAY * 4 + 4 || memcmp(data, SUM_MAGIC, 4) != 0) {
		return NULL;
	}

	struct day_sum *s = xcalloc(1, sizeof(*s));
	for (int i = 0; i < SLOTS_PER_DAY; i++) {
		s->slots[i] = get_u32(data + c.off, 0);
		c.off += 4;
	}

	if (read_names(&c, &s->domains, &s->ndomains) != 0 || read_count(&c, &n) != 0) {
		sum_free(s);
		return NULL;
	}

	s->clients = xcalloc(n, sizeof(*s->clients));
	for (size_t i = 0; i < n; i++) {
		if (c.off + 4 + CLIENT_KEY_LEN > len) {
			sum_free(s);
			return NULL;
		}

		s->clients[i].count = get_u32(data + c.off, 0);
		memcpy(s->clients[i].key, data + c.off + 4, CLIENT_KEY_LEN);
		c.off += 4 + CLIENT_KEY_LEN;
		s->nclients = i + 1;
	}

	if (c.off < len && read_names(&c, &s->blocked, &s->nblocked) != 0) {
		sum_free(s);
		return NULL;
	}

	if (c.off < len && read_client_details(&c, day, s) != 0) {
		sum_free(s);
		return NULL;
	}

	return s;
}

struct day_sum *sum_read(int64_t day)
{
	char path[600];
	struct buf data = {0};

	sum_path(day, path, sizeof(path));
	if (read_file(path, &data) != 0) {
		return NULL;
	}

	struct day_sum *s = parse_sum(day, (const uint8_t *)data.data, data.len);
	buf_free(&data);
	return s;
}

struct ranked {
	uint32_t id;
	uint32_t count;
};

static int cmp_ranked(const void *a, const void *b)
{
	const struct ranked *x = a;
	const struct ranked *y = b;
	if (x->count != y->count) {
		return x->count > y->count ? -1 : 1;
	}

	return x->id < y->id ? -1 : x->id > y->id;
}

static size_t rank_ids(const uint32_t *counts, size_t n, size_t limit, struct ranked **out)
{
	struct ranked *list = xmalloc(n * sizeof(*list));
	size_t m = 0;

	for (size_t i = 0; i < n; i++) {
		if (counts[i] > 0) {
			list[m].id = (uint32_t)i;
			list[m].count = counts[i];
			m++;
		}
	}

	qsort(list, m, sizeof(*list), cmp_ranked);
	*out = list;
	return m < limit ? m : limit;
}

void current_top_domains(struct current *c, const uint32_t *counts, size_t limit, struct top_name **out, size_t *n)
{
	struct ranked *list = NULL;
	size_t m = rank_ids(counts, c->doms.arena->count, limit, &list);

	*out = xcalloc(m, sizeof(**out));
	for (size_t i = 0; i < m; i++) {
		size_t len = 0;
		const uint8_t *name = arena_get(c->doms.arena, list[i].id, &len);
		(*out)[i].name = xstrndup((const char *)name, len);
		(*out)[i].len = len;
		(*out)[i].count = list[i].count;
	}

	*n = m;
	free(list);
}

static int cmp_clients(const void *a, const void *b)
{
	const struct top_client *x = a;
	const struct top_client *y = b;
	if (x->count != y->count) {
		return x->count > y->count ? -1 : 1;
	}

	return memcmp(x->key, y->key, CLIENT_KEY_LEN);
}

void current_top_clients(struct current *c, size_t limit, struct top_client **out, size_t *n)
{
	struct top_client *list = xcalloc(c->nclis, sizeof(*list));
	size_t m = 0;

	for (size_t i = 0; i < c->nclis; i++) {
		const struct cli_stat *cs = &c->cli_stats[i];
		if (cs->count == 0) {
			continue;
		}

		memcpy(list[m].key, c->clis[i], CLIENT_KEY_LEN);
		list[m].count = cs->count;
		list[m].blocked = cs->blocked;
		list[m].failed = cs->failed;
		list[m].last = c->day * DAY_MILLIS + cs->last;
		m++;
	}

	qsort(list, m, sizeof(*list), cmp_clients);
	*out = list;
	*n = m < limit ? m : limit;
}

static void put_u16(struct buf *b, size_t v)
{
	uint8_t p[2] = {(uint8_t)v, (uint8_t)(v >> 8)};
	buf_add(b, p, 2);
}

static void put_u32(struct buf *b, uint64_t v)
{
	uint8_t p[4] = {(uint8_t)v, (uint8_t)(v >> 8), (uint8_t)(v >> 16), (uint8_t)(v >> 24)};
	buf_add(b, p, 4);
}

static void put_names(struct buf *b, const struct top_name *list, size_t n)
{
	put_u16(b, n);
	for (size_t i = 0; i < n; i++) {
		put_u32(b, list[i].count);
		put_u16(b, list[i].len);
		buf_add(b, list[i].name, list[i].len);
	}
}

int sum_write(struct current *c)
{
	char path[600];
	struct buf b = {0};
	struct top_name *names = NULL;
	struct top_client *clients = NULL;
	size_t n = 0;

	buf_add(&b, SUM_MAGIC, 4);
	for (int i = 0; i < SLOTS_PER_DAY; i++) {
		put_u32(&b, c->slots[i]);
	}

	current_top_domains(c, c->doms.counts, DAY_TOP_LIMIT, &names, &n);
	put_names(&b, names, n);
	free_names(names, n);
	current_top_clients(c, DAY_TOP_LIMIT, &clients, &n);
	put_u16(&b, n);
	for (size_t i = 0; i < n; i++) {
		put_u32(&b, clients[i].count);
		buf_add(&b, clients[i].key, CLIENT_KEY_LEN);
	}

	size_t nclients = n;
	current_top_domains(c, c->doms.blocked, DAY_TOP_LIMIT, &names, &n);
	put_names(&b, names, n);
	free_names(names, n);
	put_u16(&b, nclients);
	for (size_t i = 0; i < nclients; i++) {
		put_u32(&b, clients[i].blocked);
		put_u32(&b, clients[i].failed);
		put_u32(&b, (uint64_t)(clients[i].last - c->day * DAY_MILLIS));
	}

	free(clients);
	sum_path(c->day, path, sizeof(path));
	int ret = atomic_write(path, b.data, b.len);
	buf_free(&b);
	return ret;
}

struct day_sum *sum_closed(int64_t day)
{
	pthread_mutex_lock(&sums_mu);
	for (size_t i = 0; i < nsums; i++) {
		if (sums[i].day == day) {
			struct day_sum *s = sums[i].sum;
			pthread_mutex_unlock(&sums_mu);
			return s;
		}
	}

	struct day_sum *s = sum_read(day);
	sums = xrealloc(sums, (nsums + 1) * sizeof(*sums));
	sums[nsums].day = day;
	sums[nsums].sum = s;
	nsums++;
	pthread_mutex_unlock(&sums_mu);
	return s;
}

void sum_forget(int64_t day)
{
	pthread_mutex_lock(&sums_mu);
	for (size_t i = 0; i < nsums; i++) {
		if (sums[i].day == day) {
			sum_free(sums[i].sum);
			sums[i] = sums[--nsums];
			break;
		}
	}

	pthread_mutex_unlock(&sums_mu);
}

struct smap_entry {
	const uint8_t *key;
	size_t len;
	uint64_t count;
};

struct smap {
	struct smap_entry *e;
	size_t cap;
	size_t n;
};

static uint32_t fnv(const uint8_t *b, size_t len)
{
	uint32_t h = 2166136261u;
	for (size_t i = 0; i < len; i++) {
		h = (h ^ b[i]) * 16777619u;
	}

	return h;
}

static struct smap_entry *smap_slot(struct smap *m, const uint8_t *key, size_t len)
{
	if ((m->n + 1) * 2 > m->cap) {
		struct smap_entry *old = m->e;
		size_t old_cap = m->cap;
		m->cap = m->cap ? m->cap * 2 : 256;
		m->e = xcalloc(m->cap, sizeof(*m->e));
		m->n = 0;
		for (size_t i = 0; i < old_cap; i++) {
			if (old[i].key != NULL) {
				struct smap_entry *e = smap_slot(m, old[i].key, old[i].len);
				*e = old[i];
				m->n++;
			}
		}

		free(old);
	}

	for (size_t i = fnv(key, len) & (m->cap - 1);; i = (i + 1) & (m->cap - 1)) {
		struct smap_entry *e = &m->e[i];
		if (e->key == NULL || (e->len == len && memcmp(e->key, key, len) == 0)) {
			return e;
		}
	}
}

static void smap_add(struct smap *m, const uint8_t *key, size_t len, uint64_t count)
{
	struct smap_entry *e = smap_slot(m, key, len);
	if (e->key == NULL) {
		e->key = key;
		e->len = len;
		m->n++;
	}

	e->count += count;
}

static int smap_has(const struct smap *m, const uint8_t *key, size_t len)
{
	if (m->cap == 0) {
		return 0;
	}

	for (size_t i = fnv(key, len) & (m->cap - 1);; i = (i + 1) & (m->cap - 1)) {
		const struct smap_entry *e = &m->e[i];
		if (e->key == NULL) {
			return 0;
		}

		if (e->len == len && memcmp(e->key, key, len) == 0) {
			return 1;
		}
	}
}

static void merge_names(struct smap *m, const struct top_name *list, size_t n)
{
	for (size_t i = 0; i < n; i++) {
		smap_add(m, (const uint8_t *)list[i].name, list[i].len, list[i].count);
	}
}

struct cmap {
	struct smap idx;
	struct top_client *v;
	size_t n;
	size_t cap;
};

static void client_fold(struct top_client *into, const struct top_client *from)
{
	into->count += from->count;
	into->blocked += from->blocked;
	into->failed += from->failed;
	if (from->last > into->last) {
		into->last = from->last;
	}
}

static void merge_clients(struct cmap *m, const struct top_client *list, size_t n)
{
	for (size_t i = 0; i < n; i++) {
		struct smap_entry *e = smap_slot(&m->idx, list[i].key, CLIENT_KEY_LEN);
		if (e->key != NULL) {
			client_fold(&m->v[e->count], &list[i]);
			continue;
		}

		if (m->n == m->cap) {
			m->cap = m->cap ? m->cap * 2 : 64;
			m->v = xrealloc(m->v, m->cap * sizeof(*m->v));
		}

		e->key = list[i].key;
		e->len = CLIENT_KEY_LEN;
		e->count = m->n;
		m->idx.n++;
		m->v[m->n++] = list[i];
	}
}

static int cmp_names(const void *a, const void *b)
{
	const struct top_name *x = a;
	const struct top_name *y = b;
	if (x->count != y->count) {
		return x->count > y->count ? -1 : 1;
	}

	size_t n = x->len < y->len ? x->len : y->len;
	int c = memcmp(x->name, y->name, n);
	if (c != 0) {
		return c;
	}

	return x->len < y->len ? -1 : x->len > y->len;
}

static size_t rank_names(const struct smap *m, const struct smap *exclude, size_t limit, struct top_name **out)
{
	struct top_name *list = xcalloc(m->n, sizeof(*list));
	size_t n = 0;

	for (size_t i = 0; i < m->cap; i++) {
		const struct smap_entry *e = &m->e[i];
		if (e->key == NULL || (exclude != NULL && smap_has(exclude, e->key, e->len))) {
			continue;
		}

		list[n].name = (char *)e->key;
		list[n].len = e->len;
		list[n].count = e->count;
		n++;
	}

	qsort(list, n, sizeof(*list), cmp_names);
	if (n > limit) {
		n = limit;
	}

	for (size_t i = 0; i < n; i++) {
		list[i].name = xstrndup(list[i].name, list[i].len);
	}

	*out = list;
	return n;
}

static size_t rank_clients(struct cmap *m, size_t limit, struct top_client **out)
{
	struct top_client *all = m->v;
	size_t n = m->n;
	size_t kept = 0;
	struct smap by_mac = {0};

	*out = all;
	if (n == 0) {
		return 0;
	}

	uint8_t(*macs)[MAC_LEN] = xmalloc(n * MAC_LEN);
	qsort(all, n, sizeof(*all), cmp_clients);
	for (size_t i = 0; i < n; i++) {
		const uint8_t *mac = all[i].key + 1 + ADDR_LEN;
		struct smap_entry *e = mac_is_zero(mac) ? NULL : smap_slot(&by_mac, mac, MAC_LEN);
		if (e != NULL && e->key != NULL) {
			struct top_client *into = &all[e->count];
			client_fold(into, &all[i]);
			if (into->key[0] != 4 && all[i].key[0] == 4) {
				memcpy(into->key, all[i].key, CLIENT_KEY_LEN);
			}

			continue;
		}

		if (e != NULL) {
			memcpy(macs[kept], mac, MAC_LEN);
			e->key = macs[kept];
			e->len = MAC_LEN;
			e->count = kept;
			by_mac.n++;
		}

		all[kept++] = all[i];
	}

	free(by_mac.e);
	free(macs);
	qsort(all, kept, sizeof(*all), cmp_clients);
	return kept < limit ? kept : limit;
}

static void free_smap_names(struct top_name **lists, size_t *counts, size_t n)
{
	for (size_t i = 0; i < n; i++) {
		free_names(lists[i], counts[i]);
	}
}

void store_refresh_tops(void)
{
	struct smap domains = {0};
	struct smap blocked = {0};
	struct cmap clients = {0};
	struct top_name *owned[2] = {NULL, NULL};
	size_t owned_n[2] = {0, 0};
	struct top_client *cur_clients = NULL;
	size_t cur_nclients = 0;
	int64_t now = now_ms();
	int64_t cur_day = now / DAY_MILLIS;

	pthread_rwlock_rdlock(&st.mu);
	if (st.cur != NULL) {
		cur_day = st.cur->day;
		current_top_domains(st.cur, st.cur->doms.counts, MERGED_TOP, &owned[0], &owned_n[0]);
		current_top_domains(st.cur, st.cur->doms.blocked, MERGED_TOP, &owned[1], &owned_n[1]);
		current_top_clients(st.cur, MERGED_TOP, &cur_clients, &cur_nclients);
	}

	pthread_rwlock_unlock(&st.mu);
	merge_names(&domains, owned[0], owned_n[0]);
	merge_names(&blocked, owned[1], owned_n[1]);
	merge_clients(&clients, cur_clients, cur_nclients);
	for (int64_t d = cur_day - TOP_WINDOW + 1; d < cur_day; d++) {
		struct day_sum *s = sum_closed(d);
		if (s != NULL) {
			merge_names(&domains, s->domains, s->ndomains);
			merge_names(&blocked, s->blocked, s->nblocked);
			merge_clients(&clients, s->clients, s->nclients);
		}
	}

	struct top_client *new_clients = NULL;
	struct top_name *new_domains = NULL;
	struct top_name *new_blocked = NULL;
	size_t nc = rank_clients(&clients, MERGED_TOP, &new_clients);
	size_t nd = rank_names(&domains, &blocked, MERGED_TOP, &new_domains);
	size_t nb = rank_names(&blocked, NULL, MERGED_TOP, &new_blocked);

	pthread_mutex_lock(&tops_mu);
	free(tops.clients);
	free_names(tops.domains, tops.ndomains);
	free_names(tops.blocked, tops.nblocked);
	tops.clients = new_clients;
	tops.nclients = nc;
	tops.domains = new_domains;
	tops.ndomains = nd;
	tops.blocked = new_blocked;
	tops.nblocked = nb;
	tops.end = now;
	tops.start = now - TOP_WINDOW * DAY_MILLIS;
	pthread_mutex_unlock(&tops_mu);

	free(domains.e);
	free(blocked.e);
	free(clients.idx.e);
	free(cur_clients);
	free_smap_names(owned, owned_n, 2);
}

size_t store_top_clients(size_t count, struct top_client **out, int64_t *start, int64_t *end)
{
	pthread_mutex_lock(&tops_mu);
	*out = tops.clients;
	*start = tops.start;
	*end = tops.end;
	return count < tops.nclients ? count : tops.nclients;
}

size_t store_top_domains(size_t count, int blocked, struct top_name **out, int64_t *start, int64_t *end)
{
	pthread_mutex_lock(&tops_mu);
	*out = blocked ? tops.blocked : tops.domains;
	size_t n = blocked ? tops.nblocked : tops.ndomains;
	*start = tops.start;
	*end = tops.end;
	return count < n ? count : n;
}

void store_tops_release(void)
{
	pthread_mutex_unlock(&tops_mu);
}

static int cmp_bucket_desc(const void *a, const void *b)
{
	const struct bucket *x = a;
	const struct bucket *y = b;
	return x->key > y->key ? -1 : x->key < y->key;
}

static size_t collect(int64_t first, int64_t current, int64_t from_day, int64_t to_day, int daily, struct bucket **out)
{
	uint32_t cur_slots[SLOTS_PER_DAY];
	int64_t cur_day = INT64_MIN;
	struct bucket *list = NULL;
	size_t n = 0;
	size_t cap = 0;

	pthread_rwlock_rdlock(&st.mu);
	if (st.cur != NULL) {
		cur_day = st.cur->day;
		memcpy(cur_slots, st.cur->slots, sizeof(cur_slots));
	}

	pthread_rwlock_unlock(&st.mu);
	for (int64_t d = from_day; d <= to_day; d++) {
		const uint32_t *slots = NULL;
		if (d == cur_day) {
			slots = cur_slots;
		} else {
			struct day_sum *s = sum_closed(d);
			if (s == NULL) {
				continue;
			}

			slots = s->slots;
		}

		for (int i = 0; i < SLOTS_PER_DAY; i++) {
			struct tm tm;
			if (slots[i] == 0) {
				continue;
			}

			time_t t = (time_t)(d * 86400 + (int64_t)i * (SLOT_MILLIS / 1000));
			localtime_r(&t, &tm);
			if (daily) {
				tm.tm_hour = 0;
				tm.tm_isdst = -1;
			}

			tm.tm_min = 0;
			tm.tm_sec = 0;
			int64_t key = (int64_t)mktime(&tm);
			if (key < first || key > current) {
				continue;
			}

			if (n == cap) {
				cap = cap ? cap * 2 : 64;
				list = xrealloc(list, cap * sizeof(*list));
			}

			list[n].key = key;
			list[n].count = slots[i];
			n++;
		}
	}

	if (n > 1) {
		qsort(list, n, sizeof(*list), cmp_bucket_desc);
	}
	size_t m = 0;
	for (size_t i = 0; i < n; i++) {
		if (m > 0 && list[m - 1].key == list[i].key) {
			list[m - 1].count += list[i].count;
		} else {
			list[m++] = list[i];
		}
	}

	*out = list;
	return m;
}

static int64_t floor_day(int64_t seconds)
{
	return seconds / 86400;
}

size_t store_hourly(int hours, int64_t now, struct bucket **out)
{
	struct tm tm;
	time_t t = (time_t)(now / 1000);

	localtime_r(&t, &tm);
	tm.tm_min = 0;
	tm.tm_sec = 0;
	int64_t current = (int64_t)mktime(&tm);
	int64_t first = current - (int64_t)(hours - 1) * 3600;
	return collect(first, current, floor_day(first), floor_day(now / 1000), 0, out);
}

size_t store_daily(int days, int64_t now, struct bucket **out)
{
	struct tm tm;
	time_t t = (time_t)(now / 1000);

	localtime_r(&t, &tm);
	tm.tm_hour = 0;
	tm.tm_min = 0;
	tm.tm_sec = 0;
	tm.tm_isdst = -1;
	struct tm first_tm = tm;
	int64_t current = (int64_t)mktime(&tm);
	first_tm.tm_mday -= days - 1;
	first_tm.tm_isdst = -1;
	int64_t first = (int64_t)mktime(&first_tm);
	return collect(first, current, floor_day(first) - 1, floor_day(now / 1000), 1, out);
}

void bucket_label(int64_t key, int daily, char out[96])
{
	struct tm tm;
	time_t t = (time_t)key;
	long off = 0;
	char sign = '+';

	localtime_r(&t, &tm);
	off = tm.tm_gmtoff;
	if (off < 0) {
		sign = '-';
		off = -off;
	}

	snprintf(out, 96, "%04d-%02d-%02dT%02d:00:00%c%02d:%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, daily ? 0 : tm.tm_hour,
			 sign, (int)(off / 3600 % 100), (int)(off / 60 % 60));
}
