#!/usr/bin/perl
use strict;
use warnings;
use Digest::SHA qw(sha1 sha256);
use File::Find;
use IO::Uncompress::Gunzip qw(gunzip $GunzipError);
use MIME::Base64 qw(encode_base64);

my ($www, $out) = @ARGV;
die "usage: gen-www.pl www-dir out-dir\n" unless defined $out;

my %mime = (
    '.html'  => 'text/html; charset=utf-8',
    '.js'    => 'text/javascript; charset=utf-8',
    '.css'   => 'text/css; charset=utf-8',
    '.json'  => 'application/json',
    '.txt'   => 'text/plain; charset=utf-8',
    '.svg'   => 'image/svg+xml',
    '.ico'   => 'image/x-icon',
    '.png'   => 'image/png',
    '.woff2' => 'font/woff2',
);

my $csp_template = "default-src 'self'; script-src 'self'%s; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'; object-src 'none'";

sub slurp {
    my ($path) = @_;
    open(my $fh, '<:raw', $path) or die "$path: $!\n";
    local $/;
    my $data = <$fh>;
    close($fh);
    return $data;
}

sub csp {
    my ($html) = @_;
    my $hashes = '';
    while ($html =~ /<script((?:\s[^>]*)?)>(.*?)<\/script>/gs) {
        my ($attrs, $body) = ($1, $2);
        my $trimmed = $body;
        $trimmed =~ s/^\s+|\s+$//g;
        next if $trimmed eq '' || index("<script$attrs", ' src=') >= 0;
        $hashes .= " 'sha256-" . encode_base64(sha256($body), '') . "'";
    }

    (my $policy = $csp_template) =~ s/%s/$hashes/;
    return $policy;
}

sub c_string {
    my ($s) = @_;
    $s =~ s/(["\\])/\\$1/g;
    return "\"$s\"";
}

my @files;
find({no_chdir => 1, wanted => sub { push @files, $File::Find::name if -f $_ }}, $www);

@files = sort @files;
my %entries;
for my $path (@files) {
    (my $name = $path) =~ s/^\Q$www\E\/?//;
    my $logical = $name;
    my $gz = $logical =~ s/\.gz$// ? 1 : 0;
    my $data = slurp($path);
    my ($ext) = $logical =~ /(\.[^.\/]*)$/;
    my $type = defined $ext && exists $mime{$ext} ? $mime{$ext} : 'application/octet-stream';
    my $policy = '';
    my $plain = '';
    if ($type eq $mime{'.html'}) {
        my $html = $data;
        if ($gz) {
            gunzip(\$data => \$html) or die "$path: $GunzipError\n";
            $plain = "$out/plain-" . scalar(keys %entries) . '.html';
            open(my $fh, '>:raw', $plain) or die "$plain: $!\n";
            print $fh $html;
            close($fh);
        }

        $policy = csp($html);
    }

    $entries{$logical} = {
        path  => $path,
        gz    => $gz,
        tag   => '"' . unpack('H16', sha1($data)) . '"',
        mime  => $type,
        csp   => $policy,
        plain => $plain,
    };
}

my @names = sort { $a cmp $b } keys %entries;
open(my $asm, '>', "$out/www.S") or die "$out/www.S: $!\n";
open(my $tab, '>', "$out/www_table.h") or die "$out/www_table.h: $!\n";
print $asm "\t.section .rodata\n";
for my $i (0 .. $#names) {
    my $e = $entries{$names[$i]};
    print $asm "\t.globl www_data_$i\n\t.globl www_end_$i\nwww_data_$i:\n\t.incbin \"$e->{path}\"\nwww_end_$i:\n";
    print $tab "extern const unsigned char www_data_$i\[\], www_end_$i\[\];\n";
    next unless $e->{plain};
    print $asm "\t.globl www_plain_$i\n\t.globl www_plain_end_$i\nwww_plain_$i:\n\t.incbin \"$e->{plain}\"\nwww_plain_end_$i:\n";
    print $tab "extern const unsigned char www_plain_$i\[\], www_plain_end_$i\[\];\n";
}

print $asm "\t.section .note.GNU-stack,\"\",%progbits\n";
print $tab "\nstatic const struct www_file www_files[] = {\n";
for my $i (0 .. $#names) {
    my $e = $entries{$names[$i]};
    my $plain = $e->{plain} ? "www_plain_$i, www_plain_end_$i" : 'NULL, NULL';
    printf $tab "\t{%s, %d, %s, %s, %s, www_data_%d, www_end_%d, %s},\n", c_string($names[$i]), $e->{gz}, c_string($e->{tag}),
        c_string($e->{mime}), c_string($e->{csp}), $i, $i, $plain;
}

print $tab "};\n";
close($asm);
close($tab);
