#ifndef HRDNS_UI_STORE_H
#define HRDNS_UI_STORE_H

#include "ui.h"

#define COL_TMS 0
#define COL_DOM 1
#define COL_CLI 2
#define COL_GRP 3
#define COL_QTYPE 4
#define COL_RCODE 5
#define COL_FLAGS 6
#define COL_QMS 7
#define COL_PING 8
#define COL_BLK 9
#define NUM_COLS 10
#define DICT_DOM 10
#define DICT_CLI 11
#define DICT_GRP 12
#define NUM_FILES 13

#define ID_DAY_SHIFT 27
#define ID_INDEX_MASK ((1ULL << ID_DAY_SHIFT) - 1)
#define PING_NONE 0xFFFF
#define MAX_GROUPS 255
#define MAX_CLIENTS 65535
#define MAX_DOMAINS 262144
#define OVERFLOW_DOMAIN "(other)"
#define FLAG_BLOCKED 1
#define FLAG_CACHED 2

#define ARENA_CHUNK (128 << 10)
#define PTR_CHUNK_SHIFT 14
#define PTR_CHUNK (1 << PTR_CHUNK_SHIFT)
#define PTR_CHUNKS ((MAX_DOMAINS + 1 + PTR_CHUNK - 1) / PTR_CHUNK)

extern const int col_width[NUM_COLS];
extern const char *const file_names[NUM_FILES];

static inline int late_column(int col)
{
	return col == COL_BLK;
}

static inline uint16_t get_u16(const uint8_t *b, size_t i)
{
	return (uint16_t)(b[i * 2] | b[i * 2 + 1] << 8);
}

static inline uint32_t get_u24(const uint8_t *b, size_t i)
{
	return (uint32_t)b[i * 3] | (uint32_t)b[i * 3 + 1] << 8 | (uint32_t)b[i * 3 + 2] << 16;
}

static inline uint32_t get_u32(const uint8_t *b, size_t i)
{
	return (uint32_t)b[i * 4] | (uint32_t)b[i * 4 + 1] << 8 | (uint32_t)b[i * 4 + 2] << 16 | (uint32_t)b[i * 4 + 3] << 24;
}

struct rec {
	uint32_t tms;
	uint32_t dom;
	uint16_t cli;
	uint16_t qtype;
	uint16_t qms;
	uint16_t ping;
	uint8_t grp;
	uint8_t rcode;
	uint8_t flags;
	uint8_t blk;
};

struct arena {
	int refs;
	uint8_t **blocks;
	size_t nblocks;
	size_t block_used;
	const uint8_t **ptrs[PTR_CHUNKS];
	uint32_t count;
};

struct arena *arena_new(void);
struct arena *arena_ref(struct arena *a);
void arena_unref(struct arena *a);
uint32_t arena_append(struct arena *a, const uint8_t *name, size_t len);
size_t arena_load(struct arena *a, uint8_t *data, size_t len);

static inline const uint8_t *arena_get(const struct arena *a, uint32_t id, size_t *len)
{
	const uint8_t *p = a->ptrs[id >> PTR_CHUNK_SHIFT][id & (PTR_CHUNK - 1)];
	*len = (size_t)(p[0] | p[1] << 8);
	return p + 2;
}

struct name {
	char *data;
	size_t len;
};

struct dict {
	int refs;
	int64_t day;
	struct arena *arena;
	uint32_t ndom;
	uint8_t (*clients)[CLIENT_KEY_LEN];
	size_t nclients;
	struct name *groups;
	size_t ngroups;
};

struct dict *dict_ref(struct dict *d);
void dict_unref(struct dict *d);

static inline const uint8_t *dict_domain(const struct dict *d, uint32_t id, size_t *len)
{
	if (id >= d->ndom) {
		*len = 0;
		return (const uint8_t *)"";
	}

	return arena_get(d->arena, id, len);
}

struct seg_view {
	int64_t day;
	int opened;
	int empty;
	int fds[NUM_COLS];
	size_t nrec;
	size_t nflushed;
	struct rec *pending;
	size_t npending;
	struct dict *dict;
};

struct views {
	size_t n;
	struct seg_view *v;
};

struct views *store_views(void);
void seg_open(struct seg_view *v);
void seg_dir(int64_t day, char *out, size_t len);

struct domtab {
	struct arena *arena;
	uint32_t *counts;
	uint32_t *blocked;
	size_t cap;
	uint32_t *slots;
	uint32_t mask;
	uint32_t other;
	int has_other;
};

struct cli_stat {
	uint32_t count;
	uint32_t blocked;
	uint32_t failed;
	uint32_t last;
};

struct current {
	int64_t day;
	char dir[640];
	int fds[NUM_FILES];
	int64_t sizes[NUM_FILES];
	struct rec *pending;
	size_t npending;
	size_t pending_cap;
	size_t flushed;
	struct domtab doms;
	uint32_t dom_flushed;
	uint8_t (*clis)[CLIENT_KEY_LEN];
	struct cli_stat *cli_stats;
	size_t nclis;
	size_t clis_cap;
	uint32_t *cli_slots;
	uint32_t cli_mask;
	size_t cli_flushed;
	struct name groups[MAX_GROUPS];
	size_t ngroups;
	size_t grp_flushed;
	uint32_t slots[SLOTS_PER_DAY];
};

struct day_sum {
	uint32_t slots[SLOTS_PER_DAY];
	struct top_name *domains;
	size_t ndomains;
	struct top_client *clients;
	size_t nclients;
	struct top_name *blocked;
	size_t nblocked;
};

struct store {
	struct store_config cfg;
	pthread_rwlock_t mu;
	struct current *cur;
	int64_t *days;
	size_t ndays;
	pthread_mutex_t cnt_mu;
	uint64_t total;
	uint64_t blocked;
	uint64_t failed;
	uint64_t tick;
	uint64_t rate;
	int64_t size_log;
	int64_t next_flush;
	int64_t next_second;
	int64_t next_hour;
};

extern struct store st;

void sum_path(int64_t day, char *out, size_t len);
int sum_write(struct current *c);
struct day_sum *sum_closed(int64_t day);
void sum_forget(int64_t day);
void sums_prune(void);
void sums_reset(void);
void sum_free(struct day_sum *s);
struct day_sum *sum_read(int64_t day);
void current_top_domains(struct current *c, const uint32_t *counts, size_t limit, struct top_name **out, size_t *n);
void current_top_clients(struct current *c, size_t limit, struct top_client **out, size_t *n);
void tops_free(void);

void dicts_forget(int64_t day);
void dicts_reset(void);
struct dict *dict_load(int64_t day);

#endif
