#define _GNU_SOURCE

#include "store.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define DOM_SLOTS_INITIAL 1024
#define CLI_SLOTS_INITIAL 64
#define DICT_CACHE 4
#define SUM_KEEP_DAYS 90

const int col_width[NUM_COLS] = {4, 3, 2, 1, 2, 1, 1, 2, 2, 1};
const char *const file_names[NUM_FILES] = {"col-tms", "col-dom", "col-cli", "col-grp", "col-qtype", "col-rcode", "col-flags",
										   "col-qms", "col-ping", "col-blk", "dict-dom", "dict-cli", "dict-grp"};

struct store st = {
	.mu = PTHREAD_RWLOCK_INITIALIZER,
	.cnt_mu = PTHREAD_MUTEX_INITIALIZER,
};

static pthread_mutex_t ref_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t dict_mu = PTHREAD_MUTEX_INITIALIZER;
static struct dict *dict_cache[DICT_CACHE];
static size_t dict_cached;

struct arena *arena_new(void)
{
	struct arena *a = xcalloc(1, sizeof(*a));
	a->refs = 1;
	return a;
}

struct arena *arena_ref(struct arena *a)
{
	pthread_mutex_lock(&ref_mu);
	a->refs++;
	pthread_mutex_unlock(&ref_mu);
	return a;
}

void arena_unref(struct arena *a)
{
	if (a == NULL) {
		return;
	}

	pthread_mutex_lock(&ref_mu);
	int left = --a->refs;
	pthread_mutex_unlock(&ref_mu);
	if (left > 0) {
		return;
	}

	for (size_t i = 0; i < a->nblocks; i++) {
		free(a->blocks[i]);
	}

	for (size_t i = 0; i < PTR_CHUNKS; i++) {
		free(a->ptrs[i]);
	}

	free(a->blocks);
	free(a);
}

static void arena_set_ptr(struct arena *a, const uint8_t *p)
{
	uint32_t id = a->count;
	size_t chunk = id >> PTR_CHUNK_SHIFT;
	if (a->ptrs[chunk] == NULL) {
		a->ptrs[chunk] = xmalloc(PTR_CHUNK * sizeof(**a->ptrs));
	}

	a->ptrs[chunk][id & (PTR_CHUNK - 1)] = p;
	a->count = id + 1;
}

static void arena_add_block(struct arena *a, uint8_t *block, size_t used)
{
	a->blocks = xrealloc(a->blocks, (a->nblocks + 1) * sizeof(*a->blocks));
	a->blocks[a->nblocks++] = block;
	a->block_used = used;
}

uint32_t arena_append(struct arena *a, const uint8_t *name, size_t len)
{
	size_t need = 2 + len;
	uint8_t *p = NULL;

	if (a->nblocks == 0 || a->block_used + need > ARENA_CHUNK) {
		size_t size = need > ARENA_CHUNK ? need : ARENA_CHUNK;
		arena_add_block(a, xmalloc(size), 0);
		if (need > ARENA_CHUNK) {
			a->block_used = ARENA_CHUNK;
			p = a->blocks[a->nblocks - 1];
		}
	}

	if (p == NULL) {
		p = a->blocks[a->nblocks - 1] + a->block_used;
		a->block_used += need;
	}

	p[0] = (uint8_t)len;
	p[1] = (uint8_t)(len >> 8);
	if (len > 0) {
		memcpy(p + 2, name, len);
	}

	uint32_t id = a->count;
	arena_set_ptr(a, p);
	return id;
}

size_t arena_load(struct arena *a, uint8_t *data, size_t len)
{
	size_t off = 0;

	arena_add_block(a, data, ARENA_CHUNK);
	while (off + 2 <= len && a->count < PTR_CHUNKS * PTR_CHUNK) {
		size_t n = (size_t)(data[off] | data[off + 1] << 8);
		if (off + 2 + n > len) {
			break;
		}

		arena_set_ptr(a, data + off);
		off += 2 + n;
	}

	return off;
}

struct dict *dict_ref(struct dict *d)
{
	pthread_mutex_lock(&ref_mu);
	d->refs++;
	pthread_mutex_unlock(&ref_mu);
	return d;
}

void dict_unref(struct dict *d)
{
	if (d == NULL) {
		return;
	}

	pthread_mutex_lock(&ref_mu);
	int left = --d->refs;
	pthread_mutex_unlock(&ref_mu);
	if (left > 0) {
		return;
	}

	arena_unref(d->arena);
	for (size_t i = 0; i < d->ngroups; i++) {
		free(d->groups[i].data);
	}

	free(d->groups);
	free(d->clients);
	free(d);
}

static uint32_t hash_bytes(const uint8_t *b, size_t len)
{
	uint32_t h = 2166136261u;
	for (size_t i = 0; i < len; i++) {
		h = (h ^ b[i]) * 16777619u;
	}

	return h;
}

static void domtab_init(struct domtab *t)
{
	memset(t, 0, sizeof(*t));
	t->arena = arena_new();
	t->slots = xcalloc(DOM_SLOTS_INITIAL, sizeof(*t->slots));
	t->mask = DOM_SLOTS_INITIAL - 1;
}

static void domtab_free(struct domtab *t)
{
	arena_unref(t->arena);
	free(t->counts);
	free(t->blocked);
	free(t->slots);
	memset(t, 0, sizeof(*t));
}

static uint32_t domtab_append(struct domtab *t, const uint8_t *name, size_t len)
{
	if (t->arena->count >= t->cap) {
		t->cap = t->cap ? t->cap * 2 : 1024;
		t->counts = xrealloc(t->counts, t->cap * sizeof(*t->counts));
		t->blocked = xrealloc(t->blocked, t->cap * sizeof(*t->blocked));
	}

	uint32_t id = arena_append(t->arena, name, len);
	t->counts[id] = 0;
	t->blocked[id] = 0;
	return id;
}

static int domtab_find(const struct domtab *t, const uint8_t *b, size_t len, uint32_t h, uint32_t *slot, uint32_t *id)
{
	for (uint32_t i = h & t->mask;; i = (i + 1) & t->mask) {
		uint32_t v = t->slots[i];
		if (v == 0) {
			*slot = i;
			return 0;
		}

		size_t n = 0;
		const uint8_t *name = arena_get(t->arena, v - 1, &n);
		if (n == len && memcmp(name, b, len) == 0) {
			*slot = i;
			*id = v - 1;
			return 1;
		}
	}
}

static void domtab_grow(struct domtab *t)
{
	size_t nslots = (size_t)(t->mask + 1) * 2;
	free(t->slots);
	t->slots = xcalloc(nslots, sizeof(*t->slots));
	t->mask = (uint32_t)(nslots - 1);
	for (uint32_t id = 0; id < t->arena->count; id++) {
		if (t->has_other && id == t->other) {
			continue;
		}

		size_t n = 0;
		const uint8_t *name = arena_get(t->arena, id, &n);
		uint32_t i = hash_bytes(name, n) & t->mask;
		while (t->slots[i] != 0) {
			i = (i + 1) & t->mask;
		}

		t->slots[i] = id + 1;
	}
}

static void domtab_insert(struct domtab *t, const uint8_t *b, size_t len, uint32_t id)
{
	uint32_t slot = 0;
	uint32_t found = 0;

	if ((size_t)t->arena->count * 2 > (size_t)t->mask + 1) {
		domtab_grow(t);
	}

	domtab_find(t, b, len, hash_bytes(b, len), &slot, &found);
	t->slots[slot] = id + 1;
}

static uint32_t domtab_intern(struct domtab *t, const uint8_t *b, size_t len)
{
	uint32_t slot = 0;
	uint32_t id = 0;

	if (len > 0xFFFF) {
		len = 0xFFFF;
	}

	if (domtab_find(t, b, len, hash_bytes(b, len), &slot, &id)) {
		return id;
	}

	if (t->arena->count >= MAX_DOMAINS) {
		if (!t->has_other) {
			t->other = domtab_append(t, (const uint8_t *)OVERFLOW_DOMAIN, strlen(OVERFLOW_DOMAIN));
			t->has_other = 1;
		}

		return t->other;
	}

	if (((size_t)t->arena->count + 1) * 2 > (size_t)t->mask + 1) {
		domtab_grow(t);
		domtab_find(t, b, len, hash_bytes(b, len), &slot, &id);
	}

	id = domtab_append(t, b, len);
	t->slots[slot] = id + 1;
	return id;
}

static size_t domtab_load(struct domtab *t, uint8_t *data, size_t len)
{
	size_t off = 0;

	arena_add_block(t->arena, data, ARENA_CHUNK);
	while (off + 2 <= len) {
		size_t n = (size_t)(data[off] | data[off + 1] << 8);
		if (off + 2 + n > len) {
			break;
		}

		if (t->arena->count >= t->cap) {
			t->cap = t->cap ? t->cap * 2 : 1024;
			t->counts = xrealloc(t->counts, t->cap * sizeof(*t->counts));
			t->blocked = xrealloc(t->blocked, t->cap * sizeof(*t->blocked));
		}

		uint32_t id = t->arena->count;
		arena_set_ptr(t->arena, data + off);
		t->counts[id] = 0;
		t->blocked[id] = 0;
		if (n == strlen(OVERFLOW_DOMAIN) && memcmp(data + off + 2, OVERFLOW_DOMAIN, n) == 0) {
			t->other = id;
			t->has_other = 1;
		} else {
			domtab_insert(t, data + off + 2, n, id);
		}

		off += 2 + n;
	}

	return off;
}

static uint32_t cli_find(const struct current *c, const uint8_t *key, uint32_t *slot)
{
	for (uint32_t i = hash_bytes(key, CLIENT_KEY_LEN) & c->cli_mask;; i = (i + 1) & c->cli_mask) {
		uint32_t v = c->cli_slots[i];
		if (v == 0 || memcmp(c->clis[(v - 1) & 0xFFFF], key, CLIENT_KEY_LEN) == 0) {
			*slot = i;
			return v;
		}
	}
}

static void cli_grow(struct current *c)
{
	size_t nslots = (size_t)(c->cli_mask + 1) * 2;
	uint32_t *old = c->cli_slots;
	size_t old_n = (size_t)c->cli_mask + 1;

	c->cli_slots = xcalloc(nslots, sizeof(*c->cli_slots));
	c->cli_mask = (uint32_t)(nslots - 1);
	for (size_t j = 0; j < old_n; j++) {
		uint32_t v = old[j];
		uint32_t slot = 0;
		if (v != 0) {
			cli_find(c, c->clis[v - 1], &slot);
			c->cli_slots[slot] = v;
		}
	}

	free(old);
}

static void cli_map_set(struct current *c, const uint8_t *key, uint16_t id)
{
	uint32_t slot = 0;
	if ((c->nclis + 1) * 2 > (size_t)c->cli_mask + 1) {
		cli_grow(c);
	}

	cli_find(c, key, &slot);
	c->cli_slots[slot] = (uint32_t)id + 1;
}

static void cli_append(struct current *c, const uint8_t *key)
{
	if (c->nclis == c->clis_cap) {
		c->clis_cap = c->clis_cap ? c->clis_cap * 2 : 64;
		c->clis = xrealloc(c->clis, c->clis_cap * CLIENT_KEY_LEN);
		c->cli_stats = xrealloc(c->cli_stats, c->clis_cap * sizeof(*c->cli_stats));
	}

	memcpy(c->clis[c->nclis], key, CLIENT_KEY_LEN);
	memset(&c->cli_stats[c->nclis], 0, sizeof(*c->cli_stats));
	c->nclis++;
}

static void cli_note(struct cli_stat *s, uint32_t tms, int blocked, uint8_t rcode)
{
	s->count++;
	s->blocked += blocked;
	s->failed += rcode != 0 && !blocked;
	if (tms > s->last) {
		s->last = tms;
	}
}

static uint16_t cli_intern(struct current *c, const uint8_t *key)
{
	uint32_t slot = 0;
	uint32_t v = cli_find(c, key, &slot);
	if (v != 0) {
		return (uint16_t)(v - 1);
	}

	if (c->nclis >= MAX_CLIENTS) {
		return MAX_CLIENTS - 1;
	}

	uint16_t id = (uint16_t)c->nclis;
	cli_append(c, key);
	cli_map_set(c, key, id);
	return id;
}

static uint8_t grp_intern(struct current *c, const uint8_t *b, size_t len)
{
	for (size_t i = 0; i < c->ngroups; i++) {
		if (c->groups[i].len == len && memcmp(c->groups[i].data, b, len) == 0) {
			return (uint8_t)i;
		}
	}

	if (c->ngroups >= MAX_GROUPS) {
		return MAX_GROUPS - 1;
	}

	c->groups[c->ngroups].data = xstrndup((const char *)b, len);
	c->groups[c->ngroups].len = len;
	return (uint8_t)c->ngroups++;
}

void seg_dir(int64_t day, char *out, size_t len)
{
	char name[11];
	day_name(day, name);
	snprintf(out, len, "%s/log/%s", st.cfg.dir, name);
}

static void log_dir(char *out, size_t len)
{
	snprintf(out, len, "%s/log", st.cfg.dir);
}

static void current_free(struct current *c)
{
	if (c == NULL) {
		return;
	}

	for (int i = 0; i < NUM_FILES; i++) {
		if (c->fds[i] >= 0) {
			close(c->fds[i]);
		}
	}

	domtab_free(&c->doms);
	for (size_t i = 0; i < c->ngroups; i++) {
		free(c->groups[i].data);
	}

	free(c->pending);
	free(c->clis);
	free(c->cli_stats);
	free(c->cli_slots);
	free(c);
}

static int fd_size(int fd, int64_t *size)
{
	struct stat sb;
	if (fstat(fd, &sb) != 0) {
		return -1;
	}

	*size = sb.st_size;
	return 0;
}

static int read_fd(int fd, uint8_t **out, size_t *len)
{
	int64_t size = 0;
	if (fd_size(fd, &size) != 0) {
		return -1;
	}

	uint8_t *data = xmalloc((size_t)size);
	size_t got = 0;
	while (got < (size_t)size) {
		ssize_t n = pread(fd, data + got, (size_t)size - got, (off_t)got);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			break;
		}

		got += (size_t)n;
	}

	if (got < (size_t)size) {
		free(data);
		return -1;
	}

	*out = data;
	*len = got;
	return 0;
}

static int pread_full(int fd, uint8_t *data, size_t len, off_t off)
{
	size_t got = 0;
	while (got < len) {
		ssize_t n = pread(fd, data + got, len - got, off + (off_t)got);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			return -1;
		}

		got += (size_t)n;
	}

	return 0;
}

static int restore_records(struct current *c)
{
	size_t records = SIZE_MAX;
	uint8_t *data[5] = {NULL, NULL, NULL, NULL, NULL};
	static const int cols[5] = {COL_TMS, COL_DOM, COL_CLI, COL_FLAGS, COL_RCODE};
	int ret = -1;

	for (int i = 0; i < NUM_COLS; i++) {
		int64_t size = 0;
		if (late_column(i)) {
			continue;
		}

		if (fd_size(c->fds[i], &size) != 0) {
			return -1;
		}

		size_t n = (size_t)size / (size_t)col_width[i];
		if (n < records) {
			records = n;
		}
	}

	for (int i = 0; i < 5; i++) {
		data[i] = xmalloc(records * (size_t)col_width[cols[i]]);
		if (records > 0 && pread_full(c->fds[cols[i]], data[i], records * (size_t)col_width[cols[i]], 0) != 0) {
			goto out;
		}
	}

	size_t valid = 0;
	for (; valid < records; valid++) {
		uint32_t tms = get_u32(data[0], valid);
		uint32_t dom = get_u24(data[1], valid);
		uint16_t cli = get_u16(data[2], valid);
		if (tms >= DAY_MILLIS || dom >= c->doms.arena->count || cli >= c->nclis) {
			break;
		}

		int blocked = (data[3][valid] & FLAG_BLOCKED) != 0;
		c->doms.counts[dom]++;
		c->doms.blocked[dom] += blocked;
		cli_note(&c->cli_stats[cli], tms, blocked, data[4][valid]);
		c->slots[tms / SLOT_MILLIS]++;
	}

	for (int i = 0; i < NUM_COLS; i++) {
		int64_t want = (int64_t)(valid * (size_t)col_width[i]);
		int64_t size = 0;
		if (fd_size(c->fds[i], &size) != 0) {
			goto out;
		}

		if (size != want && ftruncate(c->fds[i], want) != 0) {
			goto out;
		}

		c->sizes[i] = want;
	}

	c->flushed = valid;
	struct day_sum *sum = sum_read(c->day);
	if (sum != NULL) {
		for (int i = 0; i < SLOTS_PER_DAY; i++) {
			if (sum->slots[i] > c->slots[i]) {
				c->slots[i] = sum->slots[i];
			}
		}

		sum_free(sum);
	}

	ret = 0;
out:
	for (int i = 0; i < 5; i++) {
		free(data[i]);
	}

	return ret;
}

static int restore(struct current *c)
{
	uint8_t *dom = NULL;
	uint8_t *cli = NULL;
	uint8_t *grp = NULL;
	size_t dom_len = 0;
	size_t cli_len = 0;
	size_t grp_len = 0;

	if (read_fd(c->fds[DICT_DOM], &dom, &dom_len) != 0) {
		return -1;
	}

	size_t valid = domtab_load(&c->doms, dom, dom_len);
	c->dom_flushed = c->doms.arena->count;
	c->sizes[DICT_DOM] = (int64_t)valid;
	if (valid != dom_len && ftruncate(c->fds[DICT_DOM], (off_t)valid) != 0) {
		return -1;
	}

	if (read_fd(c->fds[DICT_CLI], &cli, &cli_len) != 0) {
		return -1;
	}

	size_t n = cli_len / CLIENT_KEY_LEN;
	if (n > MAX_CLIENTS) {
		n = MAX_CLIENTS;
	}

	for (size_t i = 0; i < n; i++) {
		cli_append(c, cli + i * CLIENT_KEY_LEN);
		cli_map_set(c, cli + i * CLIENT_KEY_LEN, (uint16_t)i);
	}

	free(cli);
	c->cli_flushed = n;
	c->sizes[DICT_CLI] = (int64_t)(n * CLIENT_KEY_LEN);
	if (cli_len != n * CLIENT_KEY_LEN && ftruncate(c->fds[DICT_CLI], (off_t)(n * CLIENT_KEY_LEN)) != 0) {
		return -1;
	}

	if (read_fd(c->fds[DICT_GRP], &grp, &grp_len) != 0) {
		return -1;
	}

	size_t off = 0;
	while (off < grp_len && off + 1 + grp[off] <= grp_len) {
		if (c->ngroups < MAX_GROUPS) {
			c->groups[c->ngroups].data = xstrndup((const char *)grp + off + 1, grp[off]);
			c->groups[c->ngroups].len = grp[off];
			c->ngroups++;
		}

		off += 1 + (size_t)grp[off];
	}

	free(grp);
	c->grp_flushed = c->ngroups;
	c->sizes[DICT_GRP] = (int64_t)off;
	if (off != grp_len && ftruncate(c->fds[DICT_GRP], (off_t)off) != 0) {
		return -1;
	}

	return restore_records(c);
}

static int open_current(int64_t day)
{
	struct current *c = xcalloc(1, sizeof(*c));
	char path[768];

	c->day = day;
	seg_dir(day, c->dir, sizeof(c->dir));
	for (int i = 0; i < NUM_FILES; i++) {
		c->fds[i] = -1;
	}

	domtab_init(&c->doms);
	c->cli_slots = xcalloc(CLI_SLOTS_INITIAL, sizeof(*c->cli_slots));
	c->cli_mask = CLI_SLOTS_INITIAL - 1;
	if (mkdir_all(c->dir) != 0) {
		current_free(c);
		return -1;
	}

	for (int i = 0; i < NUM_FILES; i++) {
		snprintf(path, sizeof(path), "%s/%s", c->dir, file_names[i]);
		c->fds[i] = open(path, O_CREAT | O_RDWR | O_CLOEXEC, 0644);
		if (c->fds[i] < 0) {
			current_free(c);
			return -1;
		}
	}

	if (restore(c) != 0) {
		current_free(c);
		return -1;
	}

	st.cur = c;
	return 0;
}

static int64_t dir_usage(const char *path)
{
	DIR *dir = opendir(path);
	struct dirent *ent = NULL;
	char child[1024];
	struct stat sb;
	int64_t total = 0;

	if (dir == NULL) {
		return 0;
	}

	while ((ent = readdir(dir)) != NULL) {
		if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) {
			continue;
		}

		snprintf(child, sizeof(child), "%s/%s", path, ent->d_name);
		if (lstat(child, &sb) != 0) {
			continue;
		}

		if (S_ISDIR(sb.st_mode)) {
			total += dir_usage(child);
		} else {
			total += sb.st_size;
		}
	}

	closedir(dir);
	return total;
}

static int64_t disk_usage(void)
{
	char path[600];
	log_dir(path, sizeof(path));
	return dir_usage(path);
}

static void set_size_log(int64_t v)
{
	pthread_mutex_lock(&st.cnt_mu);
	st.size_log = v;
	pthread_mutex_unlock(&st.cnt_mu);
}

static void drop_oldest_locked(void)
{
	char path[640];
	seg_dir(st.days[0], path, sizeof(path));
	remove_all(path);
	dicts_forget(st.days[0]);
	memmove(st.days, st.days + 1, (st.ndays - 1) * sizeof(*st.days));
	st.ndays--;
}

static void enforce_retention_locked(void)
{
	size_t limit = st.cfg.days < 1 ? 1 : (size_t)st.cfg.days;

	while (st.ndays > limit - 1) {
		drop_oldest_locked();
	}

	while (st.ndays > 0 && disk_usage() > st.cfg.max_bytes) {
		drop_oldest_locked();
	}

	set_size_log(disk_usage());
}

static int write_tail(struct current *c, int file, const uint8_t *data, size_t len)
{
	size_t done = 0;

	if (len == 0) {
		return 0;
	}

	while (done < len) {
		ssize_t n = pwrite(c->fds[file], data + done, len - done, (off_t)(c->sizes[file] + (int64_t)done));
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			return -1;
		}

		done += (size_t)n;
	}

	c->sizes[file] += (int64_t)len;
	return fsync(c->fds[file]);
}

static void put_le(uint8_t *p, uint32_t v, int width)
{
	for (int i = 0; i < width; i++) {
		p[i] = (uint8_t)(v >> (8 * i));
	}
}

static void rollback_columns(struct current *c)
{
	for (int col = 0; col < NUM_COLS; col++) {
		int64_t size = (int64_t)(c->flushed * (size_t)col_width[col]);
		if (ftruncate(c->fds[col], size) != 0) {
			continue;
		}

		c->sizes[col] = size;
	}
}

static int save_state(void)
{
	char path[600];
	char data[128];
	uint64_t total = 0;
	uint64_t blocked = 0;
	uint64_t failed = 0;

	store_totals(&total, &blocked, &failed);
	int n = snprintf(data, sizeof(data), "{\"total\":%llu,\"blocked\":%llu,\"failed\":%llu}", (unsigned long long)total,
					 (unsigned long long)blocked, (unsigned long long)failed);
	snprintf(path, sizeof(path), "%s/state.json", st.cfg.dir);
	return atomic_write(path, data, (size_t)n);
}

static int flush_locked(void)
{
	struct current *c = st.cur;
	struct buf b = {0};
	uint8_t *cols[NUM_COLS];
	int ret = -1;

	for (uint32_t id = c->dom_flushed; id < c->doms.arena->count; id++) {
		size_t n = 0;
		const uint8_t *name = arena_get(c->doms.arena, id, &n);
		buf_add(&b, name - 2, n + 2);
	}

	if (write_tail(c, DICT_DOM, (const uint8_t *)b.data, b.len) != 0) {
		buf_free(&b);
		return -1;
	}

	c->dom_flushed = c->doms.arena->count;
	b.len = 0;
	for (size_t i = c->cli_flushed; i < c->nclis; i++) {
		buf_add(&b, c->clis[i], CLIENT_KEY_LEN);
	}

	if (write_tail(c, DICT_CLI, (const uint8_t *)b.data, b.len) != 0) {
		buf_free(&b);
		return -1;
	}

	c->cli_flushed = c->nclis;
	b.len = 0;
	for (size_t i = c->grp_flushed; i < c->ngroups; i++) {
		buf_byte(&b, (char)c->groups[i].len);
		buf_add(&b, c->groups[i].data, c->groups[i].len);
	}

	if (write_tail(c, DICT_GRP, (const uint8_t *)b.data, b.len) != 0) {
		buf_free(&b);
		return -1;
	}

	buf_free(&b);
	c->grp_flushed = c->ngroups;
	for (int col = 0; col < NUM_COLS; col++) {
		cols[col] = xmalloc(c->npending * (size_t)col_width[col]);
	}

	for (size_t i = 0; i < c->npending; i++) {
		const struct rec *r = &c->pending[i];
		put_le(cols[COL_TMS] + i * 4, r->tms, 4);
		put_le(cols[COL_DOM] + i * 3, r->dom, 3);
		put_le(cols[COL_CLI] + i * 2, r->cli, 2);
		cols[COL_GRP][i] = r->grp;
		put_le(cols[COL_QTYPE] + i * 2, r->qtype, 2);
		cols[COL_RCODE][i] = r->rcode;
		cols[COL_FLAGS][i] = r->flags;
		put_le(cols[COL_QMS] + i * 2, r->qms, 2);
		put_le(cols[COL_PING] + i * 2, r->ping, 2);
		cols[COL_BLK][i] = r->blk;
	}

	for (int col = 0; col < NUM_COLS; col++) {
		if (write_tail(c, col, cols[col], c->npending * (size_t)col_width[col]) != 0) {
			rollback_columns(c);
			goto out;
		}
	}

	c->flushed += c->npending;
	c->npending = 0;
	set_size_log(disk_usage());
	if (sum_write(c) != 0) {
		goto out;
	}

	ret = save_state();
out:
	for (int col = 0; col < NUM_COLS; col++) {
		free(cols[col]);
	}

	return ret;
}

static void rollover_locked(int64_t day)
{
	struct current *old = st.cur;

	flush_locked();
	if (open_current(day) != 0) {
		st.cur = old;
		return;
	}

	st.days = xrealloc(st.days, (st.ndays + 1) * sizeof(*st.days));
	st.days[st.ndays++] = old->day;
	sum_forget(old->day);
	current_free(old);
	enforce_retention_locked();
	sums_prune();
}

static uint16_t clamp_u16(uint32_t v)
{
	return v > 0xFFFE ? 0xFFFE : (uint16_t)v;
}

void store_add(const struct ui_query *q)
{
	uint8_t key[CLIENT_KEY_LEN];
	int blocked = (q->flags & QUERY_BLOCKED) != 0;

	pthread_mutex_lock(&st.cnt_mu);
	st.total++;
	st.tick++;
	st.blocked += blocked;
	st.failed += q->rcode != 0;
	pthread_mutex_unlock(&st.cnt_mu);

	pthread_rwlock_wrlock(&st.mu);
	struct current *c = st.cur;
	if (c == NULL) {
		pthread_rwlock_unlock(&st.mu);
		return;
	}

	int64_t day = (int64_t)(q->time_ms / (uint64_t)DAY_MILLIS);
	if (day > c->day) {
		rollover_locked(day);
		c = st.cur;
	}

	struct rec r = {0};
	if (day == c->day) {
		r.tms = (uint32_t)(q->time_ms % (uint64_t)DAY_MILLIS);
	}

	key[0] = q->family;
	memcpy(key + 1, q->addr, ADDR_LEN);
	if (q->flags & QUERY_HAS_MAC) {
		memcpy(key + 1 + ADDR_LEN, q->mac, MAC_LEN);
	} else {
		memset(key + 1 + ADDR_LEN, 0, MAC_LEN);
	}

	r.cli = cli_intern(c, key);
	r.dom = domtab_intern(&c->doms, q->domain, q->domain_len);
	r.grp = grp_intern(c, q->group, q->group_len);
	r.qtype = q->qtype;
	r.rcode = q->rcode;
	r.qms = clamp_u16(q->query_ms);
	r.ping = q->ping_tenths < 0 ? PING_NONE : clamp_u16((uint32_t)q->ping_tenths);
	r.blk = q->block_list;
	r.flags = (uint8_t)((blocked ? FLAG_BLOCKED : 0) | ((q->flags & QUERY_CACHED) ? FLAG_CACHED : 0));
	c->doms.counts[r.dom]++;
	if (blocked) {
		c->doms.blocked[r.dom]++;
	}

	cli_note(&c->cli_stats[r.cli], r.tms, blocked, r.rcode);
	c->slots[r.tms / SLOT_MILLIS]++;
	if (c->npending == c->pending_cap) {
		c->pending_cap = c->pending_cap ? c->pending_cap * 2 : 1024;
		c->pending = xrealloc(c->pending, c->pending_cap * sizeof(*c->pending));
	}

	c->pending[c->npending++] = r;
	pthread_rwlock_unlock(&st.mu);
}

int store_flush(void)
{
	pthread_rwlock_wrlock(&st.mu);
	int ret = st.cur == NULL ? -1 : flush_locked();
	pthread_rwlock_unlock(&st.mu);
	return ret;
}

static void load_state(void)
{
	char path[600];
	struct buf data = {0};
	struct jval v;
	uint64_t total = 0;
	uint64_t blocked = 0;
	uint64_t failed = 0;

	snprintf(path, sizeof(path), "%s/state.json", st.cfg.dir);
	if (read_file(path, &data) != 0) {
		return;
	}

	if (json_parse(data.data, data.len, &v) == 0 && v.type == J_OBJ && json_as_u64(json_get(&v, "total"), &total) == 0 &&
		json_as_u64(json_get(&v, "blocked"), &blocked) == 0 && json_as_u64(json_get(&v, "failed"), &failed) == 0) {
		st.total = total;
		st.blocked = blocked;
		st.failed = failed;
	}

	json_free(&v);
	buf_free(&data);
}

static int cmp_i64(const void *a, const void *b)
{
	int64_t x = *(const int64_t *)a;
	int64_t y = *(const int64_t *)b;
	return x < y ? -1 : x > y;
}

static int list_days(int64_t **out, size_t *n)
{
	char path[600];
	char child[1024];
	struct dirent *ent = NULL;
	struct stat sb;

	log_dir(path, sizeof(path));
	DIR *dir = opendir(path);
	if (dir == NULL) {
		return -1;
	}

	*out = NULL;
	*n = 0;
	while ((ent = readdir(dir)) != NULL) {
		int64_t day = 0;
		if (strlen(ent->d_name) != 10 || parse_day(ent->d_name, &day) != 0) {
			continue;
		}

		snprintf(child, sizeof(child), "%s/%s", path, ent->d_name);
		if (stat(child, &sb) != 0 || !S_ISDIR(sb.st_mode)) {
			continue;
		}

		*out = xrealloc(*out, (*n + 1) * sizeof(**out));
		(*out)[(*n)++] = day;
	}

	closedir(dir);
	if (*n > 1) {
		qsort(*out, *n, sizeof(**out), cmp_i64);
	}
	return 0;
}

int store_open(const struct store_config *cfg)
{
	char path[600];
	int64_t *days = NULL;
	size_t ndays = 0;

	st.cfg = *cfg;
	if (st.cfg.flush_seconds < 1) {
		st.cfg.flush_seconds = 1;
	}

	log_dir(path, sizeof(path));
	if (mkdir_all(path) != 0) {
		return -1;
	}

	snprintf(path, sizeof(path), "%s/sum", st.cfg.dir);
	if (mkdir_all(path) != 0) {
		return -1;
	}

	load_state();
	if (list_days(&days, &ndays) != 0) {
		return -1;
	}

	int64_t cur = now_ms() / DAY_MILLIS;
	if (ndays > 0 && days[ndays - 1] > cur) {
		cur = days[ndays - 1];
	}

	for (size_t i = 0; i < ndays; i++) {
		if (days[i] < cur) {
			st.days = xrealloc(st.days, (st.ndays + 1) * sizeof(*st.days));
			st.days[st.ndays++] = days[i];
		}
	}

	free(days);
	if (open_current(cur) != 0) {
		return -1;
	}

	pthread_rwlock_wrlock(&st.mu);
	enforce_retention_locked();
	pthread_rwlock_unlock(&st.mu);
	sums_prune();
	store_refresh_tops();

	int64_t now = now_ms();
	st.next_flush = now + (int64_t)st.cfg.flush_seconds * 1000;
	st.next_second = now + 1000;
	st.next_hour = now + 3600 * 1000;
	return 0;
}

void store_close(void)
{
	store_flush();
	pthread_rwlock_wrlock(&st.mu);
	current_free(st.cur);
	st.cur = NULL;
	pthread_rwlock_unlock(&st.mu);
}

static int64_t advance(int64_t next, int64_t period, int64_t now)
{
	next += period;
	return next <= now ? now + period : next;
}

int64_t store_next_tick(int64_t now)
{
	int64_t next = st.next_second;
	if (st.next_flush < next) {
		next = st.next_flush;
	}

	if (st.next_hour < next) {
		next = st.next_hour;
	}

	return next < now ? now : next;
}

void store_tick(int64_t now)
{
	if (now >= st.next_second) {
		pthread_mutex_lock(&st.cnt_mu);
		st.rate = st.tick;
		st.tick = 0;
		pthread_mutex_unlock(&st.cnt_mu);
		st.next_second = advance(st.next_second, 1000, now);
	}

	if (now >= st.next_flush) {
		store_flush();
		st.next_flush = advance(st.next_flush, (int64_t)st.cfg.flush_seconds * 1000, now);
	}

	if (now >= st.next_hour) {
		store_refresh_tops();
		st.next_hour = advance(st.next_hour, 3600 * 1000, now);
	}
}

void store_totals(uint64_t *total, uint64_t *blocked, uint64_t *failed)
{
	pthread_mutex_lock(&st.cnt_mu);
	*total = st.total;
	*blocked = st.blocked;
	*failed = st.failed;
	pthread_mutex_unlock(&st.cnt_mu);
}

uint64_t store_rate(void)
{
	pthread_mutex_lock(&st.cnt_mu);
	uint64_t rate = st.rate;
	pthread_mutex_unlock(&st.cnt_mu);
	return rate;
}

int64_t store_log_bytes(void)
{
	pthread_mutex_lock(&st.cnt_mu);
	int64_t size = st.size_log;
	pthread_mutex_unlock(&st.cnt_mu);
	return size;
}

int store_clear(char *err, size_t err_len)
{
	char path[600];
	int ret = 0;

	pthread_rwlock_wrlock(&st.mu);
	if (st.cur == NULL) {
		snprintf(err, err_len, "store: closed");
		pthread_rwlock_unlock(&st.mu);
		return -1;
	}

	if (flush_locked() != 0) {
		snprintf(err, err_len, "%s", strerror(errno));
		pthread_rwlock_unlock(&st.mu);
		return -1;
	}

	int64_t day = st.cur->day;
	current_free(st.cur);
	st.cur = NULL;
	dicts_reset();
	log_dir(path, sizeof(path));
	if (remove_all(path) != 0 || mkdir_all(path) != 0) {
		snprintf(err, err_len, "%s", strerror(errno));
		pthread_rwlock_unlock(&st.mu);
		return -1;
	}

	st.ndays = 0;
	set_size_log(0);
	if (open_current(day) != 0) {
		snprintf(err, err_len, "store: reopen after clear: %s", strerror(errno));
		ret = -1;
	}

	pthread_rwlock_unlock(&st.mu);
	return ret;
}

static int open_columns(struct seg_view *v, const char *dir)
{
	char path[768];

	for (int i = 0; i < NUM_COLS; i++) {
		snprintf(path, sizeof(path), "%s/%s", dir, file_names[i]);
		v->fds[i] = open(path, O_RDONLY | O_CLOEXEC);
		if (v->fds[i] < 0 && late_column(i) && errno == ENOENT) {
			continue;
		}

		if (v->fds[i] < 0) {
			for (int j = 0; j < i; j++) {
				if (v->fds[j] >= 0) {
					close(v->fds[j]);
					v->fds[j] = -1;
				}
			}

			return -1;
		}
	}

	return 0;
}

static void close_columns(struct seg_view *v)
{
	for (int i = 0; i < NUM_COLS; i++) {
		if (v->fds[i] >= 0) {
			close(v->fds[i]);
			v->fds[i] = -1;
		}
	}
}

struct views *store_views(void)
{
	struct views *vs = xcalloc(1, sizeof(*vs));
	char dir[640];

	pthread_rwlock_rdlock(&st.mu);
	struct current *c = st.cur;
	vs->n = st.ndays + (c != NULL);
	vs->v = xcalloc(vs->n, sizeof(*vs->v));
	for (size_t i = 0; i < vs->n; i++) {
		for (int col = 0; col < NUM_COLS; col++) {
			vs->v[i].fds[col] = -1;
		}
	}

	for (size_t i = 0; i < st.ndays; i++) {
		vs->v[i].day = st.days[i];
	}

	if (c != NULL) {
		struct seg_view *v = &vs->v[st.ndays];
		struct dict *d = xcalloc(1, sizeof(*d));
		d->refs = 1;
		d->day = c->day;
		d->arena = arena_ref(c->doms.arena);
		d->ndom = c->doms.arena->count;
		d->nclients = c->nclis;
		d->clients = xmalloc(c->nclis * CLIENT_KEY_LEN);
		if (c->nclis > 0) {
			memcpy(d->clients, c->clis, c->nclis * CLIENT_KEY_LEN);
		}
		d->ngroups = c->ngroups;
		d->groups = xcalloc(c->ngroups, sizeof(*d->groups));
		for (size_t i = 0; i < c->ngroups; i++) {
			d->groups[i].data = xstrndup(c->groups[i].data, c->groups[i].len);
			d->groups[i].len = c->groups[i].len;
		}

		v->day = c->day;
		v->opened = 1;
		v->dict = d;
		v->nflushed = c->flushed;
		v->npending = c->npending;
		v->pending = xmalloc(c->npending * sizeof(*v->pending));
		if (c->npending > 0) {
			memcpy(v->pending, c->pending, c->npending * sizeof(*v->pending));
		}
		v->nrec = v->nflushed + v->npending;
		snprintf(dir, sizeof(dir), "%s", c->dir);
	}

	pthread_rwlock_unlock(&st.mu);
	if (c != NULL && open_columns(&vs->v[vs->n - 1], dir) != 0) {
		vs->v[vs->n - 1].empty = 1;
	}

	return vs;
}

void views_release(struct views *vs)
{
	if (vs == NULL) {
		return;
	}

	for (size_t i = 0; i < vs->n; i++) {
		close_columns(&vs->v[i]);
		free(vs->v[i].pending);
		dict_unref(vs->v[i].dict);
	}

	free(vs->v);
	free(vs);
}

void seg_open(struct seg_view *v)
{
	char dir[640];
	size_t records = SIZE_MAX;

	if (v->opened) {
		return;
	}

	v->opened = 1;
	seg_dir(v->day, dir, sizeof(dir));
	if (open_columns(v, dir) != 0) {
		v->empty = 1;
		return;
	}

	for (int i = 0; i < NUM_COLS; i++) {
		int64_t size = 0;
		if (late_column(i)) {
			continue;
		}

		if (fd_size(v->fds[i], &size) != 0) {
			close_columns(v);
			v->empty = 1;
			return;
		}

		size_t n = (size_t)size / (size_t)col_width[i];
		if (n < records) {
			records = n;
		}
	}

	v->dict = dict_load(v->day);
	if (v->dict == NULL) {
		close_columns(v);
		v->empty = 1;
		return;
	}

	v->nrec = records;
	v->nflushed = records;
}

static struct dict *dict_from_files(int64_t day)
{
	char dir[640];
	char path[768];
	uint8_t *dom = NULL;
	size_t dom_len = 0;
	struct buf cli = {0};
	struct buf grp = {0};
	int fd = -1;

	seg_dir(day, dir, sizeof(dir));
	snprintf(path, sizeof(path), "%s/%s", dir, file_names[DICT_DOM]);
	fd = open(path, O_RDONLY | O_CLOEXEC);
	if (fd < 0 || read_fd(fd, &dom, &dom_len) != 0) {
		if (fd >= 0) {
			close(fd);
		}

		return NULL;
	}

	close(fd);
	snprintf(path, sizeof(path), "%s/%s", dir, file_names[DICT_CLI]);
	if (read_file(path, &cli) != 0) {
		free(dom);
		return NULL;
	}

	snprintf(path, sizeof(path), "%s/%s", dir, file_names[DICT_GRP]);
	if (read_file(path, &grp) != 0) {
		free(dom);
		buf_free(&cli);
		return NULL;
	}

	struct dict *d = xcalloc(1, sizeof(*d));
	d->refs = 1;
	d->day = day;
	d->arena = arena_new();
	arena_load(d->arena, dom, dom_len);
	d->ndom = d->arena->count;
	d->nclients = cli.len / CLIENT_KEY_LEN;
	d->clients = xmalloc(d->nclients * CLIENT_KEY_LEN);
	memcpy(d->clients, cli.data, d->nclients * CLIENT_KEY_LEN);
	const uint8_t *g = (const uint8_t *)grp.data;
	size_t off = 0;
	while (off < grp.len && off + 1 + g[off] <= grp.len) {
		d->groups = xrealloc(d->groups, (d->ngroups + 1) * sizeof(*d->groups));
		d->groups[d->ngroups].data = xstrndup((const char *)g + off + 1, g[off]);
		d->groups[d->ngroups].len = g[off];
		d->ngroups++;
		off += 1 + (size_t)g[off];
	}

	buf_free(&cli);
	buf_free(&grp);
	return d;
}

struct dict *dict_load(int64_t day)
{
	pthread_mutex_lock(&dict_mu);
	for (size_t i = 0; i < dict_cached; i++) {
		if (dict_cache[i]->day == day) {
			struct dict *d = dict_ref(dict_cache[i]);
			pthread_mutex_unlock(&dict_mu);
			return d;
		}
	}

	pthread_mutex_unlock(&dict_mu);
	struct dict *d = dict_from_files(day);
	if (d == NULL) {
		return NULL;
	}

	pthread_mutex_lock(&dict_mu);
	if (dict_cached == DICT_CACHE) {
		dict_unref(dict_cache[0]);
		memmove(dict_cache, dict_cache + 1, (DICT_CACHE - 1) * sizeof(*dict_cache));
		dict_cached--;
	}

	dict_cache[dict_cached++] = dict_ref(d);
	pthread_mutex_unlock(&dict_mu);
	return d;
}

void dicts_forget(int64_t day)
{
	pthread_mutex_lock(&dict_mu);
	size_t kept = 0;
	for (size_t i = 0; i < dict_cached; i++) {
		if (dict_cache[i]->day == day) {
			dict_unref(dict_cache[i]);
		} else {
			dict_cache[kept++] = dict_cache[i];
		}
	}

	dict_cached = kept;
	pthread_mutex_unlock(&dict_mu);
}

void dicts_reset(void)
{
	pthread_mutex_lock(&dict_mu);
	for (size_t i = 0; i < dict_cached; i++) {
		dict_unref(dict_cache[i]);
	}

	dict_cached = 0;
	pthread_mutex_unlock(&dict_mu);
}

void sum_path(int64_t day, char *out, size_t len)
{
	char name[11];
	day_name(day, name);
	snprintf(out, len, "%s/sum/%s.bin", st.cfg.dir, name);
}

void sums_prune(void)
{
	char path[600];
	char child[1024];
	struct dirent *ent = NULL;
	int64_t today = now_ms() / DAY_MILLIS;

	snprintf(path, sizeof(path), "%s/sum", st.cfg.dir);
	DIR *dir = opendir(path);
	if (dir == NULL) {
		return;
	}

	while ((ent = readdir(dir)) != NULL) {
		char prefix[11];
		int64_t day = 0;
		if (strlen(ent->d_name) < 10) {
			continue;
		}

		memcpy(prefix, ent->d_name, 10);
		prefix[10] = '\0';
		if (parse_day(prefix, &day) == 0 && today - day >= SUM_KEEP_DAYS) {
			snprintf(child, sizeof(child), "%s/%s", path, ent->d_name);
			unlink(child);
			sum_forget(day);
		}
	}

	closedir(dir);
}
