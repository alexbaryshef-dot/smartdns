#ifndef HRDNS_UI_H
#define HRDNS_UI_H

#include <pthread.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

#define UI_LOG_DEBUG 0
#define UI_LOG_INFO 1
#define UI_LOG_NOTICE 2
#define UI_LOG_WARN 3

#define DAY_MILLIS 86400000LL
#define SLOT_MILLIS 900000
#define SLOTS_PER_DAY 96
#define ADDR_LEN 16
#define MAC_LEN 6
#define CLIENT_KEY_LEN (1 + ADDR_LEN + MAC_LEN)
#define ADDR_STR_LEN 48
#define MAC_STR_LEN 18

struct buf {
	char *data;
	size_t len;
	size_t cap;
};

void *xmalloc(size_t size);
void *xcalloc(size_t count, size_t size);
void *xrealloc(void *ptr, size_t size);
char *xstrndup(const char *s, size_t len);

void buf_reserve(struct buf *b, size_t extra);
void buf_add(struct buf *b, const void *data, size_t len);
void buf_str(struct buf *b, const char *s);
void buf_byte(struct buf *b, char c);
void buf_fmt(struct buf *b, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void buf_free(struct buf *b);

void json_str(struct buf *b, const void *data, size_t len);
void json_cstr(struct buf *b, const char *s);
void json_key(struct buf *b, const char *key);
void json_u64(struct buf *b, uint64_t v);
void json_i64(struct buf *b, int64_t v);
void json_float(struct buf *b, double v);
void json_bool(struct buf *b, int v);

enum jtype { J_NULL, J_BOOL, J_NUM, J_STR, J_ARR, J_OBJ };

struct jval {
	enum jtype type;
	const char *raw;
	size_t raw_len;
	int boolean;
	char *str;
	size_t len;
	struct jval *items;
	char **keys;
	size_t count;
};

int json_parse(const char *text, size_t len, struct jval *out);
void json_free(struct jval *v);
const struct jval *json_get(const struct jval *obj, const char *key);
int json_as_u64(const struct jval *v, uint64_t *out);
int json_as_i64(const struct jval *v, int64_t *out);
int json_as_double(const struct jval *v, double *out);

int64_t now_ms(void);
void day_name(int64_t day, char out[11]);
int parse_day(const char *name, int64_t *day);
void format_addr(uint8_t family, const uint8_t addr[ADDR_LEN], char out[ADDR_STR_LEN]);
void format_mac(const uint8_t mac[MAC_LEN], char out[MAC_STR_LEN]);
int mac_is_zero(const uint8_t mac[MAC_LEN]);
int mkdir_all(const char *path);
int remove_all(const char *path);
int atomic_write(const char *path, const void *data, size_t len);
int read_file(const char *path, struct buf *out);

struct ui_query {
	uint64_t time_ms;
	uint32_t query_ms;
	int32_t ping_tenths;
	uint16_t qtype;
	uint8_t rcode;
	uint8_t flags;
	uint8_t family;
	uint8_t addr[ADDR_LEN];
	uint8_t mac[MAC_LEN];
	uint8_t block_list;
	const uint8_t *group;
	size_t group_len;
	const uint8_t *domain;
	size_t domain_len;
};

#define QUERY_BLOCKED 1
#define QUERY_CACHED 2
#define QUERY_HAS_MAC 4

struct link_hello {
	char *build;
	char *server_name;
	int64_t started_ms;
};

int link_open(int fd);
const struct link_hello *link_hello(void);
int link_start(int wake_fd);
int link_subscribe(void);
int link_closed(void);
void link_stop(void);
int link_call(const char *command, int timeout_ms, struct buf *data, struct buf *err);
void link_log(int level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void link_acquire(int logs, int audit);
void link_release(int logs, int audit);

#define HUB_LOG 0
#define HUB_AUDIT 1

int hub_active(int hub);
void hub_publish(int hub, const uint8_t *prefix, size_t prefix_len, const uint8_t *text, size_t len);
uint64_t hub_subscribe(int hub);
void hub_unsubscribe(int hub);
int hub_take(int hub, uint64_t *seq, struct buf *msg);

struct store_config {
	char dir[512];
	int days;
	int64_t max_bytes;
	int flush_seconds;
};

enum tri { TRI_ANY, TRI_YES, TRI_NO };

struct filter {
	const char *domain;
	const char *domain_mode;
	int qtype;
	int has_qtype;
	const char *client;
	const char *group;
	int has_group;
	int rcode;
	int has_rcode;
	enum tri blocked;
	enum tri cached;
	int64_t after;
	int64_t before;
};

struct page_spec {
	uint64_t num;
	uint64_t size;
	int asc;
	uint64_t cursor;
	int has_cursor;
	int prev;
	int total_given;
	uint64_t total;
};

struct record {
	uint64_t id;
	int64_t time_ms;
	const uint8_t *domain;
	size_t domain_len;
	uint16_t qtype;
	char client[ADDR_STR_LEN];
	uint8_t mac[MAC_LEN];
	const char *group;
	size_t group_len;
	uint8_t rcode;
	uint32_t query_ms;
	int32_t ping_tenths;
	int blocked;
	uint8_t block_list;
	int cached;
};

struct views;

struct list_result {
	struct record *records;
	size_t count;
	uint64_t total;
	int step_by_cursor;
	int truncated;
	struct views *views;
};

struct top_name {
	char *name;
	size_t len;
	uint64_t count;
};

struct top_client {
	uint8_t key[CLIENT_KEY_LEN];
	uint64_t count;
	uint64_t blocked;
	uint64_t failed;
	int64_t last;
};

struct bucket {
	int64_t key;
	uint64_t count;
};

int store_open(const struct store_config *cfg);
void store_close(void);
void store_add(const struct ui_query *q);
int store_flush(void);
void store_tick(int64_t now);
int64_t store_next_tick(int64_t now);
void store_totals(uint64_t *total, uint64_t *blocked, uint64_t *failed);
uint64_t store_rate(void);
int64_t store_log_bytes(void);
int store_clear(char *err, size_t err_len);
void store_list(const struct filter *f, const struct page_spec *p, int budget_ms, struct list_result *out);
void store_list_free(struct list_result *res);
uint64_t store_count(const struct filter *f, int budget_ms, int *complete);
int store_get(uint64_t id, struct record *out, struct views **views);
void views_release(struct views *v);
void store_refresh_tops(void);
size_t store_top_clients(size_t count, struct top_client **out, int64_t *start, int64_t *end);
size_t store_top_domains(size_t count, int blocked, struct top_name **out, int64_t *start, int64_t *end);
void store_tops_release(void);
size_t store_hourly(int hours, int64_t now, struct bucket **out);
size_t store_daily(int days, int64_t now, struct bucket **out);
void bucket_label(int64_t key, int daily, char out[96]);

struct www_file {
	const char *name;
	int gz;
	const char *tag;
	const char *mime;
	const char *csp;
	const unsigned char *data;
	const unsigned char *end;
	const unsigned char *plain;
	const unsigned char *plain_end;
};

const struct www_file *www_find(const char *name);

struct http_request {
	const char *method;
	char *path;
	char *query;
	int minor;
	size_t header_count;
	const char *header_names[64];
	const char *header_values[64];
	const char *body;
	size_t body_len;
};

const char *http_header(const struct http_request *r, const char *name);
int http_header_has(const struct http_request *r, const char *name, const char *token);
int http_query(const struct http_request *r, const char *key, struct buf *value);

struct http_response {
	int status;
	int upgraded;
	struct buf headers;
	struct buf body;
	const unsigned char *static_body;
	size_t static_len;
};

void resp_header(struct http_response *resp, const char *name, const char *value);

enum ws_kind { WS_METRICS, WS_LOG, WS_AUDIT };

#define WS_TEXT 1
#define WS_BINARY 2

struct http_conn {
	int fd;
	struct buf in;
	struct buf out;
	size_t out_off;
	const unsigned char *body;
	size_t body_len;
	size_t body_off;
	int close_after;
	int64_t idle_deadline;
	int64_t header_deadline;
	int64_t write_since;
	int ws;
	enum ws_kind ws_kind;
	uint64_t hub_seq;
	int paused;
	int prev_level;
	int64_t next_metrics;
	struct buf ws_msg;
	int ws_op;
	int dead;
	struct http_conn *next;
};

int ws_is_upgrade(const struct http_request *r);
int ws_accept(struct http_conn *c, const struct http_request *r, enum ws_kind kind);
void ws_send(struct http_conn *c, int opcode, const void *data, size_t len);

void api_handle(struct http_conn *c, const struct http_request *r, struct http_response *resp);
void api_metrics_json(struct buf *b);
void api_ws_opened(struct http_conn *c);
void api_ws_message(struct http_conn *c, const uint8_t *data, size_t len);
void api_ws_closed(struct http_conn *c);
void static_handle(const struct http_request *r, struct http_response *resp);

struct api_options {
	char data_dir[512];
	pid_t resolver_pid;
};

void api_init(const struct api_options *opts);

int http_serve(const char *listen_spec, const char *data_dir, int wake_fd, int signal_fd);

int hrdns_ui_main(int argc, char *argv[]);

#endif
