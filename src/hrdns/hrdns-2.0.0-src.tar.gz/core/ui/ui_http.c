#define _GNU_SOURCE

#include "ui.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <openssl/evp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/epoll.h>
#include <sys/signalfd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#define MAX_HEADER (32 << 10)
#define MAX_BODY (64 << 10)
#define HEADER_TIMEOUT_MS 10000
#define IDLE_TIMEOUT_MS 120000
#define WRITE_TIMEOUT_MS 10000
#define WS_MAX_MESSAGE (1 << 20)
#define WS_MAX_PENDING (1 << 20)
#define WS_DROP_PENDING (256 << 10)
#define METRICS_PERIOD_MS 1000
#define WS_GUID "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

static struct {
	int epfd;
	int listen_fd;
	int stopping;
	char unix_path[256];
	struct http_conn *conns;
} srv = {.epfd = -1, .listen_fd = -1};

static const char *status_text(int status)
{
	switch (status) {
	case 101:
		return "Switching Protocols";
	case 200:
		return "OK";
	case 204:
		return "No Content";
	case 301:
		return "Moved Permanently";
	case 304:
		return "Not Modified";
	case 400:
		return "Bad Request";
	case 404:
		return "Not Found";
	case 405:
		return "Method Not Allowed";
	case 406:
		return "Not Acceptable";
	case 411:
		return "Length Required";
	case 413:
		return "Request Entity Too Large";
	case 431:
		return "Request Header Fields Too Large";
	case 500:
		return "Internal Server Error";
	case 501:
		return "Not Implemented";
	default:
		return "Unknown";
	}
}

const char *http_header(const struct http_request *r, const char *name)
{
	for (size_t i = 0; i < r->header_count; i++) {
		if (strcasecmp(r->header_names[i], name) == 0) {
			return r->header_values[i];
		}
	}

	return NULL;
}

static int token_in(const char *value, const char *token)
{
	size_t tlen = strlen(token);
	const char *p = value;

	while (*p) {
		const char *end = strchr(p, ',');
		if (end == NULL) {
			end = p + strlen(p);
		}

		const char *a = p;
		const char *b = end;
		while (a < b && (*a == ' ' || *a == '\t')) {
			a++;
		}

		while (b > a && (b[-1] == ' ' || b[-1] == '\t')) {
			b--;
		}

		if ((size_t)(b - a) == tlen && strncasecmp(a, token, tlen) == 0) {
			return 1;
		}

		if (*end == '\0') {
			break;
		}

		p = end + 1;
	}

	return 0;
}

int http_header_has(const struct http_request *r, const char *name, const char *token)
{
	for (size_t i = 0; i < r->header_count; i++) {
		if (strcasecmp(r->header_names[i], name) == 0 && token_in(r->header_values[i], token)) {
			return 1;
		}
	}

	return 0;
}

static int unhex(char c)
{
	if (c >= '0' && c <= '9') {
		return c - '0';
	}

	if (c >= 'a' && c <= 'f') {
		return c - 'a' + 10;
	}

	if (c >= 'A' && c <= 'F') {
		return c - 'A' + 10;
	}

	return -1;
}

static int unescape(const char *s, size_t len, int plus, struct buf *out)
{
	out->len = 0;
	buf_reserve(out, len);
	for (size_t i = 0; i < len; i++) {
		if (s[i] == '%') {
			int hi = i + 2 < len ? unhex(s[i + 1]) : -1;
			int lo = hi < 0 ? -1 : unhex(s[i + 2]);
			if (lo < 0) {
				return -1;
			}

			buf_byte(out, (char)(hi << 4 | lo));
			i += 2;
		} else if (plus && s[i] == '+') {
			buf_byte(out, ' ');
		} else {
			buf_byte(out, s[i]);
		}
	}

	out->data[out->len] = '\0';
	return 0;
}

int http_query(const struct http_request *r, const char *key, struct buf *value)
{
	const char *p = r->query;
	struct buf k = {0};
	int found = 0;

	while (p != NULL && *p != '\0' && !found) {
		const char *end = strchr(p, '&');
		size_t len = end ? (size_t)(end - p) : strlen(p);
		const char *eq = memchr(p, '=', len);
		size_t klen = eq ? (size_t)(eq - p) : len;

		if (memchr(p, ';', len) == NULL && unescape(p, klen, 1, &k) == 0 && strcmp(k.data, key) == 0) {
			const char *v = eq ? eq + 1 : p + len;
			size_t vlen = eq ? len - klen - 1 : 0;
			if (unescape(v, vlen, 1, value) == 0) {
				found = 1;
			} else {
				value->len = 0;
				value->data[0] = '\0';
			}
		}

		p = end ? end + 1 : NULL;
	}

	buf_free(&k);
	return found;
}

void resp_header(struct http_response *resp, const char *name, const char *value)
{
	buf_fmt(&resp->headers, "%s: %s\r\n", name, value);
}

static void conn_watch(struct http_conn *c)
{
	struct epoll_event ev = {.events = EPOLLIN | EPOLLRDHUP, .data.ptr = c};
	if (c->out.len > c->out_off || c->body_off < c->body_len) {
		ev.events |= EPOLLOUT;
	}

	epoll_ctl(srv.epfd, EPOLL_CTL_MOD, c->fd, &ev);
}

static void conn_close(struct http_conn *c)
{
	if (c->dead) {
		return;
	}

	c->dead = 1;
	if (c->ws && !srv.stopping) {
		api_ws_closed(c);
	}

	epoll_ctl(srv.epfd, EPOLL_CTL_DEL, c->fd, NULL);
	close(c->fd);
}

static void sweep_dead(void)
{
	struct http_conn **pp = &srv.conns;

	while (*pp != NULL) {
		struct http_conn *c = *pp;
		if (!c->dead) {
			pp = &c->next;
			continue;
		}

		*pp = c->next;
		buf_free(&c->in);
		buf_free(&c->out);
		buf_free(&c->ws_msg);
		free(c);
	}
}

static int conn_flush(struct http_conn *c)
{
	while (c->out.len > c->out_off) {
		ssize_t n = send(c->fd, c->out.data + c->out_off, c->out.len - c->out_off, MSG_NOSIGNAL);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
			return 0;
		}

		if (n <= 0) {
			return -1;
		}

		c->out_off += (size_t)n;
		c->write_since = now_ms();
	}

	c->out.len = 0;
	c->out_off = 0;
	while (c->body_off < c->body_len) {
		ssize_t n = send(c->fd, c->body + c->body_off, c->body_len - c->body_off, MSG_NOSIGNAL);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
			return 0;
		}

		if (n <= 0) {
			return -1;
		}

		c->body_off += (size_t)n;
		c->write_since = now_ms();
	}

	c->body = NULL;
	c->body_len = 0;
	c->body_off = 0;
	return 1;
}

static int conn_pending(const struct http_conn *c)
{
	return c->out.len > c->out_off || c->body_off < c->body_len;
}

static void conn_send(struct http_conn *c)
{
	if (c->dead || !conn_pending(c)) {
		return;
	}

	if (c->write_since == 0) {
		c->write_since = now_ms();
	}

	int done = conn_flush(c);
	if (done < 0) {
		conn_close(c);
		return;
	}

	if (done == 1) {
		c->write_since = 0;
		if (c->close_after) {
			conn_close(c);
			return;
		}
	}

	conn_watch(c);
}

void ws_send(struct http_conn *c, int opcode, const void *data, size_t len)
{
	uint8_t hdr[10];
	size_t n = 2;

	hdr[0] = (uint8_t)(0x80 | opcode);
	if (len < 126) {
		hdr[1] = (uint8_t)len;
	} else if (len <= 0xFFFF) {
		hdr[1] = 126;
		hdr[2] = (uint8_t)(len >> 8);
		hdr[3] = (uint8_t)len;
		n = 4;
	} else {
		hdr[1] = 127;
		for (int i = 0; i < 8; i++) {
			hdr[2 + i] = (uint8_t)((uint64_t)len >> (56 - 8 * i));
		}

		n = 10;
	}

	buf_add(&c->out, hdr, n);
	buf_add(&c->out, data, len);
}

int ws_is_upgrade(const struct http_request *r)
{
	const char *up = http_header(r, "Upgrade");
	return up != NULL && strcasecmp(up, "websocket") == 0;
}

static void ws_accept_key(const char *key, char out[64])
{
	unsigned char digest[EVP_MAX_MD_SIZE];
	unsigned int dlen = 0;
	char joined[256];

	snprintf(joined, sizeof(joined), "%s%s", key, WS_GUID);
	EVP_Digest(joined, strlen(joined), digest, &dlen, EVP_sha1(), NULL);
	EVP_EncodeBlock((unsigned char *)out, digest, (int)dlen);
}

int ws_accept(struct http_conn *c, const struct http_request *r, enum ws_kind kind)
{
	const char *key = http_header(r, "Sec-WebSocket-Key");
	const char *version = http_header(r, "Sec-WebSocket-Version");
	char accept[64];

	if (strcmp(r->method, "GET") != 0 || !http_header_has(r, "Connection", "upgrade") || !http_header_has(r, "Upgrade", "websocket") ||
		version == NULL || strcmp(version, "13") != 0 || key == NULL || key[0] == '\0' || strlen(key) > 128) {
		return -1;
	}

	ws_accept_key(key, accept);
	buf_fmt(&c->out, "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: %s\r\n\r\n",
			accept);
	c->ws = 1;
	c->ws_kind = kind;
	c->prev_level = -1;
	c->idle_deadline = 0;
	c->header_deadline = 0;
	return 0;
}

static int ws_read(struct http_conn *c)
{
	size_t off = 0;
	const uint8_t *p = (const uint8_t *)c->in.data;

	while (c->in.len - off >= 2) {
		size_t avail = c->in.len - off;
		const uint8_t *h = p + off;
		int fin = (h[0] & 0x80) != 0;
		int op = h[0] & 0x0F;
		int masked = (h[1] & 0x80) != 0;
		uint64_t size = h[1] & 0x7F;
		size_t hlen = 2;

		if (size == 126) {
			if (avail < 4) {
				break;
			}

			size = (uint64_t)h[2] << 8 | h[3];
			hlen = 4;
		} else if (size == 127) {
			if (avail < 10) {
				break;
			}

			size = 0;
			for (int i = 0; i < 8; i++) {
				size = size << 8 | h[2 + i];
			}

			hlen = 10;
		}

		if (!masked || size > WS_MAX_MESSAGE || c->ws_msg.len + size > WS_MAX_MESSAGE) {
			return -1;
		}

		if (avail < hlen + 4 + size) {
			break;
		}

		const uint8_t *mask = h + hlen;
		uint8_t *data = (uint8_t *)h + hlen + 4;
		for (uint64_t i = 0; i < size; i++) {
			data[i] ^= mask[i & 3];
		}

		off += hlen + 4 + (size_t)size;
		switch (op) {
		case 9:
			ws_send(c, 10, data, (size_t)size);
			continue;
		case 10:
			continue;
		case 8:
			ws_send(c, 8, data, (size_t)size);
			c->close_after = 1;
			return 0;
		case 0:
			if (c->ws_op == 0) {
				return -1;
			}

			break;
		case WS_TEXT:
		case WS_BINARY:
			if (c->ws_op != 0) {
				return -1;
			}

			c->ws_op = op;
			break;
		default:
			return -1;
		}

		buf_add(&c->ws_msg, data, (size_t)size);
		if (fin) {
			if (c->ws_op == WS_BINARY) {
				api_ws_message(c, (const uint8_t *)c->ws_msg.data, c->ws_msg.len);
			}

			c->ws_msg.len = 0;
			c->ws_op = 0;
		}
	}

	memmove(c->in.data, c->in.data + off, c->in.len - off);
	c->in.len -= off;
	return 0;
}

static int parse_request(char *head, struct http_request *r)
{
	char *line_end = strstr(head, "\r\n");
	char *sp1 = NULL;
	char *sp2 = NULL;

	memset(r, 0, sizeof(*r));
	if (line_end == NULL) {
		return -1;
	}

	*line_end = '\0';
	sp1 = strchr(head, ' ');
	if (sp1 == NULL) {
		return -1;
	}

	*sp1 = '\0';
	sp2 = strchr(sp1 + 1, ' ');
	if (sp2 == NULL) {
		return -1;
	}

	*sp2 = '\0';
	if (strcmp(sp2 + 1, "HTTP/1.1") == 0) {
		r->minor = 1;
	} else if (strcmp(sp2 + 1, "HTTP/1.0") != 0) {
		return -1;
	}

	r->method = head;
	r->path = sp1 + 1;
	if (r->path[0] != '/') {
		return -1;
	}

	char *q = strchr(r->path, '?');
	if (q != NULL) {
		*q = '\0';
		r->query = q + 1;
	} else {
		r->query = "";
	}

	char *p = line_end + 2;
	while (*p != '\0') {
		char *end = strstr(p, "\r\n");
		if (end == NULL) {
			end = p + strlen(p);
		}

		*end = '\0';
		char *colon = strchr(p, ':');
		if (colon == NULL || colon == p || r->header_count == sizeof(r->header_names) / sizeof(r->header_names[0])) {
			return -1;
		}

		*colon = '\0';
		char *v = colon + 1;
		while (*v == ' ' || *v == '\t') {
			v++;
		}

		char *ve = v + strlen(v);
		while (ve > v && (ve[-1] == ' ' || ve[-1] == '\t')) {
			*--ve = '\0';
		}

		r->header_names[r->header_count] = p;
		r->header_values[r->header_count] = v;
		r->header_count++;
		p = end + 2;
		if (end[1] == '\0') {
			break;
		}
	}

	return 0;
}

static int chunked_decode(const char *p, size_t len, struct buf *out, size_t *consumed)
{
	size_t off = 0;

	out->len = 0;
	for (;;) {
		const char *eol = memmem(p + off, len - off, "\r\n", 2);
		if (eol == NULL) {
			return len - off > 32 ? -1 : 0;
		}

		size_t size = 0;
		const char *q = p + off;
		while (q < eol && unhex(*q) >= 0 && q - (p + off) < 8) {
			size = size << 4 | (size_t)unhex(*q);
			q++;
		}

		if (q == p + off || (q != eol && *q != ';')) {
			return -1;
		}

		off = (size_t)(eol - p) + 2;
		if (size == 0) {
			for (;;) {
				const char *line = memmem(p + off, len - off, "\r\n", 2);
				if (line == NULL) {
					return len - off > MAX_HEADER ? -1 : 0;
				}

				size_t n = (size_t)(line - (p + off));
				off += n + 2;
				if (n == 0) {
					*consumed = off;
					return 1;
				}
			}
		}

		if (size > MAX_BODY || out->len + size > MAX_BODY) {
			return -1;
		}

		if (len - off < size + 2) {
			return 0;
		}

		if (p[off + size] != '\r' || p[off + size + 1] != '\n') {
			return -1;
		}

		buf_add(out, p + off, size);
		off += size + 2;
	}
}

static void go_clean_path(const char *in, struct buf *out)
{
	size_t n = strlen(in);
	size_t i = 0;

	out->len = 0;
	buf_byte(out, '/');
	while (i < n) {
		if (in[i] == '/') {
			i++;
			continue;
		}

		size_t j = i;
		while (j < n && in[j] != '/') {
			j++;
		}

		if (j - i == 1 && in[i] == '.') {
			i = j;
			continue;
		}

		if (j - i == 2 && in[i] == '.' && in[i + 1] == '.') {
			while (out->len > 1 && out->data[out->len - 1] != '/') {
				out->len--;
			}

			if (out->len > 1) {
				out->len--;
			}

			out->data[out->len] = '\0';
			i = j;
			continue;
		}

		if (out->len > 1) {
			buf_byte(out, '/');
		}

		buf_add(out, in + i, j - i);
		i = j;
	}

	if (n > 1 && in[n - 1] == '/' && out->len > 1) {
		buf_byte(out, '/');
	}
}

static int redirect_unclean(const struct http_request *r, struct http_response *resp)
{
	struct buf clean = {0};
	int moved = 0;

	go_clean_path(r->path, &clean);
	if (strcmp(clean.data, r->path) != 0) {
		struct buf location = {0};
		buf_str(&location, clean.data);
		if (r->query[0] != '\0') {
			buf_fmt(&location, "?%s", r->query);
		}

		resp->status = 301;
		resp_header(resp, "Location", location.data);
		resp_header(resp, "Content-Type", "text/html; charset=utf-8");
		if (strcmp(r->method, "GET") == 0 || strcmp(r->method, "HEAD") == 0) {
			buf_fmt(&resp->body, "<a href=\"%s\">Moved Permanently</a>.\n\n", location.data);
		}

		buf_free(&location);
		moved = 1;
	}

	buf_free(&clean);
	return moved;
}

static void write_response(struct http_conn *c, const struct http_request *r, struct http_response *resp, int keep)
{
	int bodyless = resp->status == 204 || resp->status == 304 || (resp->status >= 100 && resp->status < 200);
	size_t len = resp->static_body != NULL ? resp->static_len : resp->body.len;

	buf_fmt(&c->out, "HTTP/1.1 %d %s\r\n", resp->status, status_text(resp->status));
	buf_add(&c->out, resp->headers.data, resp->headers.len);
	if (!bodyless) {
		buf_fmt(&c->out, "Content-Length: %zu\r\n", len);
	}

	if (!keep) {
		buf_str(&c->out, "Connection: close\r\n");
	}

	buf_str(&c->out, "\r\n");
	if (!bodyless && strcmp(r->method, "HEAD") != 0) {
		if (resp->static_body != NULL) {
			c->body = resp->static_body;
			c->body_len = resp->static_len;
			c->body_off = 0;
		} else {
			buf_add(&c->out, resp->body.data, resp->body.len);
		}
	}

	c->close_after = !keep;
}

static void simple_error(struct http_conn *c, int status, const char *text)
{
	buf_fmt(&c->out, "HTTP/1.1 %d %s\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\nContent-Length: %zu\r\n\r\n%s",
			status, status_text(status), strlen(text), text);
	c->close_after = 1;
}

static int decode_path(char *path)
{
	struct buf out = {0};
	if (unescape(path, strlen(path), 0, &out) != 0 || strlen(out.data) != out.len) {
		buf_free(&out);
		return -1;
	}

	memcpy(path, out.data, out.len + 1);
	buf_free(&out);
	return 0;
}

static void serve_requests(struct http_conn *c)
{
	static char head[MAX_HEADER + 4];

	while (!c->dead && !c->ws && !conn_pending(c) && !c->close_after && c->in.len > 0) {
		char *end = memmem(c->in.data, c->in.len, "\r\n\r\n", 4);
		struct http_request r;
		struct http_response resp = {0};
		size_t head_len = 0;
		size_t body_len = 0;

		if (end == NULL) {
			if (c->in.len > MAX_HEADER) {
				simple_error(c, 431, "431 Request Header Fields Too Large");
			} else if (c->header_deadline == 0) {
				c->header_deadline = now_ms() + HEADER_TIMEOUT_MS;
			}

			break;
		}

		head_len = (size_t)(end - c->in.data) + 4;
		if (head_len > MAX_HEADER + 4) {
			simple_error(c, 431, "431 Request Header Fields Too Large");
			break;
		}

		memcpy(head, c->in.data, head_len - 2);
		head[head_len - 2] = '\0';
		if (memchr(head, '\0', head_len - 2) != NULL || parse_request(head, &r) != 0 || decode_path(r.path) != 0) {
			simple_error(c, 400, "400 Bad Request");
			break;
		}

		const char *cl = http_header(&r, "Content-Length");
		const char *te = http_header(&r, "Transfer-Encoding");
		struct buf chunked = {0};
		size_t consumed = 0;
		if (te != NULL && (strcasecmp(te, "chunked") != 0 || cl != NULL)) {
			simple_error(c, 501, "501 Not Implemented");
			break;
		}

		if (te != NULL) {
			int got = chunked_decode(c->in.data + head_len, c->in.len - head_len, &chunked, &consumed);
			if (got < 0) {
				buf_free(&chunked);
				simple_error(c, 400, "400 Bad Request");
				break;
			}

			if (got == 0) {
				buf_free(&chunked);
				if (c->header_deadline == 0) {
					c->header_deadline = now_ms() + HEADER_TIMEOUT_MS;
				}

				break;
			}
		} else if (cl != NULL) {
			char *e = NULL;
			unsigned long long v = strtoull(cl, &e, 10);
			if (*cl == '\0' || *e != '\0' || cl[0] == '-') {
				simple_error(c, 400, "400 Bad Request");
				break;
			}

			if (v > MAX_BODY) {
				simple_error(c, 413, "413 Request Entity Too Large");
				break;
			}

			body_len = (size_t)v;
		}

		if (c->in.len < head_len + body_len) {
			if (c->header_deadline == 0) {
				c->header_deadline = now_ms() + HEADER_TIMEOUT_MS;
			}

			break;
		}

		r.body = te != NULL ? chunked.data : c->in.data + head_len;
		r.body_len = te != NULL ? chunked.len : body_len;
		if (te != NULL) {
			body_len = consumed;
		}

		c->header_deadline = 0;

		int keep = r.minor == 1 ? !http_header_has(&r, "Connection", "close") : http_header_has(&r, "Connection", "keep-alive");
		if (!redirect_unclean(&r, &resp)) {
			if (strncmp(r.path, "/api/", 5) == 0) {
				api_handle(c, &r, &resp);
			} else {
				static_handle(&r, &resp);
			}
		}

		buf_free(&chunked);

		if (!resp.upgraded) {
			write_response(c, &r, &resp, keep);
		}

		buf_free(&resp.headers);
		buf_free(&resp.body);
		memmove(c->in.data, c->in.data + head_len + body_len, c->in.len - head_len - body_len);
		c->in.len -= head_len + body_len;
		c->idle_deadline = now_ms() + IDLE_TIMEOUT_MS;
		c->write_since = now_ms();
		int done = conn_flush(c);
		if (done < 0) {
			conn_close(c);
			return;
		}

		if (resp.upgraded) {
			api_ws_opened(c);
			conn_send(c);
			return;
		}

		if (done == 0) {
			break;
		}

		c->write_since = 0;
		if (c->close_after) {
			conn_close(c);
			return;
		}
	}

	if (!c->dead && conn_pending(c) && c->close_after && c->write_since == 0) {
		conn_send(c);
		return;
	}

	if (!c->dead) {
		conn_watch(c);
	}
}

static void conn_readable(struct http_conn *c)
{
	char chunk[16384];

	for (;;) {
		ssize_t n = recv(c->fd, chunk, sizeof(chunk), 0);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
			break;
		}

		if (n <= 0) {
			conn_close(c);
			return;
		}

		buf_add(&c->in, chunk, (size_t)n);
		if (!c->ws && c->in.len > MAX_HEADER + MAX_BODY + 4) {
			break;
		}

		if (c->ws && c->in.len > WS_MAX_MESSAGE + 16) {
			break;
		}
	}

	if (c->ws) {
		if (ws_read(c) != 0) {
			conn_close(c);
			return;
		}

		conn_send(c);
		return;
	}

	serve_requests(c);
}

static void conn_writable(struct http_conn *c)
{
	int done = conn_flush(c);
	if (done < 0) {
		conn_close(c);
		return;
	}

	if (done == 0) {
		return;
	}

	c->write_since = 0;
	if (c->close_after) {
		conn_close(c);
		return;
	}

	if (c->ws) {
		conn_watch(c);
		return;
	}

	serve_requests(c);
}

static void accept_all(void)
{
	for (;;) {
		int fd = accept4(srv.listen_fd, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
		if (fd < 0) {
			return;
		}

		struct http_conn *c = xcalloc(1, sizeof(*c));
		struct epoll_event ev = {.events = EPOLLIN | EPOLLRDHUP, .data.ptr = c};
		c->fd = fd;
		c->idle_deadline = now_ms() + IDLE_TIMEOUT_MS;
		c->prev_level = -1;
		c->next = srv.conns;
		srv.conns = c;
		if (epoll_ctl(srv.epfd, EPOLL_CTL_ADD, fd, &ev) != 0) {
			conn_close(c);
		}
	}
}

static void deliver_hubs(void)
{
	struct buf msg = {0};

	for (struct http_conn *c = srv.conns; c != NULL; c = c->next) {
		if (c->dead || !c->ws || c->ws_kind == WS_METRICS) {
			continue;
		}

		int hub = c->ws_kind == WS_LOG ? HUB_LOG : HUB_AUDIT;
		int sent = 0;
		while (hub_take(hub, &c->hub_seq, &msg)) {
			if (c->paused || c->close_after || c->out.len - c->out_off > WS_DROP_PENDING) {
				continue;
			}

			ws_send(c, WS_BINARY, msg.data, msg.len);
			sent = 1;
		}

		if (sent) {
			conn_send(c);
		}
	}

	buf_free(&msg);
}

static void tick_conns(int64_t now)
{
	struct buf metrics = {0};

	for (struct http_conn *c = srv.conns; c != NULL; c = c->next) {
		if (c->dead) {
			continue;
		}

		if (c->write_since != 0 && now - c->write_since > WRITE_TIMEOUT_MS) {
			conn_close(c);
			continue;
		}

		if (c->ws) {
			if (c->ws_kind == WS_METRICS && !c->close_after && now >= c->next_metrics) {
				if (metrics.data == NULL) {
					api_metrics_json(&metrics);
				}

				ws_send(c, WS_TEXT, metrics.data, metrics.len);
				c->next_metrics = now + METRICS_PERIOD_MS;
				if (c->out.len - c->out_off > WS_MAX_PENDING) {
					conn_close(c);
					continue;
				}

				conn_send(c);
			}

			continue;
		}

		if ((c->header_deadline != 0 && now > c->header_deadline) ||
			(c->in.len == 0 && !conn_pending(c) && c->idle_deadline != 0 && now > c->idle_deadline)) {
			conn_close(c);
		}
	}

	buf_free(&metrics);
}

static int parse_loopback(const char *spec, struct sockaddr_storage *ss, socklen_t *len, char *err, size_t err_len)
{
	char host[128];
	const char *colon = strrchr(spec, ':');
	char *end = NULL;

	if (colon == NULL) {
		snprintf(err, err_len, "address %s: missing port in address", spec);
		return -1;
	}

	size_t hlen = (size_t)(colon - spec);
	if (hlen >= sizeof(host)) {
		snprintf(err, err_len, "address %s: too long", spec);
		return -1;
	}

	memcpy(host, spec, hlen);
	host[hlen] = '\0';
	if (host[0] == '[' && hlen >= 2 && host[hlen - 1] == ']') {
		memmove(host, host + 1, hlen - 2);
		host[hlen - 2] = '\0';
	} else if (strchr(host, ':') != NULL) {
		snprintf(err, err_len, "address %s: too many colons in address", spec);
		return -1;
	}

	long port = strtol(colon + 1, &end, 10);
	if (colon[1] == '\0' || *end != '\0' || port < 0 || port > 65535) {
		snprintf(err, err_len, "address %s: invalid port", spec);
		return -1;
	}

	memset(ss, 0, sizeof(*ss));
	struct sockaddr_in *in4 = (struct sockaddr_in *)ss;
	struct sockaddr_in6 *in6 = (struct sockaddr_in6 *)ss;
	if (inet_pton(AF_INET, host, &in4->sin_addr) == 1 && (ntohl(in4->sin_addr.s_addr) >> 24) == 127) {
		in4->sin_family = AF_INET;
		in4->sin_port = htons((uint16_t)port);
		*len = sizeof(*in4);
		return 0;
	}

	if (inet_pton(AF_INET6, host, &in6->sin6_addr) == 1 && IN6_IS_ADDR_LOOPBACK(&in6->sin6_addr)) {
		in6->sin6_family = AF_INET6;
		in6->sin6_port = htons((uint16_t)port);
		*len = sizeof(*in6);
		return 0;
	}

	snprintf(err, err_len, "only unix:path or a loopback address is allowed");
	return -1;
}

static int open_listener(const char *spec, char *err, size_t err_len)
{
	int fd = -1;

	if (strncmp(spec, "unix:", 5) == 0) {
		struct sockaddr_un sun = {.sun_family = AF_UNIX};
		const char *path = spec + 5;
		if (strlen(path) >= sizeof(sun.sun_path)) {
			snprintf(err, err_len, "listen unix %s: path too long", path);
			return -1;
		}

		strcpy(sun.sun_path, path);
		unlink(path);
		fd = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
		mode_t old = umask(077);
		int ret = fd < 0 ? -1 : bind(fd, (struct sockaddr *)&sun, sizeof(sun));
		umask(old);
		if (ret != 0 || listen(fd, 128) != 0) {
			snprintf(err, err_len, "listen unix %s: bind: %s", path, strerror(errno));
			if (fd >= 0) {
				close(fd);
			}

			return -1;
		}

		snprintf(srv.unix_path, sizeof(srv.unix_path), "%s", path);
		return fd;
	}

	struct sockaddr_storage ss;
	socklen_t slen = 0;
	char why[256];
	if (parse_loopback(spec, &ss, &slen, why, sizeof(why)) != 0) {
		snprintf(err, err_len, "invalid listen address \"%s\": %s", spec, why);
		return -1;
	}

	int one = 1;
	fd = socket(ss.ss_family, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
	if (fd < 0 || setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0 || bind(fd, (struct sockaddr *)&ss, slen) != 0 ||
		listen(fd, 128) != 0) {
		snprintf(err, err_len, "listen tcp %s: %s", spec, strerror(errno));
		if (fd >= 0) {
			close(fd);
		}

		return -1;
	}

	return fd;
}

static int next_timeout(int64_t now)
{
	int64_t next = now + 1000;

	for (struct http_conn *c = srv.conns; c != NULL; c = c->next) {
		if (c->ws && c->ws_kind == WS_METRICS && c->next_metrics < next) {
			next = c->next_metrics;
		}
	}

	return next <= now ? 0 : (int)(next - now);
}

int http_serve(const char *listen_spec, const char *data_dir, int wake_fd, int signal_fd)
{
	struct epoll_event events[64];
	char err[512];
	int result = 0;

	srv.listen_fd = open_listener(listen_spec, err, sizeof(err));
	if (srv.listen_fd < 0) {
		link_log(UI_LOG_WARN, "%s", err);
		return -1;
	}

	srv.epfd = epoll_create1(EPOLL_CLOEXEC);
	struct epoll_event ev = {.events = EPOLLIN, .data.ptr = &srv.listen_fd};
	epoll_ctl(srv.epfd, EPOLL_CTL_ADD, srv.listen_fd, &ev);
	ev.data.ptr = &wake_fd;
	epoll_ctl(srv.epfd, EPOLL_CTL_ADD, wake_fd, &ev);
	ev.data.ptr = &signal_fd;
	epoll_ctl(srv.epfd, EPOLL_CTL_ADD, signal_fd, &ev);
	link_log(UI_LOG_NOTICE, "hrdns-ui %s listening on %s, journal %s", SMARTDNS_VERION, listen_spec, data_dir);

	for (;;) {
		int n = epoll_wait(srv.epfd, events, 64, next_timeout(now_ms()));
		if (n < 0 && errno != EINTR) {
			result = -1;
			break;
		}

		int stop = 0;
		for (int i = 0; i < n; i++) {
			void *tag = events[i].data.ptr;
			if (tag == &srv.listen_fd) {
				accept_all();
			} else if (tag == &wake_fd) {
				uint64_t count = 0;
				if (read(wake_fd, &count, sizeof(count)) < 0) {
					count = 0;
				}

				if (link_closed()) {
					result = -1;
					stop = 1;
				}

				deliver_hubs();
			} else if (tag == &signal_fd) {
				struct signalfd_siginfo si;
				if (read(signal_fd, &si, sizeof(si)) < 0) {
					si.ssi_signo = 0;
				}

				stop = 1;
			} else {
				struct http_conn *c = tag;
				if (c->dead) {
					continue;
				}

				if (events[i].events & EPOLLOUT) {
					conn_writable(c);
					continue;
				}

				if (events[i].events & (EPOLLIN | EPOLLRDHUP | EPOLLHUP | EPOLLERR)) {
					conn_readable(c);
				}
			}

			if (stop) {
				break;
			}
		}

		if (stop) {
			break;
		}

		tick_conns(now_ms());
		sweep_dead();
	}

	srv.stopping = 1;
	for (struct http_conn *c = srv.conns; c != NULL; c = c->next) {
		conn_close(c);
	}

	sweep_dead();

	close(srv.listen_fd);
	if (srv.unix_path[0] != '\0') {
		unlink(srv.unix_path);
	}

	close(srv.epfd);
	return result;
}
