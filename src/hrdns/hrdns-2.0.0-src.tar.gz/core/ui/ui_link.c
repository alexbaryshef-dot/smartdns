#define _GNU_SOURCE

#include "ui.h"

#include <errno.h>
#include <poll.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/eventfd.h>
#include <time.h>
#include <unistd.h>

#define KIND_CMD 0x02
#define KIND_UILOG 0x03
#define KIND_HELLO 0x81
#define KIND_REPLY 0x82
#define KIND_QUERY 0x90
#define KIND_LOG 0x91
#define KIND_AUDIT 0x92
#define KIND_LOST 0x93

#define HEADER_SIZE 5
#define MAX_FRAME (8 << 20)
#define MAX_LOG_TEXT 255
#define QUERY_FIXED 47
#define SUBSCRIBE_TIMEOUT_MS 3000
#define HUB_RING 256

enum call_state { CALL_IDLE, CALL_WAITING, CALL_DONE };

struct hub {
	pthread_mutex_t mu;
	int subscribers;
	uint64_t head;
	struct buf ring[HUB_RING];
};

static struct {
	int fd;
	int wake_fd;
	int stop_fd;
	pthread_t thread;
	int started;
	struct link_hello hello;
	uint8_t *in;
	size_t in_len;
	size_t in_cap;
	pthread_mutex_t write_mu;
	pthread_mutex_t call_mu;
	pthread_cond_t call_cond;
	uint64_t next_id;
	uint64_t wait_id;
	enum call_state state;
	int reply_ok;
	struct buf reply;
	int closed;
	pthread_mutex_t sub_mu;
	int log_subs;
	int audit_subs;
} link_state = {
	.fd = -1,
	.wake_fd = -1,
	.stop_fd = -1,
	.write_mu = PTHREAD_MUTEX_INITIALIZER,
	.call_mu = PTHREAD_MUTEX_INITIALIZER,
	.sub_mu = PTHREAD_MUTEX_INITIALIZER,
};

static struct hub hubs[2] = {{.mu = PTHREAD_MUTEX_INITIALIZER}, {.mu = PTHREAD_MUTEX_INITIALIZER}};

static uint32_t get_u32(const uint8_t *p)
{
	return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static uint16_t get_u16(const uint8_t *p)
{
	return (uint16_t)(p[0] | p[1] << 8);
}

static uint64_t get_u64(const uint8_t *p)
{
	return (uint64_t)get_u32(p) | (uint64_t)get_u32(p + 4) << 32;
}

static int write_all(int fd, const uint8_t *p, size_t len)
{
	while (len > 0) {
		ssize_t n = write(fd, p, len);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			return -1;
		}

		p += n;
		len -= (size_t)n;
	}

	return 0;
}

static int send_frame(uint8_t kind, const void *payload, size_t len)
{
	uint8_t hdr[HEADER_SIZE] = {(uint8_t)len, (uint8_t)(len >> 8), (uint8_t)(len >> 16), (uint8_t)(len >> 24), kind};
	int ret = 0;

	pthread_mutex_lock(&link_state.write_mu);
	if (write_all(link_state.fd, hdr, sizeof(hdr)) != 0 || write_all(link_state.fd, payload, len) != 0) {
		ret = -1;
	}

	pthread_mutex_unlock(&link_state.write_mu);
	return ret;
}

static int read_full(int fd, uint8_t *p, size_t len)
{
	while (len > 0) {
		ssize_t n = read(fd, p, len);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			return -1;
		}

		p += n;
		len -= (size_t)n;
	}

	return 0;
}

static char *json_string_field(const struct jval *obj, const char *key)
{
	const struct jval *v = json_get(obj, key);
	if (v == NULL || v->type != J_STR) {
		return xstrndup("", 0);
	}

	return xstrndup(v->str, v->len);
}

int link_open(int fd)
{
	uint8_t hdr[HEADER_SIZE];
	struct jval hello;

	link_state.fd = fd;
	if (read_full(fd, hdr, sizeof(hdr)) != 0) {
		return -1;
	}

	uint32_t len = get_u32(hdr);
	if (len > MAX_FRAME || hdr[4] != KIND_HELLO) {
		return -1;
	}

	uint8_t *payload = xmalloc(len);
	if (read_full(fd, payload, len) != 0 || json_parse((const char *)payload, len, &hello) != 0) {
		free(payload);
		return -1;
	}

	link_state.hello.build = json_string_field(&hello, "build");
	link_state.hello.server_name = json_string_field(&hello, "server_name");
	json_as_i64(json_get(&hello, "started_ms"), &link_state.hello.started_ms);
	json_free(&hello);
	free(payload);
	return 0;
}

const struct link_hello *link_hello(void)
{
	return &link_state.hello;
}

int link_closed(void)
{
	pthread_mutex_lock(&link_state.call_mu);
	int closed = link_state.closed;
	pthread_mutex_unlock(&link_state.call_mu);
	return closed;
}

static void deliver(const uint8_t *payload, size_t len)
{
	struct jval reply;
	uint64_t id = 0;

	if (json_parse((const char *)payload, len, &reply) != 0 || json_as_u64(json_get(&reply, "id"), &id) != 0) {
		json_free(&reply);
		return;
	}

	const struct jval *ok = json_get(&reply, "ok");
	const struct jval *data = json_get(&reply, "data");
	const struct jval *err = json_get(&reply, "error");

	pthread_mutex_lock(&link_state.call_mu);
	if (link_state.state == CALL_WAITING && link_state.wait_id == id) {
		link_state.reply.len = 0;
		link_state.reply_ok = ok != NULL && ok->type == J_BOOL && ok->boolean;
		if (link_state.reply_ok && data != NULL) {
			buf_add(&link_state.reply, data->raw, data->raw_len);
		} else if (!link_state.reply_ok && err != NULL && err->type == J_STR) {
			buf_add(&link_state.reply, err->str, err->len);
		} else {
			buf_add(&link_state.reply, "", 0);
		}

		link_state.state = CALL_DONE;
		pthread_cond_broadcast(&link_state.call_cond);
	}

	pthread_mutex_unlock(&link_state.call_mu);
	json_free(&reply);
}

static int on_query(const uint8_t *p, size_t len)
{
	struct ui_query q;

	if (len < QUERY_FIXED) {
		return -1;
	}

	q.time_ms = get_u64(p);
	q.query_ms = get_u32(p + 8);
	q.ping_tenths = (int32_t)get_u32(p + 12);
	q.qtype = get_u16(p + 16);
	q.rcode = p[18];
	q.flags = p[19];
	q.family = p[20];
	memcpy(q.addr, p + 21, ADDR_LEN);
	memcpy(q.mac, p + 37, MAC_LEN);
	q.block_list = p[43];
	q.group_len = p[44];
	q.domain_len = get_u16(p + 45);
	if (len < QUERY_FIXED + q.group_len + q.domain_len) {
		return -1;
	}

	q.group = p + QUERY_FIXED;
	q.domain = p + QUERY_FIXED + q.group_len;
	store_add(&q);
	return 0;
}

static int on_frame(uint8_t kind, const uint8_t *payload, size_t len)
{
	static const uint8_t log_prefix_zero = 0;
	uint8_t log_prefix[2];

	switch (kind) {
	case KIND_QUERY:
		return on_query(payload, len);
	case KIND_LOG:
		if (len > 0 && hub_active(HUB_LOG)) {
			log_prefix[0] = 0;
			log_prefix[1] = payload[0];
			hub_publish(HUB_LOG, log_prefix, 2, payload + 1, len - 1);
		}

		break;
	case KIND_AUDIT:
		if (hub_active(HUB_AUDIT)) {
			hub_publish(HUB_AUDIT, &log_prefix_zero, 1, payload, len);
		}

		break;
	case KIND_LOST:
		if (len >= 4) {
			link_log(UI_LOG_WARN, "resolver dropped %u events", get_u32(payload));
		}

		break;
	case KIND_REPLY:
		deliver(payload, len);
		break;
	default:
		break;
	}

	return 0;
}

static int drain_frames(void)
{
	size_t off = 0;

	while (link_state.in_len - off >= HEADER_SIZE) {
		uint32_t len = get_u32(link_state.in + off);
		if (len > MAX_FRAME) {
			return -1;
		}

		if (link_state.in_len - off < HEADER_SIZE + (size_t)len) {
			break;
		}

		if (on_frame(link_state.in[off + 4], link_state.in + off + HEADER_SIZE, len) != 0) {
			return -1;
		}

		off += HEADER_SIZE + len;
	}

	memmove(link_state.in, link_state.in + off, link_state.in_len - off);
	link_state.in_len -= off;
	if (link_state.in_len >= HEADER_SIZE) {
		size_t need = HEADER_SIZE + get_u32(link_state.in);
		if (need > link_state.in_cap) {
			link_state.in = xrealloc(link_state.in, need);
			link_state.in_cap = need;
		}
	}

	return 0;
}

static void *link_thread(void *arg)
{
	struct pollfd pfd[2] = {{.fd = link_state.fd, .events = POLLIN}, {.fd = link_state.stop_fd, .events = POLLIN}};
	uint64_t one = 1;

	for (;;) {
		int64_t now = now_ms();
		int64_t wait = store_next_tick(now) - now;
		if (wait < 0) {
			wait = 0;
		}

		int n = poll(pfd, 2, (int)(wait > 1000 ? 1000 : wait));
		if (n < 0 && errno != EINTR) {
			break;
		}

		if (n > 0 && (pfd[1].revents & POLLIN)) {
			return NULL;
		}

		if (n > 0 && (pfd[0].revents & (POLLIN | POLLHUP | POLLERR))) {
			ssize_t got = read(link_state.fd, link_state.in + link_state.in_len, link_state.in_cap - link_state.in_len);
			if (got < 0 && errno == EINTR) {
				continue;
			}

			if (got <= 0) {
				break;
			}

			link_state.in_len += (size_t)got;
			if (drain_frames() != 0) {
				break;
			}
		}

		store_tick(now_ms());
	}

	pthread_mutex_lock(&link_state.call_mu);
	link_state.closed = 1;
	pthread_cond_broadcast(&link_state.call_cond);
	pthread_mutex_unlock(&link_state.call_mu);
	if (write(link_state.wake_fd, &one, sizeof(one)) < 0) {
		return NULL;
	}

	return NULL;
}

int link_start(int wake_fd)
{
	pthread_condattr_t attr;

	pthread_condattr_init(&attr);
	pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
	pthread_cond_init(&link_state.call_cond, &attr);
	pthread_condattr_destroy(&attr);
	link_state.wake_fd = wake_fd;
	link_state.stop_fd = eventfd(0, EFD_CLOEXEC);
	link_state.in_cap = 64 << 10;
	link_state.in = xmalloc(link_state.in_cap);
	if (link_state.stop_fd < 0 || pthread_create(&link_state.thread, NULL, link_thread, NULL) != 0) {
		return -1;
	}

	link_state.started = 1;
	return 0;
}

void link_stop(void)
{
	uint64_t one = 1;

	if (!link_state.started) {
		return;
	}

	if (write(link_state.stop_fd, &one, sizeof(one)) < 0) {
		abort();
	}

	pthread_join(link_state.thread, NULL);
	link_state.started = 0;
}

int link_call(const char *command, int timeout_ms, struct buf *data, struct buf *err)
{
	struct timespec deadline;
	struct buf frame = {0};
	int ret = -1;

	pthread_mutex_lock(&link_state.call_mu);
	if (link_state.closed) {
		pthread_mutex_unlock(&link_state.call_mu);
		buf_str(err, "bridge: connection closed");
		return -1;
	}

	uint64_t id = ++link_state.next_id;
	link_state.wait_id = id;
	link_state.state = CALL_WAITING;
	pthread_mutex_unlock(&link_state.call_mu);

	buf_fmt(&frame, "%llu %s", (unsigned long long)id, command);
	if (send_frame(KIND_CMD, frame.data, frame.len) != 0) {
		buf_free(&frame);
		pthread_mutex_lock(&link_state.call_mu);
		link_state.state = CALL_IDLE;
		pthread_mutex_unlock(&link_state.call_mu);
		buf_fmt(err, "write: %s", strerror(errno));
		return -1;
	}

	buf_free(&frame);
	clock_gettime(CLOCK_MONOTONIC, &deadline);
	deadline.tv_sec += timeout_ms / 1000;
	deadline.tv_nsec += (long)(timeout_ms % 1000) * 1000000L;
	if (deadline.tv_nsec >= 1000000000L) {
		deadline.tv_sec++;
		deadline.tv_nsec -= 1000000000L;
	}

	pthread_mutex_lock(&link_state.call_mu);
	while (link_state.state == CALL_WAITING && !link_state.closed) {
		if (pthread_cond_timedwait(&link_state.call_cond, &link_state.call_mu, &deadline) == ETIMEDOUT) {
			break;
		}
	}

	if (link_state.state == CALL_DONE) {
		if (link_state.reply_ok) {
			buf_add(data, link_state.reply.data, link_state.reply.len);
			ret = 0;
		} else {
			buf_fmt(err, "bridge: command failed: %s", link_state.reply.data);
		}
	} else if (link_state.closed) {
		buf_str(err, "bridge: connection closed");
	} else {
		buf_str(err, "context deadline exceeded");
	}

	link_state.state = CALL_IDLE;
	pthread_mutex_unlock(&link_state.call_mu);
	return ret;
}

void link_log(int level, const char *fmt, ...)
{
	char text[MAX_LOG_TEXT + 2];
	va_list ap;

	text[0] = (char)level;
	va_start(ap, fmt);
	int n = vsnprintf(text + 1, sizeof(text) - 1, fmt, ap);
	va_end(ap);
	if (n < 0) {
		return;
	}

	if (n > MAX_LOG_TEXT) {
		n = MAX_LOG_TEXT;
	}

	send_frame(KIND_UILOG, text, (size_t)n + 1);
}

int link_subscribe(void)
{
	char command[32] = "subscribe q";
	struct buf data = {0};
	struct buf err = {0};

	pthread_mutex_lock(&link_state.sub_mu);
	if (link_state.log_subs > 0) {
		strcat(command, "l");
	}

	if (link_state.audit_subs > 0) {
		strcat(command, "a");
	}

	pthread_mutex_unlock(&link_state.sub_mu);
	int ret = link_call(command, SUBSCRIBE_TIMEOUT_MS, &data, &err);
	buf_free(&data);
	buf_free(&err);
	return ret;
}

void link_acquire(int logs, int audit)
{
	pthread_mutex_lock(&link_state.sub_mu);
	link_state.log_subs += logs;
	link_state.audit_subs += audit;
	pthread_mutex_unlock(&link_state.sub_mu);
	link_subscribe();
}

void link_release(int logs, int audit)
{
	pthread_mutex_lock(&link_state.sub_mu);
	link_state.log_subs -= logs;
	link_state.audit_subs -= audit;
	pthread_mutex_unlock(&link_state.sub_mu);
	link_subscribe();
}

int hub_active(int hub)
{
	pthread_mutex_lock(&hubs[hub].mu);
	int active = hubs[hub].subscribers > 0;
	pthread_mutex_unlock(&hubs[hub].mu);
	return active;
}

void hub_publish(int hub, const uint8_t *prefix, size_t prefix_len, const uint8_t *text, size_t len)
{
	struct hub *h = &hubs[hub];
	uint64_t one = 1;

	pthread_mutex_lock(&h->mu);
	struct buf *slot = &h->ring[h->head % HUB_RING];
	slot->len = 0;
	buf_add(slot, prefix, prefix_len);
	buf_add(slot, text, len);
	h->head++;
	pthread_mutex_unlock(&h->mu);
	if (write(link_state.wake_fd, &one, sizeof(one)) < 0) {
		return;
	}
}

uint64_t hub_subscribe(int hub)
{
	pthread_mutex_lock(&hubs[hub].mu);
	hubs[hub].subscribers++;
	uint64_t head = hubs[hub].head;
	pthread_mutex_unlock(&hubs[hub].mu);
	return head;
}

void hub_unsubscribe(int hub)
{
	pthread_mutex_lock(&hubs[hub].mu);
	hubs[hub].subscribers--;
	pthread_mutex_unlock(&hubs[hub].mu);
}

int hub_take(int hub, uint64_t *seq, struct buf *msg)
{
	struct hub *h = &hubs[hub];
	int got = 0;

	pthread_mutex_lock(&h->mu);
	if (h->head - *seq > HUB_RING) {
		*seq = h->head - HUB_RING;
	}

	if (*seq < h->head) {
		struct buf *slot = &h->ring[*seq % HUB_RING];
		msg->len = 0;
		buf_add(msg, slot->data, slot->len);
		(*seq)++;
		got = 1;
	}

	pthread_mutex_unlock(&h->mu);
	return got;
}
