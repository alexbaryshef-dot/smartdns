#define _GNU_SOURCE

#include "ui.h"

#include <stdlib.h>
#include <string.h>

#include "www_table.h"

#define WWW_COUNT (sizeof(www_files) / sizeof(www_files[0]))

static int cmp_file(const void *key, const void *elem)
{
	return strcmp(key, ((const struct www_file *)elem)->name);
}

const struct www_file *www_find(const char *name)
{
	return bsearch(name, www_files, WWW_COUNT, sizeof(www_files[0]), cmp_file);
}

static void clean_path(const char *in, struct buf *out)
{
	size_t n = strlen(in);
	size_t i = 0;

	out->len = 0;
	buf_byte(out, '/');
	while (i < n) {
		if (in[i] == '/') {
			i++;
			continue;
		}

		size_t j = i;
		while (j < n && in[j] != '/') {
			j++;
		}

		if (j - i == 1 && in[i] == '.') {
			i = j;
			continue;
		}

		if (j - i == 2 && in[i] == '.' && in[i + 1] == '.') {
			while (out->len > 1 && out->data[out->len - 1] != '/') {
				out->len--;
			}

			if (out->len > 1) {
				out->len--;
			}

			out->data[out->len] = '\0';
			i = j;
			continue;
		}

		if (out->len > 1) {
			buf_byte(out, '/');
		}

		buf_add(out, in + i, j - i);
		i = j;
	}
}

static const struct www_file *lookup(const char *url_path, int *status)
{
	struct buf clean = {0};
	struct buf cand = {0};
	const struct www_file *f = NULL;
	const char *p = NULL;

	clean_path(url_path, &clean);
	p = clean.data + 1;
	*status = 200;
	if (*p == '\0') {
		f = www_find("index.html");
	} else {
		f = www_find(p);
		if (f == NULL) {
			buf_fmt(&cand, "%s.html", p);
			f = www_find(cand.data);
		}

		if (f == NULL) {
			cand.len = 0;
			buf_fmt(&cand, "%s/index.html", p);
			f = www_find(cand.data);
		}
	}

	if (f == NULL) {
		*status = 404;
		f = www_find("404.html");
	}

	buf_free(&clean);
	buf_free(&cand);
	return f;
}

static void plain(struct http_response *resp, int status, const char *text)
{
	resp->status = status;
	resp_header(resp, "Content-Type", "text/plain; charset=utf-8");
	resp_header(resp, "X-Content-Type-Options", "nosniff");
	buf_str(&resp->body, text);
}

void static_handle(const struct http_request *r, struct http_response *resp)
{
	int status = 200;

	if (strcmp(r->method, "GET") != 0 && strcmp(r->method, "HEAD") != 0) {
		resp_header(resp, "Allow", "GET, HEAD");
		plain(resp, 405, "method not allowed\n");
		return;
	}

	const struct www_file *f = lookup(r->path, &status);
	if (f == NULL) {
		plain(resp, 404, "404 page not found\n");
		return;
	}

	const char *match = http_header(r, "If-None-Match");
	int not_modified = status == 200 && match != NULL && strcmp(match, f->tag) == 0;
	resp->status = not_modified ? 304 : status;
	if (!not_modified) {
		resp_header(resp, "Content-Type", f->mime);
	}

	resp_header(resp, "Vary", "Accept-Encoding");
	resp_header(resp, "X-Content-Type-Options", "nosniff");
	if (f->csp[0] != '\0') {
		resp_header(resp, "Content-Security-Policy", f->csp);
	}

	resp_header(resp, "Cache-Control", strncmp(r->path, "/_next/static/", 14) == 0 ? "public, max-age=31536000, immutable" : "no-cache");
	if (status == 200) {
		resp_header(resp, "ETag", f->tag);
	}

	if (not_modified) {
		return;
	}

	const char *accept = http_header(r, "Accept-Encoding");
	if (f->gz && (accept == NULL || strstr(accept, "gzip") == NULL)) {
		if (f->plain == NULL) {
			buf_free(&resp->headers);
			plain(resp, 406, "gzip encoding required\n");
			return;
		}

		resp->static_body = f->plain;
		resp->static_len = (size_t)(f->plain_end - f->plain);
		return;
	}

	if (f->gz) {
		resp_header(resp, "Content-Encoding", "gzip");
	}

	resp->static_body = f->data;
	resp->static_len = (size_t)(f->end - f->data);
}
