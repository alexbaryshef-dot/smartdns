#define _GNU_SOURCE

#include "smartdns/ui_spawn.h"
#include "smartdns/tlog.h"
#include "smartdns/ui_bridge.h"
#include "smartdns/util.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <spawn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

#define UI_SPAWN_SELF "/proc/self/exe"
#define UI_SPAWN_STOP_WAIT_MS 5000
#define UI_SPAWN_STOP_POLL_US 50000
#define UI_SPAWN_FD_LIMIT 65536
#define UI_SPAWN_ARGV_MAX 16
#define UI_SPAWN_NUM_LEN 16

extern char **environ;

static int ui_collect_fds(int **fds)
{
	DIR *dir = opendir("/proc/self/fd");
	struct dirent *ent = NULL;
	int count = 0;
	int cap = 64;
	int self = -1;

	if (dir == NULL) {
		return -1;
	}

	*fds = malloc(cap * sizeof(int));
	if (*fds == NULL) {
		closedir(dir);
		return -1;
	}

	self = dirfd(dir);
	while ((ent = readdir(dir)) != NULL) {
		char *end = NULL;
		long fd = strtol(ent->d_name, &end, 10);

		if (end == ent->d_name || *end != '\0' || fd <= UI_SPAWN_FD || fd == self) {
			continue;
		}

		if (count == cap) {
			int *grown = realloc(*fds, cap * 2 * sizeof(int));
			if (grown == NULL) {
				closedir(dir);
				free(*fds);
				*fds = NULL;
				return -1;
			}

			*fds = grown;
			cap *= 2;
		}

		(*fds)[count++] = (int)fd;
	}

	closedir(dir);
	return count;
}

static int ui_add_close_actions(posix_spawn_file_actions_t *actions)
{
	int *fds = NULL;
	int count = ui_collect_fds(&fds);
	int i = 0;
	int ret = 0;

	if (count >= 0) {
		for (i = 0; i < count && ret == 0; i++) {
			ret = posix_spawn_file_actions_addclose(actions, fds[i]);
		}

		free(fds);
		return ret;
	}

	count = getdtablesize();
	if (count > UI_SPAWN_FD_LIMIT) {
		count = UI_SPAWN_FD_LIMIT;
	}

	for (i = UI_SPAWN_FD + 1; i < count && ret == 0; i++) {
		ret = posix_spawn_file_actions_addclose(actions, i);
	}

	return ret;
}

static int ui_build_actions(posix_spawn_file_actions_t *actions, int child_end)
{
	if (posix_spawn_file_actions_adddup2(actions, child_end, UI_SPAWN_FD) != 0 ||
		ui_add_close_actions(actions) != 0 ||
		posix_spawn_file_actions_addopen(actions, STDIN_FILENO, "/dev/null", O_RDONLY, 0) != 0 ||
		posix_spawn_file_actions_addopen(actions, STDOUT_FILENO, "/dev/null", O_WRONLY, 0) != 0 ||
		posix_spawn_file_actions_addopen(actions, STDERR_FILENO, "/dev/null", O_WRONLY, 0) != 0) {
		return -1;
	}

	return 0;
}

static int ui_build_argv(char **argv, char (*numbers)[UI_SPAWN_NUM_LEN])
{
	int argc = 0;

	snprintf(numbers[0], UI_SPAWN_NUM_LEN, "%d", ui_conf.days);
	snprintf(numbers[1], UI_SPAWN_NUM_LEN, "%d", ui_conf.max_mb);
	snprintf(numbers[2], UI_SPAWN_NUM_LEN, "%d", ui_conf.flush_seconds);
	argv[argc++] = (char *)UI_SPAWN_NAME;
	argv[argc++] = "-data";
	argv[argc++] = ui_conf.data_dir;
	argv[argc++] = "-days";
	argv[argc++] = numbers[0];
	argv[argc++] = "-max-mb";
	argv[argc++] = numbers[1];
	argv[argc++] = "-flush";
	argv[argc++] = numbers[2];
	if (ui_conf.listen[0] != '\0') {
		argv[argc++] = "-listen";
		argv[argc++] = ui_conf.listen;
	}

	argv[argc] = NULL;
	return argc;
}

static int ui_exec(int child_end, pid_t *pid)
{
	static char *clean_env[] = {"PATH=/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin", NULL};
	const char *exe = ui_conf.exec[0] != '\0' ? ui_conf.exec : UI_SPAWN_SELF;
	char *argv[UI_SPAWN_ARGV_MAX];
	char numbers[3][UI_SPAWN_NUM_LEN];
	posix_spawn_file_actions_t actions;
	posix_spawnattr_t attr;
	sigset_t all;
	sigset_t none;
	int ret = -1;

	ui_build_argv(argv, numbers);
	sigfillset(&all);
	sigemptyset(&none);
	if (posix_spawnattr_init(&attr) != 0) {
		return ENOMEM;
	}

	if (posix_spawn_file_actions_init(&actions) != 0) {
		posix_spawnattr_destroy(&attr);
		return ENOMEM;
	}

	if (posix_spawnattr_setsigdefault(&attr, &all) == 0 && posix_spawnattr_setsigmask(&attr, &none) == 0 &&
		posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETSIGDEF | POSIX_SPAWN_SETSIGMASK) == 0 &&
		ui_build_actions(&actions, child_end) == 0) {
		ret = posix_spawn(pid, exe, &actions, &attr, argv, ui_conf.exec[0] != '\0' ? environ : clean_env);
	} else {
		ret = ENOMEM;
	}

	posix_spawn_file_actions_destroy(&actions);
	posix_spawnattr_destroy(&attr);
	return ret;
}

int ui_spawn_start(int *sock, pid_t *pid)
{
	int pair[2];
	int ret = 0;

	if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, pair) != 0) {
		return -1;
	}

	if (pair[1] == UI_SPAWN_FD) {
		int moved = fcntl(pair[1], F_DUPFD_CLOEXEC, UI_SPAWN_FD + 1);
		if (moved < 0) {
			close(pair[0]);
			close(pair[1]);
			return -1;
		}

		close(pair[1]);
		pair[1] = moved;
	}

	if (fcntl(pair[0], F_SETFL, O_NONBLOCK) != 0) {
		close(pair[0]);
		close(pair[1]);
		return -1;
	}

	ret = ui_exec(pair[1], pid);
	close(pair[1]);
	if (ret != 0) {
		close(pair[0]);
		errno = ret;
		return -1;
	}

	*sock = pair[0];
	return 0;
}

int ui_spawn_exited(pid_t pid)
{
	int status = 0;
	pid_t ret = waitpid(pid, &status, WNOHANG);

	if (ret == 0 || (ret < 0 && errno == EINTR)) {
		return 0;
	}

	if (ret < 0) {
		tlog(TLOG_WARN, "ui process %d is gone: %s", (int)pid, strerror(errno));
	} else if (WIFSIGNALED(status)) {
		tlog(TLOG_WARN, "ui process %d killed by signal %d", (int)pid, WTERMSIG(status));
	} else {
		tlog(TLOG_NOTICE, "ui process %d exited with status %d", (int)pid, WEXITSTATUS(status));
	}

	return 1;
}

void ui_spawn_stop(pid_t pid)
{
	int waited_us = 0;

	if (pid <= 0) {
		return;
	}

	kill(pid, SIGTERM);
	while (waited_us < UI_SPAWN_STOP_WAIT_MS * 1000) {
		if (ui_spawn_exited(pid)) {
			return;
		}

		usleep(UI_SPAWN_STOP_POLL_US);
		waited_us += UI_SPAWN_STOP_POLL_US;
	}

	kill(pid, SIGKILL);
	waitpid(pid, NULL, 0);
}
