#ifndef SMART_DNS_UI_SPAWN_H
#define SMART_DNS_UI_SPAWN_H

#include <stddef.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

#define UI_SPAWN_FD 3
#define UI_SPAWN_NAME "hrdns-ui"

int ui_spawn_start(int *sock, pid_t *pid);

int ui_spawn_exited(pid_t pid);

void ui_spawn_stop(pid_t pid);

int hrdns_ui_main(int argc, char *argv[]);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
