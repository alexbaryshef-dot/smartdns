#ifndef _SMARTDNS_HOSTS_SOURCE_H_
#define _SMARTDNS_HOSTS_SOURCE_H_

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

int hosts_conf_socket(void *data, int argc, char *argv[]);

int hosts_conf_record(void *data, int argc, char *argv[]);

void hosts_load(void);

void hosts_log(void);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
