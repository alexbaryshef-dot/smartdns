/*************************************************************************
 *
 * Copyright (C) 2018-2025 Ruilin Peng (Nick) <pymumu@gmail.com>.
 *
 * smartdns is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * smartdns is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "smartdns/smartdns.h"
#include "smartdns/ui_spawn.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	const char *name = strrchr(argv[0], '/');

	if (strcmp(name != NULL ? name + 1 : argv[0], UI_SPAWN_NAME) == 0) {
		return hrdns_ui_main(argc, argv);
	}

	return smartdns_main(argc, argv);
}
