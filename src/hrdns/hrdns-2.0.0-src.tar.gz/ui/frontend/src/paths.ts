export const paths = {
  home: '/',
  dashboard: {
    dashboard: '/dashboard',
    queryLog: '/dashboard/query-log',
    upstreamServers: '/dashboard/upstream-servers',
    clients: '/dashboard/clients',
    log: '/dashboard/log',
  },
  errors: { notFound: '/errors/not-found' },
} as const;
