"use client";

import * as React from 'react';
import RouterLink from 'next/link';
import { smartdnsServer } from '@/lib/backend/server';
import type { TopClients } from '@/lib/backend/server';
import { CardLoading } from './card-loading';
import { TopTable } from './top-table';
import { clientLabel, clientLogUrl } from '@/lib/client-label';
import { useNames } from '@/lib/names';
import { Link } from '@mui/material';
import { useTranslation } from 'react-i18next';

function TopClientsTable({ clients }: { clients: TopClients[] }): React.JSX.Element {
  const { t } = useTranslation();
  const names = useNames();

  const rows = clients.map((client) => {
    const id = client.client_mac ?? client.client_ip;
    const url = clientLogUrl(client);
    const name = clientLabel(client.client_ip, names?.client(client.client_ip, client.client_mac));
    return {
      key: id,
      name,
      label: <Link component={RouterLink} href={url}>{name}</Link>,
      sort: client.query_count,
      value: client.query_count,
    };
  });

  return <TopTable head={[t('Client'), t('Count')]} rows={rows} />;
}

export function TopClientsCard(): React.JSX.Element {
  const [clients, setClients] = React.useState<TopClients[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  const { t } = useTranslation();

  React.useEffect(() => {
    const fetchData = async (): Promise<void> => {
      const data = await smartdnsServer.GetTopClients();
      if (data.error) {
        setErrorMsg(smartdnsServer.getErrorMessage(data.error));
        return;
      }

      if (data.data === null || data.data === undefined) {
        return;
      }

      setClients(data.data);
      setLoading(false);
    };

    void fetchData();
  }, []);

  return (
    <CardLoading title={t("Top Clients")} isLoading={loading} errorMsg={errorMsg}>
      <TopClientsTable clients={clients} />
    </CardLoading>
  );
}
