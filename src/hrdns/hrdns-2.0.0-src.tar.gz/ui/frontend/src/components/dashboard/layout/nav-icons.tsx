import { ArticleOutlined, DevicesOutlined, DnsOutlined, type SvgIconComponent, QueryStatsOutlined, EventNoteOutlined } from '@mui/icons-material';

export const navIcons = {
  'QueryStats': QueryStatsOutlined,
  'EventNote': EventNoteOutlined,
  "Dns": DnsOutlined,
  'Devices': DevicesOutlined,
  'Article': ArticleOutlined,
} as Record<string, SvgIconComponent>;
