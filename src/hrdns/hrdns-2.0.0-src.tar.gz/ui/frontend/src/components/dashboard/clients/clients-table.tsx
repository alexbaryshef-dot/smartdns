"use client"

import * as React from 'react';
import { useMemo, useState } from 'react';
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef as MRTColumnDef,
} from 'material-react-table';
import { Box, IconButton, Tooltip } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { createTheme, useColorScheme } from '@mui/material/styles';
import { useRouter } from 'next/navigation';
import { useTranslation } from 'react-i18next';
import { MRT_Localization_RU } from 'material-react-table/locales/ru';
import { type TopClients, smartdnsServer } from '@/lib/backend/server';
import { clientLogUrl, resolverClient } from '@/lib/client-label';
import { compactTableOptions, clipSx, usePersistedVisibility } from '@/lib/mrt-table';
import { type NamedHost, useNames } from '@/lib/names';

const MAX_CLIENTS = 1000;

interface ClientRow extends TopClients {
  name: string;
  host?: NamedHost;
}

function blockedShare(row: ClientRow): string {
  const share = row.query_count ? (row.blocked_count * 100) / row.query_count : 0;
  return `${row.blocked_count} (${share.toLocaleString('ru-RU', { maximumFractionDigits: 1 })} %)`;
}

export function ClientsTable(): React.JSX.Element {
  const { t } = useTranslation();
  const router = useRouter();
  const names = useNames();
  const [clients, setClients] = useState<TopClients[]>([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [columnVisibility, onColumnVisibilityChange] = usePersistedVisibility('clients-columns', {});

  const data = useMemo<ClientRow[]>(
    () => clients.map((client) => {
      const host = names?.host(client.client_ip, client.client_mac);
      return { ...client, host, name: client.client_ip ? host?.name ?? '' : resolverClient };
    }),
    [clients, names],
  );

  const columns = useMemo<MRTColumnDef<ClientRow>[]>(
    () => [
      {
        accessorKey: 'name',
        header: t('Name'),
        Cell: ({ row }) => <Box component="span" sx={clipSx}>{row.original.name || '—'}</Box>,
      },
      {
        accessorKey: 'client_ip',
        header: t('IP'),
        Cell: ({ cell }) => cell.getValue<string>() || '—',
      },
      {
        accessorFn: (row) => row.client_mac ?? '',
        id: 'client_mac',
        header: 'MAC',
        Cell: ({ cell }) => cell.getValue<string>() || '—',
      },
      {
        accessorFn: (row) => (row.host ? Number(row.host.online) : -1),
        id: 'online',
        header: t('Status'),
        Cell: ({ row }) => {
          const { host } = row.original;
          if (!host) {
            return '—';
          }
          return (
            <>
              <Box component="span" sx={{ color: host.online ? 'var(--mui-palette-dashboard-ok)' : 'text.secondary' }}>{t(host.online ? 'Online' : 'Offline')}</Box>
              {host.denied ? <Box component="span" sx={{ display: 'block', color: 'var(--mui-palette-dashboard-bad)' }}>{t('Access denied')}</Box> : null}
            </>
          );
        },
      },
      {
        accessorFn: (row) => row.host?.policy ?? '',
        id: 'policy',
        header: t('Policy'),
        Cell: ({ cell }) => cell.getValue<string>() || '—',
      },
      {
        accessorFn: (row) => row.host?.segment ?? '',
        id: 'segment',
        header: t('Segment'),
        Cell: ({ cell }) => cell.getValue<string>() || '—',
      },
      {
        accessorKey: 'query_count',
        header: t('Query Count'),
      },
      {
        accessorKey: 'blocked_count',
        header: t('Blocked Count'),
        Cell: ({ row }) => blockedShare(row.original),
      },
      {
        accessorKey: 'failed_count',
        header: t('Errors'),
      },
      {
        accessorKey: 'last_timestamp',
        header: t('Last Query'),
        Cell: ({ cell }) => {
          const last = cell.getValue<number>();
          return last ? new Date(last).toLocaleString('ru-RU') : '—';
        },
      },
    ],
    [t],
  );

  const fetchData = React.useCallback(async (): Promise<void> => {
    setIsLoading(true);
    const refreshed = await smartdnsServer.RefreshStats();
    const ret = refreshed.error ? { error: refreshed.error, data: null } : await smartdnsServer.GetTopClients(MAX_CLIENTS);
    setIsLoading(false);
    if (ret.error) {
      setErrorMsg(smartdnsServer.getErrorMessage(ret.error));
      return;
    }

    setClients(ret.data ?? []);
    setErrorMsg('');
  }, []);

  React.useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const { colorScheme } = useColorScheme();
  const tableTheme = React.useMemo(
    () => createTheme({ palette: { mode: colorScheme === 'dark' ? 'dark' : 'light' } }),
    [colorScheme],
  );

  const table = useMaterialReactTable({
    columns,
    data,
    localization: MRT_Localization_RU,
    ...compactTableOptions<ClientRow>(),
    enableColumnOrdering: false,
    enableColumnActions: false,
    enableColumnFilters: false,
    enableSorting: true,
    enableGlobalFilter: true,
    enableColumnDragging: false,
    enableKeyboardShortcuts: false,
    enablePagination: false,
    enableGlobalFilterRankedResults: false,
    muiToolbarAlertBannerProps: errorMsg ? { color: 'error', children: errorMsg } : undefined,
    muiTableBodyRowProps: ({ row }) => ({
      onClick: () => { router.push(clientLogUrl(row.original)); },
      sx: { cursor: 'pointer' },
    }),
    renderTopToolbarCustomActions: () => (
      <Tooltip arrow title={t('Refresh Data')}>
        <IconButton onClick={() => { void fetchData(); }}>
          <RefreshIcon />
        </IconButton>
      </Tooltip>
    ),
    onColumnVisibilityChange,
    initialState: {
      density: 'compact',
      showGlobalFilter: true,
      sorting: [{ id: 'query_count', desc: true }],
    },
    state: {
      showAlertBanner: errorMsg.length > 0,
      showProgressBars: isLoading,
      showSkeletons: isLoading,
      columnVisibility,
    },
    mrtTheme: () => ({
      baseBackgroundColor: tableTheme.palette.background.paper,
    }),
  });

  return <MaterialReactTable table={table} />;
}
