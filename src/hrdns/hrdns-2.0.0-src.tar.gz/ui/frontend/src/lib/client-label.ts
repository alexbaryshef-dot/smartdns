import type { TopClients } from '@/lib/backend/server';
import { paths } from '@/paths';

export const resolverClient = 'Резолвер hrdns';

export function clientLabel(address: string, name?: string): string {
  if (!address) {
    return resolverClient;
  }
  return name ? `${name} (${address})` : address;
}

export function clientLogUrl(client: TopClients): string {
  const id = client.client_mac ?? client.client_ip;
  return `${paths.dashboard.queryLog}?client=${encodeURIComponent(id)}&total_count=${client.query_count}&timestamp_after=${client.timestamp_start}&timestamp_before=${client.timestamp_end}`;
}
